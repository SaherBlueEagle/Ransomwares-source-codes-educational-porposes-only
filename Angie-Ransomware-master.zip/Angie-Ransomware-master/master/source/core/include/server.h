#ifndef SERVER_INCLUDED
#define SERVER_INCLUDED

BOOL
InitServer(VOID);

#endif
