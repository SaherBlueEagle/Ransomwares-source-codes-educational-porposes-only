#ifndef INIT_INCLUDED
#define INIT_INCLUDED

BOOL
InitCryptoModule(VOID);

#endif
