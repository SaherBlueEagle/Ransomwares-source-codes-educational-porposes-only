#ifndef __INCLUDE_RTLP_H
#define __INCLUDE_RTLP_H

#include <rtlp\memory.h>
#include <rtlp\string.h>

#endif
