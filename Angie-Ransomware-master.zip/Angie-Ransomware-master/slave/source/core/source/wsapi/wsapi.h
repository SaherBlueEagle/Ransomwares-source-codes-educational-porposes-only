#ifndef WSAPI_WSAPI_INCLUDED
#define WSAPI_WSAPI_INCLUDED

#define WsapiFunctionsCount 6

extern CONST VOLATILE DWORD WsapiNamesHashXorKey;
extern DWORD WsapiNamesHash[];
extern FARPROC WsapiAddressStorage[];

#endif
