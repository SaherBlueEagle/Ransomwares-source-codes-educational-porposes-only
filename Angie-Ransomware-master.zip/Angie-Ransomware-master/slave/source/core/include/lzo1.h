#ifndef LZO1_INCLUDED
#define LZO1_INCLUDED

VOID
Lzo1Decompress(
    IN  PVOID   Source,
    IN  SIZE_T  cbSource,
    OUT PVOID   Destination
    );

#endif
