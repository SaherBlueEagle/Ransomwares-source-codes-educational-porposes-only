#ifndef REGISTER_INCLUDED
#define REGISTER_INCLUDED

BOOL
RegisterSlave(VOID);

#endif
