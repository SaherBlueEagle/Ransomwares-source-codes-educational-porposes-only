#ifndef DROPPER_INCLUDED
#define DROPPER_INCLUDED

BOOL
ExecuteDropper(VOID);

#endif
