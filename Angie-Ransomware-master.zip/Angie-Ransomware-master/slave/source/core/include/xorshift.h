#ifndef XORSHIFT_INCLUDED
#define XORSHIFT_INCLUDED

DWORD
Xorshift32Ex(
    IO PDWORD dwSeed
    );

#endif
