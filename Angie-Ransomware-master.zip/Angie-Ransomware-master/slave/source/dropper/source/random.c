#include <random.h>

QWORD RandomSeed[2];
