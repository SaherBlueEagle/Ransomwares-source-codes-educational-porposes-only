#include <config.h>

DECLSPEC_DLLEXPORT CONFIG Config;
