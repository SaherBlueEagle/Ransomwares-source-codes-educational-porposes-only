# WannaLocker-Source-code
This is a android ransomeware source code
