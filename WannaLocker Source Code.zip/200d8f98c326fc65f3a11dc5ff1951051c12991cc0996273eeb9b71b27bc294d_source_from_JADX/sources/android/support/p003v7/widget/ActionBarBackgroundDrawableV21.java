package android.support.p003v7.widget;

import android.graphics.Outline;
import android.support.annotation.NonNull;

/* renamed from: android.support.v7.widget.ActionBarBackgroundDrawableV21 */
class ActionBarBackgroundDrawableV21 extends ActionBarBackgroundDrawable {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ActionBarBackgroundDrawableV21(ActionBarContainer actionBarContainer) {
        super(actionBarContainer);
    }

    public void getOutline(@NonNull Outline outline) {
        Outline outline2 = outline;
        if (this.mContainer.mIsSplit) {
            if (this.mContainer.mSplitBackground != null) {
                this.mContainer.mSplitBackground.getOutline(outline2);
            }
        } else if (this.mContainer.mBackground != null) {
            this.mContainer.mBackground.getOutline(outline2);
        }
    }
}
