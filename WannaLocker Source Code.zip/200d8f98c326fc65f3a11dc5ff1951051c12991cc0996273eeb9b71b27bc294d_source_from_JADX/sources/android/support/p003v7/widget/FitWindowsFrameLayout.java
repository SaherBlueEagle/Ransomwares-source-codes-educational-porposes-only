package android.support.p003v7.widget;

import android.content.Context;
import android.graphics.Rect;
import android.support.p003v7.widget.FitWindowsViewGroup;
import android.util.AttributeSet;
import android.widget.FrameLayout;

/* renamed from: android.support.v7.widget.FitWindowsFrameLayout */
public class FitWindowsFrameLayout extends FrameLayout implements FitWindowsViewGroup {
    private FitWindowsViewGroup.OnFitSystemWindowsListener mListener;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public FitWindowsFrameLayout(Context context) {
        super(context);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public FitWindowsFrameLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public void setOnFitSystemWindowsListener(FitWindowsViewGroup.OnFitSystemWindowsListener onFitSystemWindowsListener) {
        FitWindowsViewGroup.OnFitSystemWindowsListener onFitSystemWindowsListener2 = onFitSystemWindowsListener;
        this.mListener = onFitSystemWindowsListener2;
    }

    /* access modifiers changed from: protected */
    public boolean fitSystemWindows(Rect rect) {
        Rect rect2 = rect;
        if (this.mListener != null) {
            this.mListener.onFitSystemWindows(rect2);
        }
        return super.fitSystemWindows(rect2);
    }
}
