package android.support.p003v7.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.p000v4.view.GravityCompat;
import android.support.p000v4.view.InputDeviceCompat;
import android.support.p000v4.view.ViewCompat;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/* renamed from: android.support.v7.widget.LinearLayoutCompat */
public class LinearLayoutCompat extends ViewGroup {
    public static final int HORIZONTAL = 0;
    private static final int INDEX_BOTTOM = 2;
    private static final int INDEX_CENTER_VERTICAL = 0;
    private static final int INDEX_FILL = 3;
    private static final int INDEX_TOP = 1;
    public static final int SHOW_DIVIDER_BEGINNING = 1;
    public static final int SHOW_DIVIDER_END = 4;
    public static final int SHOW_DIVIDER_MIDDLE = 2;
    public static final int SHOW_DIVIDER_NONE = 0;
    public static final int VERTICAL = 1;
    private static final int VERTICAL_GRAVITY_COUNT = 4;
    private boolean mBaselineAligned;
    private int mBaselineAlignedChildIndex;
    private int mBaselineChildTop;
    private Drawable mDivider;
    private int mDividerHeight;
    private int mDividerPadding;
    private int mDividerWidth;
    private int mGravity;
    private int[] mMaxAscent;
    private int[] mMaxDescent;
    private int mOrientation;
    private int mShowDividers;
    private int mTotalLength;
    private boolean mUseLargestChild;
    private float mWeightSum;

    @Retention(RetentionPolicy.SOURCE)
    /* renamed from: android.support.v7.widget.LinearLayoutCompat$DividerMode */
    public @interface DividerMode {
    }

    @Retention(RetentionPolicy.SOURCE)
    /* renamed from: android.support.v7.widget.LinearLayoutCompat$OrientationMode */
    public @interface OrientationMode {
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public LinearLayoutCompat(Context context) {
        this(context, (AttributeSet) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public LinearLayoutCompat(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public LinearLayoutCompat(android.content.Context r13, android.util.AttributeSet r14, int r15) {
        /*
            r12 = this;
            r0 = r12
            r1 = r13
            r2 = r14
            r3 = r15
            r7 = r0
            r8 = r1
            r9 = r2
            r10 = r3
            r7.<init>(r8, r9, r10)
            r7 = r0
            r8 = 1
            r7.mBaselineAligned = r8
            r7 = r0
            r8 = -1
            r7.mBaselineAlignedChildIndex = r8
            r7 = r0
            r8 = 0
            r7.mBaselineChildTop = r8
            r7 = r0
            r8 = 8388659(0x800033, float:1.1755015E-38)
            r7.mGravity = r8
            r7 = r1
            r8 = r2
            int[] r9 = android.support.p003v7.appcompat.C0232R.styleable.LinearLayoutCompat
            r10 = r3
            r11 = 0
            android.support.v7.widget.TintTypedArray r7 = android.support.p003v7.widget.TintTypedArray.obtainStyledAttributes(r7, r8, r9, r10, r11)
            r4 = r7
            r7 = r4
            int r8 = android.support.p003v7.appcompat.C0232R.styleable.LinearLayoutCompat_android_orientation
            r9 = -1
            int r7 = r7.getInt(r8, r9)
            r5 = r7
            r7 = r5
            if (r7 < 0) goto L_0x0039
            r7 = r0
            r8 = r5
            r7.setOrientation(r8)
        L_0x0039:
            r7 = r4
            int r8 = android.support.p003v7.appcompat.C0232R.styleable.LinearLayoutCompat_android_gravity
            r9 = -1
            int r7 = r7.getInt(r8, r9)
            r5 = r7
            r7 = r5
            if (r7 < 0) goto L_0x004a
            r7 = r0
            r8 = r5
            r7.setGravity(r8)
        L_0x004a:
            r7 = r4
            int r8 = android.support.p003v7.appcompat.C0232R.styleable.LinearLayoutCompat_android_baselineAligned
            r9 = 1
            boolean r7 = r7.getBoolean(r8, r9)
            r6 = r7
            r7 = r6
            if (r7 != 0) goto L_0x005b
            r7 = r0
            r8 = r6
            r7.setBaselineAligned(r8)
        L_0x005b:
            r7 = r0
            r8 = r4
            int r9 = android.support.p003v7.appcompat.C0232R.styleable.LinearLayoutCompat_android_weightSum
            r10 = -1082130432(0xffffffffbf800000, float:-1.0)
            float r8 = r8.getFloat(r9, r10)
            r7.mWeightSum = r8
            r7 = r0
            r8 = r4
            int r9 = android.support.p003v7.appcompat.C0232R.styleable.LinearLayoutCompat_android_baselineAlignedChildIndex
            r10 = -1
            int r8 = r8.getInt(r9, r10)
            r7.mBaselineAlignedChildIndex = r8
            r7 = r0
            r8 = r4
            int r9 = android.support.p003v7.appcompat.C0232R.styleable.LinearLayoutCompat_measureWithLargestChild
            r10 = 0
            boolean r8 = r8.getBoolean(r9, r10)
            r7.mUseLargestChild = r8
            r7 = r0
            r8 = r4
            int r9 = android.support.p003v7.appcompat.C0232R.styleable.LinearLayoutCompat_divider
            android.graphics.drawable.Drawable r8 = r8.getDrawable(r9)
            r7.setDividerDrawable(r8)
            r7 = r0
            r8 = r4
            int r9 = android.support.p003v7.appcompat.C0232R.styleable.LinearLayoutCompat_showDividers
            r10 = 0
            int r8 = r8.getInt(r9, r10)
            r7.mShowDividers = r8
            r7 = r0
            r8 = r4
            int r9 = android.support.p003v7.appcompat.C0232R.styleable.LinearLayoutCompat_dividerPadding
            r10 = 0
            int r8 = r8.getDimensionPixelSize(r9, r10)
            r7.mDividerPadding = r8
            r7 = r4
            r7.recycle()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p003v7.widget.LinearLayoutCompat.<init>(android.content.Context, android.util.AttributeSet, int):void");
    }

    public void setShowDividers(int i) {
        int i2 = i;
        if (i2 != this.mShowDividers) {
            requestLayout();
        }
        this.mShowDividers = i2;
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }

    public int getShowDividers() {
        return this.mShowDividers;
    }

    public Drawable getDividerDrawable() {
        return this.mDivider;
    }

    public void setDividerDrawable(Drawable drawable) {
        Drawable drawable2 = drawable;
        if (drawable2 != this.mDivider) {
            this.mDivider = drawable2;
            if (drawable2 != null) {
                this.mDividerWidth = drawable2.getIntrinsicWidth();
                this.mDividerHeight = drawable2.getIntrinsicHeight();
            } else {
                this.mDividerWidth = 0;
                this.mDividerHeight = 0;
            }
            setWillNotDraw(drawable2 == null);
            requestLayout();
        }
    }

    public void setDividerPadding(int i) {
        int i2 = i;
        this.mDividerPadding = i2;
    }

    public int getDividerPadding() {
        return this.mDividerPadding;
    }

    public int getDividerWidth() {
        return this.mDividerWidth;
    }

    /* access modifiers changed from: protected */
    public void onDraw(Canvas canvas) {
        Canvas canvas2 = canvas;
        if (this.mDivider != null) {
            if (this.mOrientation == 1) {
                drawDividersVertical(canvas2);
            } else {
                drawDividersHorizontal(canvas2);
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void drawDividersVertical(Canvas canvas) {
        int bottom;
        Canvas canvas2 = canvas;
        int virtualChildCount = getVirtualChildCount();
        for (int i = 0; i < virtualChildCount; i++) {
            View virtualChildAt = getVirtualChildAt(i);
            if (!(virtualChildAt == null || virtualChildAt.getVisibility() == 8 || !hasDividerBeforeChildAt(i))) {
                drawHorizontalDivider(canvas2, (virtualChildAt.getTop() - ((LayoutParams) virtualChildAt.getLayoutParams()).topMargin) - this.mDividerHeight);
            }
        }
        if (hasDividerBeforeChildAt(virtualChildCount)) {
            View virtualChildAt2 = getVirtualChildAt(virtualChildCount - 1);
            if (virtualChildAt2 == null) {
                bottom = (getHeight() - getPaddingBottom()) - this.mDividerHeight;
            } else {
                bottom = virtualChildAt2.getBottom() + ((LayoutParams) virtualChildAt2.getLayoutParams()).bottomMargin;
            }
            drawHorizontalDivider(canvas2, bottom);
        }
    }

    /* access modifiers changed from: package-private */
    public void drawDividersHorizontal(Canvas canvas) {
        int right;
        int left;
        Canvas canvas2 = canvas;
        int virtualChildCount = getVirtualChildCount();
        boolean isLayoutRtl = ViewUtils.isLayoutRtl(this);
        for (int i = 0; i < virtualChildCount; i++) {
            View virtualChildAt = getVirtualChildAt(i);
            if (!(virtualChildAt == null || virtualChildAt.getVisibility() == 8 || !hasDividerBeforeChildAt(i))) {
                LayoutParams layoutParams = (LayoutParams) virtualChildAt.getLayoutParams();
                if (isLayoutRtl) {
                    left = virtualChildAt.getRight() + layoutParams.rightMargin;
                } else {
                    left = (virtualChildAt.getLeft() - layoutParams.leftMargin) - this.mDividerWidth;
                }
                drawVerticalDivider(canvas2, left);
            }
        }
        if (hasDividerBeforeChildAt(virtualChildCount)) {
            View virtualChildAt2 = getVirtualChildAt(virtualChildCount - 1);
            if (virtualChildAt2 != null) {
                LayoutParams layoutParams2 = (LayoutParams) virtualChildAt2.getLayoutParams();
                if (isLayoutRtl) {
                    right = (virtualChildAt2.getLeft() - layoutParams2.leftMargin) - this.mDividerWidth;
                } else {
                    right = virtualChildAt2.getRight() + layoutParams2.rightMargin;
                }
            } else if (isLayoutRtl) {
                right = getPaddingLeft();
            } else {
                right = (getWidth() - getPaddingRight()) - this.mDividerWidth;
            }
            drawVerticalDivider(canvas2, right);
        }
    }

    /* access modifiers changed from: package-private */
    public void drawHorizontalDivider(Canvas canvas, int i) {
        int i2 = i;
        this.mDivider.setBounds(getPaddingLeft() + this.mDividerPadding, i2, (getWidth() - getPaddingRight()) - this.mDividerPadding, i2 + this.mDividerHeight);
        this.mDivider.draw(canvas);
    }

    /* access modifiers changed from: package-private */
    public void drawVerticalDivider(Canvas canvas, int i) {
        int i2 = i;
        this.mDivider.setBounds(i2, getPaddingTop() + this.mDividerPadding, i2 + this.mDividerWidth, (getHeight() - getPaddingBottom()) - this.mDividerPadding);
        this.mDivider.draw(canvas);
    }

    public boolean isBaselineAligned() {
        return this.mBaselineAligned;
    }

    public void setBaselineAligned(boolean z) {
        boolean z2 = z;
        this.mBaselineAligned = z2;
    }

    public boolean isMeasureWithLargestChildEnabled() {
        return this.mUseLargestChild;
    }

    public void setMeasureWithLargestChildEnabled(boolean z) {
        boolean z2 = z;
        this.mUseLargestChild = z2;
    }

    public int getBaseline() {
        int i;
        Throwable th;
        Throwable th2;
        if (this.mBaselineAlignedChildIndex < 0) {
            return super.getBaseline();
        }
        if (getChildCount() <= this.mBaselineAlignedChildIndex) {
            Throwable th3 = th2;
            new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
            throw th3;
        }
        View childAt = getChildAt(this.mBaselineAlignedChildIndex);
        int baseline = childAt.getBaseline();
        if (baseline != -1) {
            int i2 = this.mBaselineChildTop;
            if (this.mOrientation == 1 && (i = this.mGravity & 112) != 48) {
                switch (i) {
                    case 16:
                        i2 += ((((getBottom() - getTop()) - getPaddingTop()) - getPaddingBottom()) - this.mTotalLength) / 2;
                        break;
                    case 80:
                        i2 = ((getBottom() - getTop()) - getPaddingBottom()) - this.mTotalLength;
                        break;
                }
            }
            return i2 + ((LayoutParams) childAt.getLayoutParams()).topMargin + baseline;
        } else if (this.mBaselineAlignedChildIndex == 0) {
            return -1;
        } else {
            Throwable th4 = th;
            new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
            throw th4;
        }
    }

    public int getBaselineAlignedChildIndex() {
        return this.mBaselineAlignedChildIndex;
    }

    public void setBaselineAlignedChildIndex(int i) {
        Throwable th;
        StringBuilder sb;
        int i2 = i;
        if (i2 < 0 || i2 >= getChildCount()) {
            Throwable th2 = th;
            new StringBuilder();
            new IllegalArgumentException(sb.append("base aligned child index out of range (0, ").append(getChildCount()).append(")").toString());
            throw th2;
        }
        this.mBaselineAlignedChildIndex = i2;
    }

    /* access modifiers changed from: package-private */
    public View getVirtualChildAt(int i) {
        return getChildAt(i);
    }

    /* access modifiers changed from: package-private */
    public int getVirtualChildCount() {
        return getChildCount();
    }

    public float getWeightSum() {
        return this.mWeightSum;
    }

    public void setWeightSum(float f) {
        float max = Math.max(0.0f, f);
        this.mWeightSum = max;
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        int i3 = i;
        int i4 = i2;
        if (this.mOrientation == 1) {
            measureVertical(i3, i4);
        } else {
            measureHorizontal(i3, i4);
        }
    }

    /* access modifiers changed from: protected */
    public boolean hasDividerBeforeChildAt(int i) {
        boolean z;
        int i2 = i;
        if (i2 == 0) {
            if ((this.mShowDividers & 1) != 0) {
                z = true;
            } else {
                z = false;
            }
            return z;
        } else if (i2 == getChildCount()) {
            return (this.mShowDividers & 4) != 0;
        } else if ((this.mShowDividers & 2) == 0) {
            return false;
        } else {
            boolean z2 = false;
            int i3 = i2 - 1;
            while (true) {
                if (i3 < 0) {
                    break;
                } else if (getChildAt(i3).getVisibility() != 8) {
                    z2 = true;
                    break;
                } else {
                    i3--;
                }
            }
            return z2;
        }
    }

    /* access modifiers changed from: package-private */
    public void measureVertical(int i, int i2) {
        Throwable th;
        int i3 = i;
        int i4 = i2;
        this.mTotalLength = 0;
        int i5 = 0;
        int i6 = 0;
        int i7 = 0;
        int i8 = 0;
        boolean z = true;
        float f = 0.0f;
        int virtualChildCount = getVirtualChildCount();
        int mode = View.MeasureSpec.getMode(i3);
        int mode2 = View.MeasureSpec.getMode(i4);
        boolean z2 = false;
        boolean z3 = false;
        int i9 = this.mBaselineAlignedChildIndex;
        boolean z4 = this.mUseLargestChild;
        int i10 = Integer.MIN_VALUE;
        int i11 = 0;
        while (i11 < virtualChildCount) {
            View virtualChildAt = getVirtualChildAt(i11);
            if (virtualChildAt == null) {
                this.mTotalLength += measureNullChild(i11);
            } else if (virtualChildAt.getVisibility() == 8) {
                i11 += getChildrenSkipCount(virtualChildAt, i11);
            } else {
                if (hasDividerBeforeChildAt(i11)) {
                    this.mTotalLength += this.mDividerHeight;
                }
                LayoutParams layoutParams = (LayoutParams) virtualChildAt.getLayoutParams();
                f += layoutParams.weight;
                if (mode2 == 1073741824 && layoutParams.height == 0 && layoutParams.weight > 0.0f) {
                    int i12 = this.mTotalLength;
                    this.mTotalLength = Math.max(i12, i12 + layoutParams.topMargin + layoutParams.bottomMargin);
                    z3 = true;
                } else {
                    int i13 = Integer.MIN_VALUE;
                    if (layoutParams.height == 0 && layoutParams.weight > 0.0f) {
                        i13 = 0;
                        layoutParams.height = -2;
                    }
                    measureChildBeforeLayout(virtualChildAt, i11, i3, 0, i4, f == 0.0f ? this.mTotalLength : 0);
                    if (i13 != Integer.MIN_VALUE) {
                        layoutParams.height = i13;
                    }
                    int measuredHeight = virtualChildAt.getMeasuredHeight();
                    int i14 = this.mTotalLength;
                    this.mTotalLength = Math.max(i14, i14 + measuredHeight + layoutParams.topMargin + layoutParams.bottomMargin + getNextLocationOffset(virtualChildAt));
                    if (z4) {
                        i10 = Math.max(measuredHeight, i10);
                    }
                }
                if (i9 >= 0 && i9 == i11 + 1) {
                    this.mBaselineChildTop = this.mTotalLength;
                }
                if (i11 >= i9 || layoutParams.weight <= 0.0f) {
                    boolean z5 = false;
                    if (mode != 1073741824 && layoutParams.width == -1) {
                        z2 = true;
                        z5 = true;
                    }
                    int i15 = layoutParams.leftMargin + layoutParams.rightMargin;
                    int measuredWidth = virtualChildAt.getMeasuredWidth() + i15;
                    i5 = Math.max(i5, measuredWidth);
                    i6 = ViewUtils.combineMeasuredStates(i6, ViewCompat.getMeasuredState(virtualChildAt));
                    z = z && layoutParams.width == -1;
                    if (layoutParams.weight > 0.0f) {
                        i8 = Math.max(i8, z5 ? i15 : measuredWidth);
                    } else {
                        i7 = Math.max(i7, z5 ? i15 : measuredWidth);
                    }
                    i11 += getChildrenSkipCount(virtualChildAt, i11);
                } else {
                    Throwable th2 = th;
                    new RuntimeException("A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex.");
                    throw th2;
                }
            }
            i11++;
        }
        if (this.mTotalLength > 0 && hasDividerBeforeChildAt(virtualChildCount)) {
            this.mTotalLength += this.mDividerHeight;
        }
        if (z4 && (mode2 == Integer.MIN_VALUE || mode2 == 0)) {
            this.mTotalLength = 0;
            int i16 = 0;
            while (i16 < virtualChildCount) {
                View virtualChildAt2 = getVirtualChildAt(i16);
                if (virtualChildAt2 == null) {
                    this.mTotalLength += measureNullChild(i16);
                } else if (virtualChildAt2.getVisibility() == 8) {
                    i16 += getChildrenSkipCount(virtualChildAt2, i16);
                } else {
                    LayoutParams layoutParams2 = (LayoutParams) virtualChildAt2.getLayoutParams();
                    int i17 = this.mTotalLength;
                    this.mTotalLength = Math.max(i17, i17 + i10 + layoutParams2.topMargin + layoutParams2.bottomMargin + getNextLocationOffset(virtualChildAt2));
                }
                i16++;
            }
        }
        this.mTotalLength += getPaddingTop() + getPaddingBottom();
        int resolveSizeAndState = ViewCompat.resolveSizeAndState(Math.max(this.mTotalLength, getSuggestedMinimumHeight()), i4, 0);
        int i18 = (resolveSizeAndState & ViewCompat.MEASURED_SIZE_MASK) - this.mTotalLength;
        if (z3 || (i18 != 0 && f > 0.0f)) {
            float f2 = this.mWeightSum > 0.0f ? this.mWeightSum : f;
            this.mTotalLength = 0;
            for (int i19 = 0; i19 < virtualChildCount; i19++) {
                View virtualChildAt3 = getVirtualChildAt(i19);
                if (virtualChildAt3.getVisibility() != 8) {
                    LayoutParams layoutParams3 = (LayoutParams) virtualChildAt3.getLayoutParams();
                    float f3 = layoutParams3.weight;
                    if (f3 > 0.0f) {
                        int i20 = (int) ((f3 * ((float) i18)) / f2);
                        f2 -= f3;
                        i18 -= i20;
                        int childMeasureSpec = getChildMeasureSpec(i3, getPaddingLeft() + getPaddingRight() + layoutParams3.leftMargin + layoutParams3.rightMargin, layoutParams3.width);
                        if (layoutParams3.height == 0 && mode2 == 1073741824) {
                            virtualChildAt3.measure(childMeasureSpec, View.MeasureSpec.makeMeasureSpec(i20 > 0 ? i20 : 0, 1073741824));
                        } else {
                            int measuredHeight2 = virtualChildAt3.getMeasuredHeight() + i20;
                            if (measuredHeight2 < 0) {
                                measuredHeight2 = 0;
                            }
                            virtualChildAt3.measure(childMeasureSpec, View.MeasureSpec.makeMeasureSpec(measuredHeight2, 1073741824));
                        }
                        i6 = ViewUtils.combineMeasuredStates(i6, ViewCompat.getMeasuredState(virtualChildAt3) & InputDeviceCompat.SOURCE_ANY);
                    }
                    int i21 = layoutParams3.leftMargin + layoutParams3.rightMargin;
                    int measuredWidth2 = virtualChildAt3.getMeasuredWidth() + i21;
                    i5 = Math.max(i5, measuredWidth2);
                    i7 = Math.max(i7, mode != 1073741824 && layoutParams3.width == -1 ? i21 : measuredWidth2);
                    z = z && layoutParams3.width == -1;
                    int i22 = this.mTotalLength;
                    this.mTotalLength = Math.max(i22, i22 + virtualChildAt3.getMeasuredHeight() + layoutParams3.topMargin + layoutParams3.bottomMargin + getNextLocationOffset(virtualChildAt3));
                }
            }
            this.mTotalLength += getPaddingTop() + getPaddingBottom();
        } else {
            i7 = Math.max(i7, i8);
            if (z4 && mode2 != 1073741824) {
                for (int i23 = 0; i23 < virtualChildCount; i23++) {
                    View virtualChildAt4 = getVirtualChildAt(i23);
                    if (!(virtualChildAt4 == null || virtualChildAt4.getVisibility() == 8 || ((LayoutParams) virtualChildAt4.getLayoutParams()).weight <= 0.0f)) {
                        virtualChildAt4.measure(View.MeasureSpec.makeMeasureSpec(virtualChildAt4.getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(i10, 1073741824));
                    }
                }
            }
        }
        if (!z && mode != 1073741824) {
            i5 = i7;
        }
        setMeasuredDimension(ViewCompat.resolveSizeAndState(Math.max(i5 + getPaddingLeft() + getPaddingRight(), getSuggestedMinimumWidth()), i3, i6), resolveSizeAndState);
        if (z2) {
            forceUniformWidth(virtualChildCount, i4);
        }
    }

    private void forceUniformWidth(int i, int i2) {
        int i3 = i;
        int i4 = i2;
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
        for (int i5 = 0; i5 < i3; i5++) {
            View virtualChildAt = getVirtualChildAt(i5);
            if (virtualChildAt.getVisibility() != 8) {
                LayoutParams layoutParams = (LayoutParams) virtualChildAt.getLayoutParams();
                if (layoutParams.width == -1) {
                    int i6 = layoutParams.height;
                    layoutParams.height = virtualChildAt.getMeasuredHeight();
                    measureChildWithMargins(virtualChildAt, makeMeasureSpec, 0, i4, 0);
                    layoutParams.height = i6;
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Code restructure failed: missing block: B:3:0x005a, code lost:
        if (r2.mMaxDescent == null) goto L_0x005c;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void measureHorizontal(int r50, int r51) {
        /*
            r49 = this;
            r2 = r49
            r3 = r50
            r4 = r51
            r36 = r2
            r37 = 0
            r0 = r37
            r1 = r36
            r1.mTotalLength = r0
            r36 = 0
            r5 = r36
            r36 = 0
            r6 = r36
            r36 = 0
            r7 = r36
            r36 = 0
            r8 = r36
            r36 = 1
            r9 = r36
            r36 = 0
            r10 = r36
            r36 = r2
            int r36 = r36.getVirtualChildCount()
            r11 = r36
            r36 = r3
            int r36 = android.view.View.MeasureSpec.getMode(r36)
            r12 = r36
            r36 = r4
            int r36 = android.view.View.MeasureSpec.getMode(r36)
            r13 = r36
            r36 = 0
            r14 = r36
            r36 = 0
            r15 = r36
            r36 = r2
            r0 = r36
            int[] r0 = r0.mMaxAscent
            r36 = r0
            if (r36 == 0) goto L_0x005c
            r36 = r2
            r0 = r36
            int[] r0 = r0.mMaxDescent
            r36 = r0
            if (r36 != 0) goto L_0x007c
        L_0x005c:
            r36 = r2
            r37 = 4
            r0 = r37
            int[] r0 = new int[r0]
            r37 = r0
            r0 = r37
            r1 = r36
            r1.mMaxAscent = r0
            r36 = r2
            r37 = 4
            r0 = r37
            int[] r0 = new int[r0]
            r37 = r0
            r0 = r37
            r1 = r36
            r1.mMaxDescent = r0
        L_0x007c:
            r36 = r2
            r0 = r36
            int[] r0 = r0.mMaxAscent
            r36 = r0
            r16 = r36
            r36 = r2
            r0 = r36
            int[] r0 = r0.mMaxDescent
            r36 = r0
            r17 = r36
            r36 = r16
            r37 = 0
            r38 = r16
            r39 = 1
            r40 = r16
            r41 = 2
            r42 = r16
            r43 = 3
            r44 = -1
            r46 = r42
            r47 = r43
            r48 = r44
            r42 = r48
            r43 = r46
            r44 = r47
            r45 = r48
            r43[r44] = r45
            r46 = r40
            r47 = r41
            r48 = r42
            r40 = r48
            r41 = r46
            r42 = r47
            r43 = r48
            r41[r42] = r43
            r46 = r38
            r47 = r39
            r48 = r40
            r38 = r48
            r39 = r46
            r40 = r47
            r41 = r48
            r39[r40] = r41
            r36[r37] = r38
            r36 = r17
            r37 = 0
            r38 = r17
            r39 = 1
            r40 = r17
            r41 = 2
            r42 = r17
            r43 = 3
            r44 = -1
            r46 = r42
            r47 = r43
            r48 = r44
            r42 = r48
            r43 = r46
            r44 = r47
            r45 = r48
            r43[r44] = r45
            r46 = r40
            r47 = r41
            r48 = r42
            r40 = r48
            r41 = r46
            r42 = r47
            r43 = r48
            r41[r42] = r43
            r46 = r38
            r47 = r39
            r48 = r40
            r38 = r48
            r39 = r46
            r40 = r47
            r41 = r48
            r39[r40] = r41
            r36[r37] = r38
            r36 = r2
            r0 = r36
            boolean r0 = r0.mBaselineAligned
            r36 = r0
            r18 = r36
            r36 = r2
            r0 = r36
            boolean r0 = r0.mUseLargestChild
            r36 = r0
            r19 = r36
            r36 = r12
            r37 = 1073741824(0x40000000, float:2.0)
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x017b
            r36 = 1
        L_0x0138:
            r20 = r36
            r36 = -2147483648(0xffffffff80000000, float:-0.0)
            r21 = r36
            r36 = 0
            r22 = r36
        L_0x0142:
            r36 = r22
            r37 = r11
            r0 = r36
            r1 = r37
            if (r0 >= r1) goto L_0x0496
            r36 = r2
            r37 = r22
            android.view.View r36 = r36.getVirtualChildAt(r37)
            r23 = r36
            r36 = r23
            if (r36 != 0) goto L_0x017e
            r36 = r2
            r46 = r36
            r36 = r46
            r37 = r46
            r0 = r37
            int r0 = r0.mTotalLength
            r37 = r0
            r38 = r2
            r39 = r22
            int r38 = r38.measureNullChild(r39)
            int r37 = r37 + r38
            r0 = r37
            r1 = r36
            r1.mTotalLength = r0
        L_0x0178:
            int r22 = r22 + 1
            goto L_0x0142
        L_0x017b:
            r36 = 0
            goto L_0x0138
        L_0x017e:
            r36 = r23
            int r36 = r36.getVisibility()
            r37 = 8
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x019d
            r36 = r22
            r37 = r2
            r38 = r23
            r39 = r22
            int r37 = r37.getChildrenSkipCount(r38, r39)
            int r36 = r36 + r37
            r22 = r36
            goto L_0x0178
        L_0x019d:
            r36 = r2
            r37 = r22
            boolean r36 = r36.hasDividerBeforeChildAt(r37)
            if (r36 == 0) goto L_0x01c5
            r36 = r2
            r46 = r36
            r36 = r46
            r37 = r46
            r0 = r37
            int r0 = r0.mTotalLength
            r37 = r0
            r38 = r2
            r0 = r38
            int r0 = r0.mDividerWidth
            r38 = r0
            int r37 = r37 + r38
            r0 = r37
            r1 = r36
            r1.mTotalLength = r0
        L_0x01c5:
            r36 = r23
            android.view.ViewGroup$LayoutParams r36 = r36.getLayoutParams()
            android.support.v7.widget.LinearLayoutCompat$LayoutParams r36 = (android.support.p003v7.widget.LinearLayoutCompat.LayoutParams) r36
            r24 = r36
            r36 = r10
            r37 = r24
            r0 = r37
            float r0 = r0.weight
            r37 = r0
            float r36 = r36 + r37
            r10 = r36
            r36 = r12
            r37 = 1073741824(0x40000000, float:2.0)
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x0382
            r36 = r24
            r0 = r36
            int r0 = r0.width
            r36 = r0
            if (r36 != 0) goto L_0x0382
            r36 = r24
            r0 = r36
            float r0 = r0.weight
            r36 = r0
            r37 = 0
            int r36 = (r36 > r37 ? 1 : (r36 == r37 ? 0 : -1))
            if (r36 <= 0) goto L_0x0382
            r36 = r20
            if (r36 == 0) goto L_0x034c
            r36 = r2
            r46 = r36
            r36 = r46
            r37 = r46
            r0 = r37
            int r0 = r0.mTotalLength
            r37 = r0
            r38 = r24
            r0 = r38
            int r0 = r0.leftMargin
            r38 = r0
            r39 = r24
            r0 = r39
            int r0 = r0.rightMargin
            r39 = r0
            int r38 = r38 + r39
            int r37 = r37 + r38
            r0 = r37
            r1 = r36
            r1.mTotalLength = r0
        L_0x022b:
            r36 = r18
            if (r36 == 0) goto L_0x037c
            r36 = 0
            r37 = 0
            int r36 = android.view.View.MeasureSpec.makeMeasureSpec(r36, r37)
            r25 = r36
            r36 = r23
            r37 = r25
            r38 = r25
            r36.measure(r37, r38)
        L_0x0242:
            r36 = 0
            r25 = r36
            r36 = r13
            r37 = 1073741824(0x40000000, float:2.0)
            r0 = r36
            r1 = r37
            if (r0 == r1) goto L_0x0268
            r36 = r24
            r0 = r36
            int r0 = r0.height
            r36 = r0
            r37 = -1
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x0268
            r36 = 1
            r14 = r36
            r36 = 1
            r25 = r36
        L_0x0268:
            r36 = r24
            r0 = r36
            int r0 = r0.topMargin
            r36 = r0
            r37 = r24
            r0 = r37
            int r0 = r0.bottomMargin
            r37 = r0
            int r36 = r36 + r37
            r26 = r36
            r36 = r23
            int r36 = r36.getMeasuredHeight()
            r37 = r26
            int r36 = r36 + r37
            r27 = r36
            r36 = r6
            r37 = r23
            int r37 = android.support.p000v4.view.ViewCompat.getMeasuredState(r37)
            int r36 = android.support.p003v7.widget.ViewUtils.combineMeasuredStates(r36, r37)
            r6 = r36
            r36 = r18
            if (r36 == 0) goto L_0x02fc
            r36 = r23
            int r36 = r36.getBaseline()
            r28 = r36
            r36 = r28
            r37 = -1
            r0 = r36
            r1 = r37
            if (r0 == r1) goto L_0x02fc
            r36 = r24
            r0 = r36
            int r0 = r0.gravity
            r36 = r0
            if (r36 >= 0) goto L_0x0471
            r36 = r2
            r0 = r36
            int r0 = r0.mGravity
            r36 = r0
        L_0x02be:
            r37 = 112(0x70, float:1.57E-43)
            r36 = r36 & 112(0x70, float:1.57E-43)
            r29 = r36
            r36 = r29
            r37 = 4
            int r36 = r36 >> 4
            r37 = -2
            r36 = r36 & -2
            r37 = 1
            int r36 = r36 >> 1
            r30 = r36
            r36 = r16
            r37 = r30
            r38 = r16
            r39 = r30
            r38 = r38[r39]
            r39 = r28
            int r38 = java.lang.Math.max(r38, r39)
            r36[r37] = r38
            r36 = r17
            r37 = r30
            r38 = r17
            r39 = r30
            r38 = r38[r39]
            r39 = r27
            r40 = r28
            int r39 = r39 - r40
            int r38 = java.lang.Math.max(r38, r39)
            r36[r37] = r38
        L_0x02fc:
            r36 = r5
            r37 = r27
            int r36 = java.lang.Math.max(r36, r37)
            r5 = r36
            r36 = r9
            if (r36 == 0) goto L_0x047b
            r36 = r24
            r0 = r36
            int r0 = r0.height
            r36 = r0
            r37 = -1
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x047b
            r36 = 1
        L_0x031c:
            r9 = r36
            r36 = r24
            r0 = r36
            float r0 = r0.weight
            r36 = r0
            r37 = 0
            int r36 = (r36 > r37 ? 1 : (r36 == r37 ? 0 : -1))
            if (r36 <= 0) goto L_0x0483
            r36 = r8
            r37 = r25
            if (r37 == 0) goto L_0x047f
            r37 = r26
        L_0x0334:
            int r36 = java.lang.Math.max(r36, r37)
            r8 = r36
        L_0x033a:
            r36 = r22
            r37 = r2
            r38 = r23
            r39 = r22
            int r37 = r37.getChildrenSkipCount(r38, r39)
            int r36 = r36 + r37
            r22 = r36
            goto L_0x0178
        L_0x034c:
            r36 = r2
            r0 = r36
            int r0 = r0.mTotalLength
            r36 = r0
            r25 = r36
            r36 = r2
            r37 = r25
            r38 = r25
            r39 = r24
            r0 = r39
            int r0 = r0.leftMargin
            r39 = r0
            int r38 = r38 + r39
            r39 = r24
            r0 = r39
            int r0 = r0.rightMargin
            r39 = r0
            int r38 = r38 + r39
            int r37 = java.lang.Math.max(r37, r38)
            r0 = r37
            r1 = r36
            r1.mTotalLength = r0
            goto L_0x022b
        L_0x037c:
            r36 = 1
            r15 = r36
            goto L_0x0242
        L_0x0382:
            r36 = -2147483648(0xffffffff80000000, float:-0.0)
            r25 = r36
            r36 = r24
            r0 = r36
            int r0 = r0.width
            r36 = r0
            if (r36 != 0) goto L_0x03ac
            r36 = r24
            r0 = r36
            float r0 = r0.weight
            r36 = r0
            r37 = 0
            int r36 = (r36 > r37 ? 1 : (r36 == r37 ? 0 : -1))
            if (r36 <= 0) goto L_0x03ac
            r36 = 0
            r25 = r36
            r36 = r24
            r37 = -2
            r0 = r37
            r1 = r36
            r1.width = r0
        L_0x03ac:
            r36 = r2
            r37 = r23
            r38 = r22
            r39 = r3
            r40 = r10
            r41 = 0
            int r40 = (r40 > r41 ? 1 : (r40 == r41 ? 0 : -1))
            if (r40 != 0) goto L_0x0431
            r40 = r2
            r0 = r40
            int r0 = r0.mTotalLength
            r40 = r0
        L_0x03c4:
            r41 = r4
            r42 = 0
            r36.measureChildBeforeLayout(r37, r38, r39, r40, r41, r42)
            r36 = r25
            r37 = -2147483648(0xffffffff80000000, float:-0.0)
            r0 = r36
            r1 = r37
            if (r0 == r1) goto L_0x03df
            r36 = r24
            r37 = r25
            r0 = r37
            r1 = r36
            r1.width = r0
        L_0x03df:
            r36 = r23
            int r36 = r36.getMeasuredWidth()
            r26 = r36
            r36 = r20
            if (r36 == 0) goto L_0x0434
            r36 = r2
            r46 = r36
            r36 = r46
            r37 = r46
            r0 = r37
            int r0 = r0.mTotalLength
            r37 = r0
            r38 = r26
            r39 = r24
            r0 = r39
            int r0 = r0.leftMargin
            r39 = r0
            int r38 = r38 + r39
            r39 = r24
            r0 = r39
            int r0 = r0.rightMargin
            r39 = r0
            int r38 = r38 + r39
            r39 = r2
            r40 = r23
            int r39 = r39.getNextLocationOffset(r40)
            int r38 = r38 + r39
            int r37 = r37 + r38
            r0 = r37
            r1 = r36
            r1.mTotalLength = r0
        L_0x0421:
            r36 = r19
            if (r36 == 0) goto L_0x0242
            r36 = r26
            r37 = r21
            int r36 = java.lang.Math.max(r36, r37)
            r21 = r36
            goto L_0x0242
        L_0x0431:
            r40 = 0
            goto L_0x03c4
        L_0x0434:
            r36 = r2
            r0 = r36
            int r0 = r0.mTotalLength
            r36 = r0
            r27 = r36
            r36 = r2
            r37 = r27
            r38 = r27
            r39 = r26
            int r38 = r38 + r39
            r39 = r24
            r0 = r39
            int r0 = r0.leftMargin
            r39 = r0
            int r38 = r38 + r39
            r39 = r24
            r0 = r39
            int r0 = r0.rightMargin
            r39 = r0
            int r38 = r38 + r39
            r39 = r2
            r40 = r23
            int r39 = r39.getNextLocationOffset(r40)
            int r38 = r38 + r39
            int r37 = java.lang.Math.max(r37, r38)
            r0 = r37
            r1 = r36
            r1.mTotalLength = r0
            goto L_0x0421
        L_0x0471:
            r36 = r24
            r0 = r36
            int r0 = r0.gravity
            r36 = r0
            goto L_0x02be
        L_0x047b:
            r36 = 0
            goto L_0x031c
        L_0x047f:
            r37 = r27
            goto L_0x0334
        L_0x0483:
            r36 = r7
            r37 = r25
            if (r37 == 0) goto L_0x0493
            r37 = r26
        L_0x048b:
            int r36 = java.lang.Math.max(r36, r37)
            r7 = r36
            goto L_0x033a
        L_0x0493:
            r37 = r27
            goto L_0x048b
        L_0x0496:
            r36 = r2
            r0 = r36
            int r0 = r0.mTotalLength
            r36 = r0
            if (r36 <= 0) goto L_0x04c8
            r36 = r2
            r37 = r11
            boolean r36 = r36.hasDividerBeforeChildAt(r37)
            if (r36 == 0) goto L_0x04c8
            r36 = r2
            r46 = r36
            r36 = r46
            r37 = r46
            r0 = r37
            int r0 = r0.mTotalLength
            r37 = r0
            r38 = r2
            r0 = r38
            int r0 = r0.mDividerWidth
            r38 = r0
            int r37 = r37 + r38
            r0 = r37
            r1 = r36
            r1.mTotalLength = r0
        L_0x04c8:
            r36 = r16
            r37 = 1
            r36 = r36[r37]
            r37 = -1
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x0500
            r36 = r16
            r37 = 0
            r36 = r36[r37]
            r37 = -1
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x0500
            r36 = r16
            r37 = 2
            r36 = r36[r37]
            r37 = -1
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x0500
            r36 = r16
            r37 = 3
            r36 = r36[r37]
            r37 = -1
            r0 = r36
            r1 = r37
            if (r0 == r1) goto L_0x055a
        L_0x0500:
            r36 = r16
            r37 = 3
            r36 = r36[r37]
            r37 = r16
            r38 = 0
            r37 = r37[r38]
            r38 = r16
            r39 = 1
            r38 = r38[r39]
            r39 = r16
            r40 = 2
            r39 = r39[r40]
            int r38 = java.lang.Math.max(r38, r39)
            int r37 = java.lang.Math.max(r37, r38)
            int r36 = java.lang.Math.max(r36, r37)
            r22 = r36
            r36 = r17
            r37 = 3
            r36 = r36[r37]
            r37 = r17
            r38 = 0
            r37 = r37[r38]
            r38 = r17
            r39 = 1
            r38 = r38[r39]
            r39 = r17
            r40 = 2
            r39 = r39[r40]
            int r38 = java.lang.Math.max(r38, r39)
            int r37 = java.lang.Math.max(r37, r38)
            int r36 = java.lang.Math.max(r36, r37)
            r23 = r36
            r36 = r5
            r37 = r22
            r38 = r23
            int r37 = r37 + r38
            int r36 = java.lang.Math.max(r36, r37)
            r5 = r36
        L_0x055a:
            r36 = r19
            if (r36 == 0) goto L_0x0655
            r36 = r12
            r37 = -2147483648(0xffffffff80000000, float:-0.0)
            r0 = r36
            r1 = r37
            if (r0 == r1) goto L_0x056c
            r36 = r12
            if (r36 != 0) goto L_0x0655
        L_0x056c:
            r36 = r2
            r37 = 0
            r0 = r37
            r1 = r36
            r1.mTotalLength = r0
            r36 = 0
            r22 = r36
        L_0x057a:
            r36 = r22
            r37 = r11
            r0 = r36
            r1 = r37
            if (r0 >= r1) goto L_0x0655
            r36 = r2
            r37 = r22
            android.view.View r36 = r36.getVirtualChildAt(r37)
            r23 = r36
            r36 = r23
            if (r36 != 0) goto L_0x05b3
            r36 = r2
            r46 = r36
            r36 = r46
            r37 = r46
            r0 = r37
            int r0 = r0.mTotalLength
            r37 = r0
            r38 = r2
            r39 = r22
            int r38 = r38.measureNullChild(r39)
            int r37 = r37 + r38
            r0 = r37
            r1 = r36
            r1.mTotalLength = r0
        L_0x05b0:
            int r22 = r22 + 1
            goto L_0x057a
        L_0x05b3:
            r36 = r23
            int r36 = r36.getVisibility()
            r37 = 8
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x05d2
            r36 = r22
            r37 = r2
            r38 = r23
            r39 = r22
            int r37 = r37.getChildrenSkipCount(r38, r39)
            int r36 = r36 + r37
            r22 = r36
            goto L_0x05b0
        L_0x05d2:
            r36 = r23
            android.view.ViewGroup$LayoutParams r36 = r36.getLayoutParams()
            android.support.v7.widget.LinearLayoutCompat$LayoutParams r36 = (android.support.p003v7.widget.LinearLayoutCompat.LayoutParams) r36
            r24 = r36
            r36 = r20
            if (r36 == 0) goto L_0x0617
            r36 = r2
            r46 = r36
            r36 = r46
            r37 = r46
            r0 = r37
            int r0 = r0.mTotalLength
            r37 = r0
            r38 = r21
            r39 = r24
            r0 = r39
            int r0 = r0.leftMargin
            r39 = r0
            int r38 = r38 + r39
            r39 = r24
            r0 = r39
            int r0 = r0.rightMargin
            r39 = r0
            int r38 = r38 + r39
            r39 = r2
            r40 = r23
            int r39 = r39.getNextLocationOffset(r40)
            int r38 = r38 + r39
            int r37 = r37 + r38
            r0 = r37
            r1 = r36
            r1.mTotalLength = r0
            goto L_0x05b0
        L_0x0617:
            r36 = r2
            r0 = r36
            int r0 = r0.mTotalLength
            r36 = r0
            r25 = r36
            r36 = r2
            r37 = r25
            r38 = r25
            r39 = r21
            int r38 = r38 + r39
            r39 = r24
            r0 = r39
            int r0 = r0.leftMargin
            r39 = r0
            int r38 = r38 + r39
            r39 = r24
            r0 = r39
            int r0 = r0.rightMargin
            r39 = r0
            int r38 = r38 + r39
            r39 = r2
            r40 = r23
            int r39 = r39.getNextLocationOffset(r40)
            int r38 = r38 + r39
            int r37 = java.lang.Math.max(r37, r38)
            r0 = r37
            r1 = r36
            r1.mTotalLength = r0
            goto L_0x05b0
        L_0x0655:
            r36 = r2
            r46 = r36
            r36 = r46
            r37 = r46
            r0 = r37
            int r0 = r0.mTotalLength
            r37 = r0
            r38 = r2
            int r38 = r38.getPaddingLeft()
            r39 = r2
            int r39 = r39.getPaddingRight()
            int r38 = r38 + r39
            int r37 = r37 + r38
            r0 = r37
            r1 = r36
            r1.mTotalLength = r0
            r36 = r2
            r0 = r36
            int r0 = r0.mTotalLength
            r36 = r0
            r22 = r36
            r36 = r22
            r37 = r2
            int r37 = r37.getSuggestedMinimumWidth()
            int r36 = java.lang.Math.max(r36, r37)
            r22 = r36
            r36 = r22
            r37 = r3
            r38 = 0
            int r36 = android.support.p000v4.view.ViewCompat.resolveSizeAndState(r36, r37, r38)
            r23 = r36
            r36 = r23
            r37 = 16777215(0xffffff, float:2.3509886E-38)
            r36 = r36 & r37
            r22 = r36
            r36 = r22
            r37 = r2
            r0 = r37
            int r0 = r0.mTotalLength
            r37 = r0
            int r36 = r36 - r37
            r24 = r36
            r36 = r15
            if (r36 != 0) goto L_0x06c4
            r36 = r24
            if (r36 == 0) goto L_0x0af9
            r36 = r10
            r37 = 0
            int r36 = (r36 > r37 ? 1 : (r36 == r37 ? 0 : -1))
            if (r36 <= 0) goto L_0x0af9
        L_0x06c4:
            r36 = r2
            r0 = r36
            float r0 = r0.mWeightSum
            r36 = r0
            r37 = 0
            int r36 = (r36 > r37 ? 1 : (r36 == r37 ? 0 : -1))
            if (r36 <= 0) goto L_0x079f
            r36 = r2
            r0 = r36
            float r0 = r0.mWeightSum
            r36 = r0
        L_0x06da:
            r25 = r36
            r36 = r16
            r37 = 0
            r38 = r16
            r39 = 1
            r40 = r16
            r41 = 2
            r42 = r16
            r43 = 3
            r44 = -1
            r46 = r42
            r47 = r43
            r48 = r44
            r42 = r48
            r43 = r46
            r44 = r47
            r45 = r48
            r43[r44] = r45
            r46 = r40
            r47 = r41
            r48 = r42
            r40 = r48
            r41 = r46
            r42 = r47
            r43 = r48
            r41[r42] = r43
            r46 = r38
            r47 = r39
            r48 = r40
            r38 = r48
            r39 = r46
            r40 = r47
            r41 = r48
            r39[r40] = r41
            r36[r37] = r38
            r36 = r17
            r37 = 0
            r38 = r17
            r39 = 1
            r40 = r17
            r41 = 2
            r42 = r17
            r43 = 3
            r44 = -1
            r46 = r42
            r47 = r43
            r48 = r44
            r42 = r48
            r43 = r46
            r44 = r47
            r45 = r48
            r43[r44] = r45
            r46 = r40
            r47 = r41
            r48 = r42
            r40 = r48
            r41 = r46
            r42 = r47
            r43 = r48
            r41[r42] = r43
            r46 = r38
            r47 = r39
            r48 = r40
            r38 = r48
            r39 = r46
            r40 = r47
            r41 = r48
            r39[r40] = r41
            r36[r37] = r38
            r36 = -1
            r5 = r36
            r36 = r2
            r37 = 0
            r0 = r37
            r1 = r36
            r1.mTotalLength = r0
            r36 = 0
            r26 = r36
        L_0x0776:
            r36 = r26
            r37 = r11
            r0 = r36
            r1 = r37
            if (r0 >= r1) goto L_0x09e4
            r36 = r2
            r37 = r26
            android.view.View r36 = r36.getVirtualChildAt(r37)
            r27 = r36
            r36 = r27
            if (r36 == 0) goto L_0x079c
            r36 = r27
            int r36 = r36.getVisibility()
            r37 = 8
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x07a3
        L_0x079c:
            int r26 = r26 + 1
            goto L_0x0776
        L_0x079f:
            r36 = r10
            goto L_0x06da
        L_0x07a3:
            r36 = r27
            android.view.ViewGroup$LayoutParams r36 = r36.getLayoutParams()
            android.support.v7.widget.LinearLayoutCompat$LayoutParams r36 = (android.support.p003v7.widget.LinearLayoutCompat.LayoutParams) r36
            r28 = r36
            r36 = r28
            r0 = r36
            float r0 = r0.weight
            r36 = r0
            r29 = r36
            r36 = r29
            r37 = 0
            int r36 = (r36 > r37 ? 1 : (r36 == r37 ? 0 : -1))
            if (r36 <= 0) goto L_0x0860
            r36 = r29
            r37 = r24
            r0 = r37
            float r0 = (float) r0
            r37 = r0
            float r36 = r36 * r37
            r37 = r25
            float r36 = r36 / r37
            r0 = r36
            int r0 = (int) r0
            r36 = r0
            r30 = r36
            r36 = r25
            r37 = r29
            float r36 = r36 - r37
            r25 = r36
            r36 = r24
            r37 = r30
            int r36 = r36 - r37
            r24 = r36
            r36 = r4
            r37 = r2
            int r37 = r37.getPaddingTop()
            r38 = r2
            int r38 = r38.getPaddingBottom()
            int r37 = r37 + r38
            r38 = r28
            r0 = r38
            int r0 = r0.topMargin
            r38 = r0
            int r37 = r37 + r38
            r38 = r28
            r0 = r38
            int r0 = r0.bottomMargin
            r38 = r0
            int r37 = r37 + r38
            r38 = r28
            r0 = r38
            int r0 = r0.height
            r38 = r0
            int r36 = getChildMeasureSpec(r36, r37, r38)
            r31 = r36
            r36 = r28
            r0 = r36
            int r0 = r0.width
            r36 = r0
            if (r36 != 0) goto L_0x082b
            r36 = r12
            r37 = 1073741824(0x40000000, float:2.0)
            r0 = r36
            r1 = r37
            if (r0 == r1) goto L_0x0974
        L_0x082b:
            r36 = r27
            int r36 = r36.getMeasuredWidth()
            r37 = r30
            int r36 = r36 + r37
            r32 = r36
            r36 = r32
            if (r36 >= 0) goto L_0x083f
            r36 = 0
            r32 = r36
        L_0x083f:
            r36 = r27
            r37 = r32
            r38 = 1073741824(0x40000000, float:2.0)
            int r37 = android.view.View.MeasureSpec.makeMeasureSpec(r37, r38)
            r38 = r31
            r36.measure(r37, r38)
        L_0x084e:
            r36 = r6
            r37 = r27
            int r37 = android.support.p000v4.view.ViewCompat.getMeasuredState(r37)
            r38 = -16777216(0xffffffffff000000, float:-1.7014118E38)
            r37 = r37 & r38
            int r36 = android.support.p003v7.widget.ViewUtils.combineMeasuredStates(r36, r37)
            r6 = r36
        L_0x0860:
            r36 = r20
            if (r36 == 0) goto L_0x098c
            r36 = r2
            r46 = r36
            r36 = r46
            r37 = r46
            r0 = r37
            int r0 = r0.mTotalLength
            r37 = r0
            r38 = r27
            int r38 = r38.getMeasuredWidth()
            r39 = r28
            r0 = r39
            int r0 = r0.leftMargin
            r39 = r0
            int r38 = r38 + r39
            r39 = r28
            r0 = r39
            int r0 = r0.rightMargin
            r39 = r0
            int r38 = r38 + r39
            r39 = r2
            r40 = r27
            int r39 = r39.getNextLocationOffset(r40)
            int r38 = r38 + r39
            int r37 = r37 + r38
            r0 = r37
            r1 = r36
            r1.mTotalLength = r0
        L_0x089e:
            r36 = r13
            r37 = 1073741824(0x40000000, float:2.0)
            r0 = r36
            r1 = r37
            if (r0 == r1) goto L_0x09ce
            r36 = r28
            r0 = r36
            int r0 = r0.height
            r36 = r0
            r37 = -1
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x09ce
            r36 = 1
        L_0x08ba:
            r30 = r36
            r36 = r28
            r0 = r36
            int r0 = r0.topMargin
            r36 = r0
            r37 = r28
            r0 = r37
            int r0 = r0.bottomMargin
            r37 = r0
            int r36 = r36 + r37
            r31 = r36
            r36 = r27
            int r36 = r36.getMeasuredHeight()
            r37 = r31
            int r36 = r36 + r37
            r32 = r36
            r36 = r5
            r37 = r32
            int r36 = java.lang.Math.max(r36, r37)
            r5 = r36
            r36 = r7
            r37 = r30
            if (r37 == 0) goto L_0x09d2
            r37 = r31
        L_0x08ee:
            int r36 = java.lang.Math.max(r36, r37)
            r7 = r36
            r36 = r9
            if (r36 == 0) goto L_0x09d6
            r36 = r28
            r0 = r36
            int r0 = r0.height
            r36 = r0
            r37 = -1
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x09d6
            r36 = 1
        L_0x090a:
            r9 = r36
            r36 = r18
            if (r36 == 0) goto L_0x079c
            r36 = r27
            int r36 = r36.getBaseline()
            r33 = r36
            r36 = r33
            r37 = -1
            r0 = r36
            r1 = r37
            if (r0 == r1) goto L_0x079c
            r36 = r28
            r0 = r36
            int r0 = r0.gravity
            r36 = r0
            if (r36 >= 0) goto L_0x09da
            r36 = r2
            r0 = r36
            int r0 = r0.mGravity
            r36 = r0
        L_0x0934:
            r37 = 112(0x70, float:1.57E-43)
            r36 = r36 & 112(0x70, float:1.57E-43)
            r34 = r36
            r36 = r34
            r37 = 4
            int r36 = r36 >> 4
            r37 = -2
            r36 = r36 & -2
            r37 = 1
            int r36 = r36 >> 1
            r35 = r36
            r36 = r16
            r37 = r35
            r38 = r16
            r39 = r35
            r38 = r38[r39]
            r39 = r33
            int r38 = java.lang.Math.max(r38, r39)
            r36[r37] = r38
            r36 = r17
            r37 = r35
            r38 = r17
            r39 = r35
            r38 = r38[r39]
            r39 = r32
            r40 = r33
            int r39 = r39 - r40
            int r38 = java.lang.Math.max(r38, r39)
            r36[r37] = r38
            goto L_0x079c
        L_0x0974:
            r36 = r27
            r37 = r30
            if (r37 <= 0) goto L_0x0989
            r37 = r30
        L_0x097c:
            r38 = 1073741824(0x40000000, float:2.0)
            int r37 = android.view.View.MeasureSpec.makeMeasureSpec(r37, r38)
            r38 = r31
            r36.measure(r37, r38)
            goto L_0x084e
        L_0x0989:
            r37 = 0
            goto L_0x097c
        L_0x098c:
            r36 = r2
            r0 = r36
            int r0 = r0.mTotalLength
            r36 = r0
            r30 = r36
            r36 = r2
            r37 = r30
            r38 = r30
            r39 = r27
            int r39 = r39.getMeasuredWidth()
            int r38 = r38 + r39
            r39 = r28
            r0 = r39
            int r0 = r0.leftMargin
            r39 = r0
            int r38 = r38 + r39
            r39 = r28
            r0 = r39
            int r0 = r0.rightMargin
            r39 = r0
            int r38 = r38 + r39
            r39 = r2
            r40 = r27
            int r39 = r39.getNextLocationOffset(r40)
            int r38 = r38 + r39
            int r37 = java.lang.Math.max(r37, r38)
            r0 = r37
            r1 = r36
            r1.mTotalLength = r0
            goto L_0x089e
        L_0x09ce:
            r36 = 0
            goto L_0x08ba
        L_0x09d2:
            r37 = r32
            goto L_0x08ee
        L_0x09d6:
            r36 = 0
            goto L_0x090a
        L_0x09da:
            r36 = r28
            r0 = r36
            int r0 = r0.gravity
            r36 = r0
            goto L_0x0934
        L_0x09e4:
            r36 = r2
            r46 = r36
            r36 = r46
            r37 = r46
            r0 = r37
            int r0 = r0.mTotalLength
            r37 = r0
            r38 = r2
            int r38 = r38.getPaddingLeft()
            r39 = r2
            int r39 = r39.getPaddingRight()
            int r38 = r38 + r39
            int r37 = r37 + r38
            r0 = r37
            r1 = r36
            r1.mTotalLength = r0
            r36 = r16
            r37 = 1
            r36 = r36[r37]
            r37 = -1
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x0a40
            r36 = r16
            r37 = 0
            r36 = r36[r37]
            r37 = -1
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x0a40
            r36 = r16
            r37 = 2
            r36 = r36[r37]
            r37 = -1
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x0a40
            r36 = r16
            r37 = 3
            r36 = r36[r37]
            r37 = -1
            r0 = r36
            r1 = r37
            if (r0 == r1) goto L_0x0a9a
        L_0x0a40:
            r36 = r16
            r37 = 3
            r36 = r36[r37]
            r37 = r16
            r38 = 0
            r37 = r37[r38]
            r38 = r16
            r39 = 1
            r38 = r38[r39]
            r39 = r16
            r40 = 2
            r39 = r39[r40]
            int r38 = java.lang.Math.max(r38, r39)
            int r37 = java.lang.Math.max(r37, r38)
            int r36 = java.lang.Math.max(r36, r37)
            r26 = r36
            r36 = r17
            r37 = 3
            r36 = r36[r37]
            r37 = r17
            r38 = 0
            r37 = r37[r38]
            r38 = r17
            r39 = 1
            r38 = r38[r39]
            r39 = r17
            r40 = 2
            r39 = r39[r40]
            int r38 = java.lang.Math.max(r38, r39)
            int r37 = java.lang.Math.max(r37, r38)
            int r36 = java.lang.Math.max(r36, r37)
            r27 = r36
            r36 = r5
            r37 = r26
            r38 = r27
            int r37 = r37 + r38
            int r36 = java.lang.Math.max(r36, r37)
            r5 = r36
        L_0x0a9a:
            r36 = r9
            if (r36 != 0) goto L_0x0aac
            r36 = r13
            r37 = 1073741824(0x40000000, float:2.0)
            r0 = r36
            r1 = r37
            if (r0 == r1) goto L_0x0aac
            r36 = r7
            r5 = r36
        L_0x0aac:
            r36 = r5
            r37 = r2
            int r37 = r37.getPaddingTop()
            r38 = r2
            int r38 = r38.getPaddingBottom()
            int r37 = r37 + r38
            int r36 = r36 + r37
            r5 = r36
            r36 = r5
            r37 = r2
            int r37 = r37.getSuggestedMinimumHeight()
            int r36 = java.lang.Math.max(r36, r37)
            r5 = r36
            r36 = r2
            r37 = r23
            r38 = r6
            r39 = -16777216(0xffffffffff000000, float:-1.7014118E38)
            r38 = r38 & r39
            r37 = r37 | r38
            r38 = r5
            r39 = r4
            r40 = r6
            r41 = 16
            int r40 = r40 << 16
            int r38 = android.support.p000v4.view.ViewCompat.resolveSizeAndState(r38, r39, r40)
            r36.setMeasuredDimension(r37, r38)
            r36 = r14
            if (r36 == 0) goto L_0x0af8
            r36 = r2
            r37 = r11
            r38 = r3
            r36.forceUniformHeight(r37, r38)
        L_0x0af8:
            return
        L_0x0af9:
            r36 = r7
            r37 = r8
            int r36 = java.lang.Math.max(r36, r37)
            r7 = r36
            r36 = r19
            if (r36 == 0) goto L_0x0a9a
            r36 = r12
            r37 = 1073741824(0x40000000, float:2.0)
            r0 = r36
            r1 = r37
            if (r0 == r1) goto L_0x0a9a
            r36 = 0
            r25 = r36
        L_0x0b15:
            r36 = r25
            r37 = r11
            r0 = r36
            r1 = r37
            if (r0 >= r1) goto L_0x0a9a
            r36 = r2
            r37 = r25
            android.view.View r36 = r36.getVirtualChildAt(r37)
            r26 = r36
            r36 = r26
            if (r36 == 0) goto L_0x0b3b
            r36 = r26
            int r36 = r36.getVisibility()
            r37 = 8
            r0 = r36
            r1 = r37
            if (r0 != r1) goto L_0x0b3e
        L_0x0b3b:
            int r25 = r25 + 1
            goto L_0x0b15
        L_0x0b3e:
            r36 = r26
            android.view.ViewGroup$LayoutParams r36 = r36.getLayoutParams()
            android.support.v7.widget.LinearLayoutCompat$LayoutParams r36 = (android.support.p003v7.widget.LinearLayoutCompat.LayoutParams) r36
            r27 = r36
            r36 = r27
            r0 = r36
            float r0 = r0.weight
            r36 = r0
            r28 = r36
            r36 = r28
            r37 = 0
            int r36 = (r36 > r37 ? 1 : (r36 == r37 ? 0 : -1))
            if (r36 <= 0) goto L_0x0b3b
            r36 = r26
            r37 = r21
            r38 = 1073741824(0x40000000, float:2.0)
            int r37 = android.view.View.MeasureSpec.makeMeasureSpec(r37, r38)
            r38 = r26
            int r38 = r38.getMeasuredHeight()
            r39 = 1073741824(0x40000000, float:2.0)
            int r38 = android.view.View.MeasureSpec.makeMeasureSpec(r38, r39)
            r36.measure(r37, r38)
            goto L_0x0b3b
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p003v7.widget.LinearLayoutCompat.measureHorizontal(int, int):void");
    }

    private void forceUniformHeight(int i, int i2) {
        int i3 = i;
        int i4 = i2;
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
        for (int i5 = 0; i5 < i3; i5++) {
            View virtualChildAt = getVirtualChildAt(i5);
            if (virtualChildAt.getVisibility() != 8) {
                LayoutParams layoutParams = (LayoutParams) virtualChildAt.getLayoutParams();
                if (layoutParams.height == -1) {
                    int i6 = layoutParams.width;
                    layoutParams.width = virtualChildAt.getMeasuredWidth();
                    measureChildWithMargins(virtualChildAt, i4, 0, makeMeasureSpec, 0);
                    layoutParams.width = i6;
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    public int getChildrenSkipCount(View view, int i) {
        View view2 = view;
        int i2 = i;
        return 0;
    }

    /* access modifiers changed from: package-private */
    public int measureNullChild(int i) {
        int i2 = i;
        return 0;
    }

    /* access modifiers changed from: package-private */
    public void measureChildBeforeLayout(View view, int i, int i2, int i3, int i4, int i5) {
        int i6 = i;
        measureChildWithMargins(view, i2, i3, i4, i5);
    }

    /* access modifiers changed from: package-private */
    public int getLocationOffset(View view) {
        View view2 = view;
        return 0;
    }

    /* access modifiers changed from: package-private */
    public int getNextLocationOffset(View view) {
        View view2 = view;
        return 0;
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        boolean z2 = z;
        int i5 = i;
        int i6 = i2;
        int i7 = i3;
        int i8 = i4;
        if (this.mOrientation == 1) {
            layoutVertical(i5, i6, i7, i8);
        } else {
            layoutHorizontal(i5, i6, i7, i8);
        }
    }

    /* access modifiers changed from: package-private */
    public void layoutVertical(int i, int i2, int i3, int i4) {
        int paddingTop;
        int i5;
        int i6 = i2;
        int i7 = i4;
        int paddingLeft = getPaddingLeft();
        int i8 = i3 - i;
        int paddingRight = i8 - getPaddingRight();
        int paddingRight2 = (i8 - paddingLeft) - getPaddingRight();
        int virtualChildCount = getVirtualChildCount();
        int i9 = this.mGravity & 112;
        int i10 = this.mGravity & GravityCompat.RELATIVE_HORIZONTAL_GRAVITY_MASK;
        switch (i9) {
            case 16:
                paddingTop = getPaddingTop() + (((i7 - i6) - this.mTotalLength) / 2);
                break;
            case 80:
                paddingTop = ((getPaddingTop() + i7) - i6) - this.mTotalLength;
                break;
            default:
                paddingTop = getPaddingTop();
                break;
        }
        int i11 = 0;
        while (i11 < virtualChildCount) {
            View virtualChildAt = getVirtualChildAt(i11);
            if (virtualChildAt == null) {
                paddingTop += measureNullChild(i11);
            } else if (virtualChildAt.getVisibility() != 8) {
                int measuredWidth = virtualChildAt.getMeasuredWidth();
                int measuredHeight = virtualChildAt.getMeasuredHeight();
                LayoutParams layoutParams = (LayoutParams) virtualChildAt.getLayoutParams();
                int i12 = layoutParams.gravity;
                if (i12 < 0) {
                    i12 = i10;
                }
                switch (GravityCompat.getAbsoluteGravity(i12, ViewCompat.getLayoutDirection(this)) & 7) {
                    case 1:
                        i5 = ((paddingLeft + ((paddingRight2 - measuredWidth) / 2)) + layoutParams.leftMargin) - layoutParams.rightMargin;
                        break;
                    case 5:
                        i5 = (paddingRight - measuredWidth) - layoutParams.rightMargin;
                        break;
                    default:
                        i5 = paddingLeft + layoutParams.leftMargin;
                        break;
                }
                if (hasDividerBeforeChildAt(i11)) {
                    paddingTop += this.mDividerHeight;
                }
                int i13 = paddingTop + layoutParams.topMargin;
                setChildFrame(virtualChildAt, i5, i13 + getLocationOffset(virtualChildAt), measuredWidth, measuredHeight);
                paddingTop = i13 + measuredHeight + layoutParams.bottomMargin + getNextLocationOffset(virtualChildAt);
                i11 += getChildrenSkipCount(virtualChildAt, i11);
            }
            i11++;
        }
    }

    /* access modifiers changed from: package-private */
    public void layoutHorizontal(int i, int i2, int i3, int i4) {
        int paddingLeft;
        int i5;
        int i6 = i;
        int i7 = i3;
        boolean isLayoutRtl = ViewUtils.isLayoutRtl(this);
        int paddingTop = getPaddingTop();
        int i8 = i4 - i2;
        int paddingBottom = i8 - getPaddingBottom();
        int paddingBottom2 = (i8 - paddingTop) - getPaddingBottom();
        int virtualChildCount = getVirtualChildCount();
        int i9 = this.mGravity & GravityCompat.RELATIVE_HORIZONTAL_GRAVITY_MASK;
        int i10 = this.mGravity & 112;
        boolean z = this.mBaselineAligned;
        int[] iArr = this.mMaxAscent;
        int[] iArr2 = this.mMaxDescent;
        switch (GravityCompat.getAbsoluteGravity(i9, ViewCompat.getLayoutDirection(this))) {
            case 1:
                paddingLeft = getPaddingLeft() + (((i7 - i6) - this.mTotalLength) / 2);
                break;
            case 5:
                paddingLeft = ((getPaddingLeft() + i7) - i6) - this.mTotalLength;
                break;
            default:
                paddingLeft = getPaddingLeft();
                break;
        }
        int i11 = 0;
        int i12 = 1;
        if (isLayoutRtl) {
            i11 = virtualChildCount - 1;
            i12 = -1;
        }
        int i13 = 0;
        while (i13 < virtualChildCount) {
            int i14 = i11 + (i12 * i13);
            View virtualChildAt = getVirtualChildAt(i14);
            if (virtualChildAt == null) {
                paddingLeft += measureNullChild(i14);
            } else if (virtualChildAt.getVisibility() != 8) {
                int measuredWidth = virtualChildAt.getMeasuredWidth();
                int measuredHeight = virtualChildAt.getMeasuredHeight();
                int i15 = -1;
                LayoutParams layoutParams = (LayoutParams) virtualChildAt.getLayoutParams();
                if (z && layoutParams.height != -1) {
                    i15 = virtualChildAt.getBaseline();
                }
                int i16 = layoutParams.gravity;
                if (i16 < 0) {
                    i16 = i10;
                }
                switch (i16 & 112) {
                    case 16:
                        i5 = ((paddingTop + ((paddingBottom2 - measuredHeight) / 2)) + layoutParams.topMargin) - layoutParams.bottomMargin;
                        break;
                    case 48:
                        i5 = paddingTop + layoutParams.topMargin;
                        if (i15 != -1) {
                            i5 += iArr[1] - i15;
                            break;
                        }
                        break;
                    case 80:
                        i5 = (paddingBottom - measuredHeight) - layoutParams.bottomMargin;
                        if (i15 != -1) {
                            i5 -= iArr2[2] - (virtualChildAt.getMeasuredHeight() - i15);
                            break;
                        }
                        break;
                    default:
                        i5 = paddingTop;
                        break;
                }
                if (hasDividerBeforeChildAt(i14)) {
                    paddingLeft += this.mDividerWidth;
                }
                int i17 = paddingLeft + layoutParams.leftMargin;
                setChildFrame(virtualChildAt, i17 + getLocationOffset(virtualChildAt), i5, measuredWidth, measuredHeight);
                paddingLeft = i17 + measuredWidth + layoutParams.rightMargin + getNextLocationOffset(virtualChildAt);
                i13 += getChildrenSkipCount(virtualChildAt, i14);
            }
            i13++;
        }
    }

    private void setChildFrame(View view, int i, int i2, int i3, int i4) {
        int i5 = i;
        int i6 = i2;
        view.layout(i5, i6, i5 + i3, i6 + i4);
    }

    public void setOrientation(int i) {
        int i2 = i;
        if (this.mOrientation != i2) {
            this.mOrientation = i2;
            requestLayout();
        }
    }

    public int getOrientation() {
        return this.mOrientation;
    }

    public void setGravity(int i) {
        int i2 = i;
        if (this.mGravity != i2) {
            if ((i2 & GravityCompat.RELATIVE_HORIZONTAL_GRAVITY_MASK) == 0) {
                i2 |= 8388611;
            }
            if ((i2 & 112) == 0) {
                i2 |= 48;
            }
            this.mGravity = i2;
            requestLayout();
        }
    }

    public void setHorizontalGravity(int i) {
        int i2 = i & GravityCompat.RELATIVE_HORIZONTAL_GRAVITY_MASK;
        if ((this.mGravity & GravityCompat.RELATIVE_HORIZONTAL_GRAVITY_MASK) != i2) {
            this.mGravity = (this.mGravity & -8388616) | i2;
            requestLayout();
        }
    }

    public void setVerticalGravity(int i) {
        int i2 = i & 112;
        if ((this.mGravity & 112) != i2) {
            this.mGravity = (this.mGravity & -113) | i2;
            requestLayout();
        }
    }

    public LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        LayoutParams layoutParams;
        new LayoutParams(getContext(), attributeSet);
        return layoutParams;
    }

    /* access modifiers changed from: protected */
    public LayoutParams generateDefaultLayoutParams() {
        LayoutParams layoutParams;
        LayoutParams layoutParams2;
        if (this.mOrientation == 0) {
            new LayoutParams(-2, -2);
            return layoutParams2;
        } else if (this.mOrientation != 1) {
            return null;
        } else {
            new LayoutParams(-1, -2);
            return layoutParams;
        }
    }

    /* access modifiers changed from: protected */
    public LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        LayoutParams layoutParams2;
        new LayoutParams(layoutParams);
        return layoutParams2;
    }

    /* access modifiers changed from: protected */
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        AccessibilityEvent accessibilityEvent2 = accessibilityEvent;
        if (Build.VERSION.SDK_INT >= 14) {
            super.onInitializeAccessibilityEvent(accessibilityEvent2);
            accessibilityEvent2.setClassName(LinearLayoutCompat.class.getName());
        }
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        AccessibilityNodeInfo accessibilityNodeInfo2 = accessibilityNodeInfo;
        if (Build.VERSION.SDK_INT >= 14) {
            super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo2);
            accessibilityNodeInfo2.setClassName(LinearLayoutCompat.class.getName());
        }
    }

    /* renamed from: android.support.v7.widget.LinearLayoutCompat$LayoutParams */
    public static class LayoutParams extends ViewGroup.MarginLayoutParams {
        public int gravity;
        public float weight;

        /* JADX WARNING: Illegal instructions before constructor call */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public LayoutParams(android.content.Context r9, android.util.AttributeSet r10) {
            /*
                r8 = this;
                r0 = r8
                r1 = r9
                r2 = r10
                r4 = r0
                r5 = r1
                r6 = r2
                r4.<init>(r5, r6)
                r4 = r0
                r5 = -1
                r4.gravity = r5
                r4 = r1
                r5 = r2
                int[] r6 = android.support.p003v7.appcompat.C0232R.styleable.LinearLayoutCompat_Layout
                android.content.res.TypedArray r4 = r4.obtainStyledAttributes(r5, r6)
                r3 = r4
                r4 = r0
                r5 = r3
                int r6 = android.support.p003v7.appcompat.C0232R.styleable.LinearLayoutCompat_Layout_android_layout_weight
                r7 = 0
                float r5 = r5.getFloat(r6, r7)
                r4.weight = r5
                r4 = r0
                r5 = r3
                int r6 = android.support.p003v7.appcompat.C0232R.styleable.LinearLayoutCompat_Layout_android_layout_gravity
                r7 = -1
                int r5 = r5.getInt(r6, r7)
                r4.gravity = r5
                r4 = r3
                r4.recycle()
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: android.support.p003v7.widget.LinearLayoutCompat.LayoutParams.<init>(android.content.Context, android.util.AttributeSet):void");
        }

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public LayoutParams(int i, int i2) {
            super(i, i2);
            this.gravity = -1;
            this.weight = 0.0f;
        }

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public LayoutParams(int i, int i2, float f) {
            super(i, i2);
            this.gravity = -1;
            this.weight = f;
        }

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public LayoutParams(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.gravity = -1;
        }

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public LayoutParams(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
            this.gravity = -1;
        }

        /* JADX WARNING: Illegal instructions before constructor call */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public LayoutParams(android.support.p003v7.widget.LinearLayoutCompat.LayoutParams r5) {
            /*
                r4 = this;
                r0 = r4
                r1 = r5
                r2 = r0
                r3 = r1
                r2.<init>(r3)
                r2 = r0
                r3 = -1
                r2.gravity = r3
                r2 = r0
                r3 = r1
                float r3 = r3.weight
                r2.weight = r3
                r2 = r0
                r3 = r1
                int r3 = r3.gravity
                r2.gravity = r3
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: android.support.p003v7.widget.LinearLayoutCompat.LayoutParams.<init>(android.support.v7.widget.LinearLayoutCompat$LayoutParams):void");
        }
    }
}
