package android.support.p003v7.widget;

import android.content.Context;
import android.graphics.Rect;
import android.support.p000v4.view.ViewCompat;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.widget.FrameLayout;

/* renamed from: android.support.v7.widget.ContentFrameLayout */
public class ContentFrameLayout extends FrameLayout {
    private OnAttachListener mAttachListener;
    private final Rect mDecorPadding;
    private TypedValue mFixedHeightMajor;
    private TypedValue mFixedHeightMinor;
    private TypedValue mFixedWidthMajor;
    private TypedValue mFixedWidthMinor;
    private TypedValue mMinWidthMajor;
    private TypedValue mMinWidthMinor;

    /* renamed from: android.support.v7.widget.ContentFrameLayout$OnAttachListener */
    public interface OnAttachListener {
        void onAttachedFromWindow();

        void onDetachedFromWindow();
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public ContentFrameLayout(Context context) {
        this(context, (AttributeSet) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public ContentFrameLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ContentFrameLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        Rect rect;
        new Rect();
        this.mDecorPadding = rect;
    }

    public void dispatchFitSystemWindows(Rect rect) {
        boolean fitSystemWindows = fitSystemWindows(rect);
    }

    public void setAttachListener(OnAttachListener onAttachListener) {
        OnAttachListener onAttachListener2 = onAttachListener;
        this.mAttachListener = onAttachListener2;
    }

    public void setDecorPadding(int i, int i2, int i3, int i4) {
        this.mDecorPadding.set(i, i2, i3, i4);
        if (ViewCompat.isLaidOut(this)) {
            requestLayout();
        }
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        int i3 = i;
        int i4 = i2;
        DisplayMetrics displayMetrics = getContext().getResources().getDisplayMetrics();
        boolean z = displayMetrics.widthPixels < displayMetrics.heightPixels;
        int mode = View.MeasureSpec.getMode(i3);
        int mode2 = View.MeasureSpec.getMode(i4);
        boolean z2 = false;
        if (mode == Integer.MIN_VALUE) {
            TypedValue typedValue = z ? this.mFixedWidthMinor : this.mFixedWidthMajor;
            if (!(typedValue == null || typedValue.type == 0)) {
                int i5 = 0;
                if (typedValue.type == 5) {
                    i5 = (int) typedValue.getDimension(displayMetrics);
                } else if (typedValue.type == 6) {
                    i5 = (int) typedValue.getFraction((float) displayMetrics.widthPixels, (float) displayMetrics.widthPixels);
                }
                if (i5 > 0) {
                    i3 = View.MeasureSpec.makeMeasureSpec(Math.min(i5 - (this.mDecorPadding.left + this.mDecorPadding.right), View.MeasureSpec.getSize(i3)), 1073741824);
                    z2 = true;
                }
            }
        }
        if (mode2 == Integer.MIN_VALUE) {
            TypedValue typedValue2 = z ? this.mFixedHeightMajor : this.mFixedHeightMinor;
            if (!(typedValue2 == null || typedValue2.type == 0)) {
                int i6 = 0;
                if (typedValue2.type == 5) {
                    i6 = (int) typedValue2.getDimension(displayMetrics);
                } else if (typedValue2.type == 6) {
                    i6 = (int) typedValue2.getFraction((float) displayMetrics.heightPixels, (float) displayMetrics.heightPixels);
                }
                if (i6 > 0) {
                    i4 = View.MeasureSpec.makeMeasureSpec(Math.min(i6 - (this.mDecorPadding.top + this.mDecorPadding.bottom), View.MeasureSpec.getSize(i4)), 1073741824);
                }
            }
        }
        super.onMeasure(i3, i4);
        int measuredWidth = getMeasuredWidth();
        boolean z3 = false;
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth, 1073741824);
        if (!z2 && mode == Integer.MIN_VALUE) {
            TypedValue typedValue3 = z ? this.mMinWidthMinor : this.mMinWidthMajor;
            if (!(typedValue3 == null || typedValue3.type == 0)) {
                int i7 = 0;
                if (typedValue3.type == 5) {
                    i7 = (int) typedValue3.getDimension(displayMetrics);
                } else if (typedValue3.type == 6) {
                    i7 = (int) typedValue3.getFraction((float) displayMetrics.widthPixels, (float) displayMetrics.widthPixels);
                }
                if (i7 > 0) {
                    i7 -= this.mDecorPadding.left + this.mDecorPadding.right;
                }
                if (measuredWidth < i7) {
                    makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i7, 1073741824);
                    z3 = true;
                }
            }
        }
        if (z3) {
            super.onMeasure(makeMeasureSpec, i4);
        }
    }

    public TypedValue getMinWidthMajor() {
        TypedValue typedValue;
        if (this.mMinWidthMajor == null) {
            new TypedValue();
            this.mMinWidthMajor = typedValue;
        }
        return this.mMinWidthMajor;
    }

    public TypedValue getMinWidthMinor() {
        TypedValue typedValue;
        if (this.mMinWidthMinor == null) {
            new TypedValue();
            this.mMinWidthMinor = typedValue;
        }
        return this.mMinWidthMinor;
    }

    public TypedValue getFixedWidthMajor() {
        TypedValue typedValue;
        if (this.mFixedWidthMajor == null) {
            new TypedValue();
            this.mFixedWidthMajor = typedValue;
        }
        return this.mFixedWidthMajor;
    }

    public TypedValue getFixedWidthMinor() {
        TypedValue typedValue;
        if (this.mFixedWidthMinor == null) {
            new TypedValue();
            this.mFixedWidthMinor = typedValue;
        }
        return this.mFixedWidthMinor;
    }

    public TypedValue getFixedHeightMajor() {
        TypedValue typedValue;
        if (this.mFixedHeightMajor == null) {
            new TypedValue();
            this.mFixedHeightMajor = typedValue;
        }
        return this.mFixedHeightMajor;
    }

    public TypedValue getFixedHeightMinor() {
        TypedValue typedValue;
        if (this.mFixedHeightMinor == null) {
            new TypedValue();
            this.mFixedHeightMinor = typedValue;
        }
        return this.mFixedHeightMinor;
    }

    /* access modifiers changed from: protected */
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.mAttachListener != null) {
            this.mAttachListener.onAttachedFromWindow();
        }
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (this.mAttachListener != null) {
            this.mAttachListener.onDetachedFromWindow();
        }
    }
}
