package android.support.p003v7.widget;

import android.content.Context;
import android.support.annotation.MenuRes;
import android.support.p003v7.appcompat.C0232R;
import android.support.p003v7.view.SupportMenuInflater;
import android.support.p003v7.view.menu.MenuBuilder;
import android.support.p003v7.view.menu.MenuPopupHelper;
import android.support.p003v7.view.menu.MenuPresenter;
import android.support.p003v7.view.menu.SubMenuBuilder;
import android.support.p003v7.widget.ListPopupWindow;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

/* renamed from: android.support.v7.widget.PopupMenu */
public class PopupMenu implements MenuBuilder.Callback, MenuPresenter.Callback {
    private View mAnchor;
    private Context mContext;
    private OnDismissListener mDismissListener;
    private View.OnTouchListener mDragListener;
    private MenuBuilder mMenu;
    private OnMenuItemClickListener mMenuItemClickListener;
    /* access modifiers changed from: private */
    public MenuPopupHelper mPopup;

    /* renamed from: android.support.v7.widget.PopupMenu$OnDismissListener */
    public interface OnDismissListener {
        void onDismiss(PopupMenu popupMenu);
    }

    /* renamed from: android.support.v7.widget.PopupMenu$OnMenuItemClickListener */
    public interface OnMenuItemClickListener {
        boolean onMenuItemClick(MenuItem menuItem);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public PopupMenu(Context context, View view) {
        this(context, view, 0);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public PopupMenu(Context context, View view, int i) {
        this(context, view, i, C0232R.attr.popupMenuStyle, 0);
    }

    public PopupMenu(Context context, View view, int i, int i2, int i3) {
        MenuBuilder menuBuilder;
        MenuPopupHelper menuPopupHelper;
        Context context2 = context;
        View view2 = view;
        this.mContext = context2;
        new MenuBuilder(context2);
        this.mMenu = menuBuilder;
        this.mMenu.setCallback(this);
        this.mAnchor = view2;
        new MenuPopupHelper(context2, this.mMenu, view2, false, i2, i3);
        this.mPopup = menuPopupHelper;
        this.mPopup.setGravity(i);
        this.mPopup.setCallback(this);
    }

    public void setGravity(int i) {
        this.mPopup.setGravity(i);
    }

    public int getGravity() {
        return this.mPopup.getGravity();
    }

    public View.OnTouchListener getDragToOpenListener() {
        View.OnTouchListener onTouchListener;
        if (this.mDragListener == null) {
            new ListPopupWindow.ForwardingListener(this, this.mAnchor) {
                final /* synthetic */ PopupMenu this$0;

                {
                    this.this$0 = r6;
                }

                /* access modifiers changed from: protected */
                public boolean onForwardingStarted() {
                    this.this$0.show();
                    return true;
                }

                /* access modifiers changed from: protected */
                public boolean onForwardingStopped() {
                    this.this$0.dismiss();
                    return true;
                }

                public ListPopupWindow getPopup() {
                    return this.this$0.mPopup.getPopup();
                }
            };
            this.mDragListener = onTouchListener;
        }
        return this.mDragListener;
    }

    public Menu getMenu() {
        return this.mMenu;
    }

    public MenuInflater getMenuInflater() {
        MenuInflater menuInflater;
        new SupportMenuInflater(this.mContext);
        return menuInflater;
    }

    public void inflate(@MenuRes int i) {
        getMenuInflater().inflate(i, this.mMenu);
    }

    public void show() {
        this.mPopup.show();
    }

    public void dismiss() {
        this.mPopup.dismiss();
    }

    public void setOnMenuItemClickListener(OnMenuItemClickListener onMenuItemClickListener) {
        OnMenuItemClickListener onMenuItemClickListener2 = onMenuItemClickListener;
        this.mMenuItemClickListener = onMenuItemClickListener2;
    }

    public void setOnDismissListener(OnDismissListener onDismissListener) {
        OnDismissListener onDismissListener2 = onDismissListener;
        this.mDismissListener = onDismissListener2;
    }

    public boolean onMenuItemSelected(MenuBuilder menuBuilder, MenuItem menuItem) {
        MenuBuilder menuBuilder2 = menuBuilder;
        MenuItem menuItem2 = menuItem;
        if (this.mMenuItemClickListener != null) {
            return this.mMenuItemClickListener.onMenuItemClick(menuItem2);
        }
        return false;
    }

    public void onCloseMenu(MenuBuilder menuBuilder, boolean z) {
        MenuBuilder menuBuilder2 = menuBuilder;
        boolean z2 = z;
        if (this.mDismissListener != null) {
            this.mDismissListener.onDismiss(this);
        }
    }

    public boolean onOpenSubMenu(MenuBuilder menuBuilder) {
        MenuPopupHelper menuPopupHelper;
        MenuBuilder menuBuilder2 = menuBuilder;
        if (menuBuilder2 == null) {
            return false;
        }
        if (!menuBuilder2.hasVisibleItems()) {
            return true;
        }
        new MenuPopupHelper(this.mContext, menuBuilder2, this.mAnchor);
        menuPopupHelper.show();
        return true;
    }

    public void onCloseSubMenu(SubMenuBuilder subMenuBuilder) {
    }

    public void onMenuModeChange(MenuBuilder menuBuilder) {
    }
}
