package android.support.p003v7.app;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.LayoutRes;
import android.support.annotation.Nullable;
import android.support.p003v7.appcompat.C0232R;
import android.support.p003v7.view.ActionMode;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;

/* renamed from: android.support.v7.app.AppCompatDialog */
public class AppCompatDialog extends Dialog implements AppCompatCallback {
    private AppCompatDelegate mDelegate;

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public AppCompatDialog(Context context) {
        this(context, 0);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public AppCompatDialog(android.content.Context r8, int r9) {
        /*
            r7 = this;
            r0 = r7
            r1 = r8
            r2 = r9
            r3 = r0
            r4 = r1
            r5 = r1
            r6 = r2
            int r5 = getThemeResId(r5, r6)
            r3.<init>(r4, r5)
            r3 = r0
            android.support.v7.app.AppCompatDelegate r3 = r3.getDelegate()
            r4 = 0
            r3.onCreate(r4)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p003v7.app.AppCompatDialog.<init>(android.content.Context, int):void");
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    protected AppCompatDialog(Context context, boolean z, DialogInterface.OnCancelListener onCancelListener) {
        super(context, z, onCancelListener);
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        Bundle bundle2 = bundle;
        getDelegate().installViewFactory();
        super.onCreate(bundle2);
        getDelegate().onCreate(bundle2);
    }

    public ActionBar getSupportActionBar() {
        return getDelegate().getSupportActionBar();
    }

    public void setContentView(@LayoutRes int i) {
        getDelegate().setContentView(i);
    }

    public void setContentView(View view) {
        getDelegate().setContentView(view);
    }

    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        getDelegate().setContentView(view, layoutParams);
    }

    public void setTitle(CharSequence charSequence) {
        CharSequence charSequence2 = charSequence;
        super.setTitle(charSequence2);
        getDelegate().setTitle(charSequence2);
    }

    public void setTitle(int i) {
        int i2 = i;
        super.setTitle(i2);
        getDelegate().setTitle(getContext().getString(i2));
    }

    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        getDelegate().addContentView(view, layoutParams);
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
        getDelegate().onStop();
    }

    public boolean supportRequestWindowFeature(int i) {
        return getDelegate().requestWindowFeature(i);
    }

    public void invalidateOptionsMenu() {
        getDelegate().invalidateOptionsMenu();
    }

    public AppCompatDelegate getDelegate() {
        if (this.mDelegate == null) {
            this.mDelegate = AppCompatDelegate.create((Dialog) this, (AppCompatCallback) this);
        }
        return this.mDelegate;
    }

    private static int getThemeResId(Context context, int i) {
        TypedValue typedValue;
        Context context2 = context;
        int i2 = i;
        if (i2 == 0) {
            new TypedValue();
            TypedValue typedValue2 = typedValue;
            boolean resolveAttribute = context2.getTheme().resolveAttribute(C0232R.attr.dialogTheme, typedValue2, true);
            i2 = typedValue2.resourceId;
        }
        return i2;
    }

    public void onSupportActionModeStarted(ActionMode actionMode) {
    }

    public void onSupportActionModeFinished(ActionMode actionMode) {
    }

    @Nullable
    public ActionMode onWindowStartingSupportActionMode(ActionMode.Callback callback) {
        ActionMode.Callback callback2 = callback;
        return null;
    }
}
