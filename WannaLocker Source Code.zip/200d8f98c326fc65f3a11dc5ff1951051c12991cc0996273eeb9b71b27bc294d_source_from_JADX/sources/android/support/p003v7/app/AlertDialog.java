package android.support.p003v7.app;

import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Message;
import android.support.p003v7.app.AlertController;
import android.support.p003v7.appcompat.C0232R;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;

/* renamed from: android.support.v7.app.AlertDialog */
public class AlertDialog extends AppCompatDialog implements DialogInterface {
    static final int LAYOUT_HINT_NONE = 0;
    static final int LAYOUT_HINT_SIDE = 1;
    /* access modifiers changed from: private */
    public AlertController mAlert;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    protected AlertDialog(android.content.Context r7) {
        /*
            r6 = this;
            r0 = r6
            r1 = r7
            r2 = r0
            r3 = r1
            r4 = r1
            r5 = 0
            int r4 = resolveDialogTheme(r4, r5)
            r5 = 1
            r2.<init>((android.content.Context) r3, (int) r4, (boolean) r5)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p003v7.app.AlertDialog.<init>(android.content.Context):void");
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    protected AlertDialog(Context context, int i) {
        this(context, i, true);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    AlertDialog(android.content.Context r12, int r13, boolean r14) {
        /*
            r11 = this;
            r0 = r11
            r1 = r12
            r2 = r13
            r3 = r14
            r4 = r0
            r5 = r1
            r6 = r1
            r7 = r2
            int r6 = resolveDialogTheme(r6, r7)
            r4.<init>(r5, r6)
            r4 = r0
            android.support.v7.app.AlertController r5 = new android.support.v7.app.AlertController
            r10 = r5
            r5 = r10
            r6 = r10
            r7 = r0
            android.content.Context r7 = r7.getContext()
            r8 = r0
            r9 = r0
            android.view.Window r9 = r9.getWindow()
            r6.<init>(r7, r8, r9)
            r4.mAlert = r5
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p003v7.app.AlertDialog.<init>(android.content.Context, int, boolean):void");
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    protected AlertDialog(android.content.Context r12, boolean r13, android.content.DialogInterface.OnCancelListener r14) {
        /*
            r11 = this;
            r0 = r11
            r1 = r12
            r2 = r13
            r3 = r14
            r4 = r0
            r5 = r1
            r6 = r1
            r7 = 0
            int r6 = resolveDialogTheme(r6, r7)
            r4.<init>(r5, r6)
            r4 = r0
            r5 = r2
            r4.setCancelable(r5)
            r4 = r0
            r5 = r3
            r4.setOnCancelListener(r5)
            r4 = r0
            android.support.v7.app.AlertController r5 = new android.support.v7.app.AlertController
            r10 = r5
            r5 = r10
            r6 = r10
            r7 = r1
            r8 = r0
            r9 = r0
            android.view.Window r9 = r9.getWindow()
            r6.<init>(r7, r8, r9)
            r4.mAlert = r5
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p003v7.app.AlertDialog.<init>(android.content.Context, boolean, android.content.DialogInterface$OnCancelListener):void");
    }

    static int resolveDialogTheme(Context context, int i) {
        TypedValue typedValue;
        Context context2 = context;
        int i2 = i;
        if (i2 >= 16777216) {
            return i2;
        }
        new TypedValue();
        TypedValue typedValue2 = typedValue;
        boolean resolveAttribute = context2.getTheme().resolveAttribute(C0232R.attr.alertDialogTheme, typedValue2, true);
        return typedValue2.resourceId;
    }

    public Button getButton(int i) {
        return this.mAlert.getButton(i);
    }

    public ListView getListView() {
        return this.mAlert.getListView();
    }

    public void setTitle(CharSequence charSequence) {
        CharSequence charSequence2 = charSequence;
        super.setTitle(charSequence2);
        this.mAlert.setTitle(charSequence2);
    }

    public void setCustomTitle(View view) {
        this.mAlert.setCustomTitle(view);
    }

    public void setMessage(CharSequence charSequence) {
        this.mAlert.setMessage(charSequence);
    }

    public void setView(View view) {
        this.mAlert.setView(view);
    }

    public void setView(View view, int i, int i2, int i3, int i4) {
        this.mAlert.setView(view, i, i2, i3, i4);
    }

    /* access modifiers changed from: package-private */
    public void setButtonPanelLayoutHint(int i) {
        this.mAlert.setButtonPanelLayoutHint(i);
    }

    public void setButton(int i, CharSequence charSequence, Message message) {
        this.mAlert.setButton(i, charSequence, (DialogInterface.OnClickListener) null, message);
    }

    public void setButton(int i, CharSequence charSequence, DialogInterface.OnClickListener onClickListener) {
        this.mAlert.setButton(i, charSequence, onClickListener, (Message) null);
    }

    public void setIcon(int i) {
        this.mAlert.setIcon(i);
    }

    public void setIcon(Drawable drawable) {
        this.mAlert.setIcon(drawable);
    }

    public void setIconAttribute(int i) {
        TypedValue typedValue;
        new TypedValue();
        TypedValue typedValue2 = typedValue;
        boolean resolveAttribute = getContext().getTheme().resolveAttribute(i, typedValue2, true);
        this.mAlert.setIcon(typedValue2.resourceId);
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.mAlert.installContent();
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        int i2 = i;
        KeyEvent keyEvent2 = keyEvent;
        if (this.mAlert.onKeyDown(i2, keyEvent2)) {
            return true;
        }
        return super.onKeyDown(i2, keyEvent2);
    }

    public boolean onKeyUp(int i, KeyEvent keyEvent) {
        int i2 = i;
        KeyEvent keyEvent2 = keyEvent;
        if (this.mAlert.onKeyUp(i2, keyEvent2)) {
            return true;
        }
        return super.onKeyUp(i2, keyEvent2);
    }

    /* renamed from: android.support.v7.app.AlertDialog$Builder */
    public static class Builder {

        /* renamed from: P */
        private final AlertController.AlertParams f26P;
        private int mTheme;

        /* JADX WARNING: Illegal instructions before constructor call */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public Builder(android.content.Context r7) {
            /*
                r6 = this;
                r0 = r6
                r1 = r7
                r2 = r0
                r3 = r1
                r4 = r1
                r5 = 0
                int r4 = android.support.p003v7.app.AlertDialog.resolveDialogTheme(r4, r5)
                r2.<init>(r3, r4)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: android.support.p003v7.app.AlertDialog.Builder.<init>(android.content.Context):void");
        }

        public Builder(Context context, int i) {
            AlertController.AlertParams alertParams;
            Context context2;
            Context context3 = context;
            int i2 = i;
            new ContextThemeWrapper(context3, AlertDialog.resolveDialogTheme(context3, i2));
            new AlertController.AlertParams(context2);
            this.f26P = alertParams;
            this.mTheme = i2;
        }

        public Context getContext() {
            return this.f26P.mContext;
        }

        public Builder setTitle(int i) {
            this.f26P.mTitle = this.f26P.mContext.getText(i);
            return this;
        }

        public Builder setTitle(CharSequence charSequence) {
            this.f26P.mTitle = charSequence;
            return this;
        }

        public Builder setCustomTitle(View view) {
            this.f26P.mCustomTitleView = view;
            return this;
        }

        public Builder setMessage(int i) {
            this.f26P.mMessage = this.f26P.mContext.getText(i);
            return this;
        }

        public Builder setMessage(CharSequence charSequence) {
            this.f26P.mMessage = charSequence;
            return this;
        }

        public Builder setIcon(int i) {
            this.f26P.mIconId = i;
            return this;
        }

        public Builder setIcon(Drawable drawable) {
            this.f26P.mIcon = drawable;
            return this;
        }

        public Builder setIconAttribute(int i) {
            TypedValue typedValue;
            new TypedValue();
            TypedValue typedValue2 = typedValue;
            boolean resolveAttribute = this.f26P.mContext.getTheme().resolveAttribute(i, typedValue2, true);
            this.f26P.mIconId = typedValue2.resourceId;
            return this;
        }

        public Builder setPositiveButton(int i, DialogInterface.OnClickListener onClickListener) {
            this.f26P.mPositiveButtonText = this.f26P.mContext.getText(i);
            this.f26P.mPositiveButtonListener = onClickListener;
            return this;
        }

        public Builder setPositiveButton(CharSequence charSequence, DialogInterface.OnClickListener onClickListener) {
            this.f26P.mPositiveButtonText = charSequence;
            this.f26P.mPositiveButtonListener = onClickListener;
            return this;
        }

        public Builder setNegativeButton(int i, DialogInterface.OnClickListener onClickListener) {
            this.f26P.mNegativeButtonText = this.f26P.mContext.getText(i);
            this.f26P.mNegativeButtonListener = onClickListener;
            return this;
        }

        public Builder setNegativeButton(CharSequence charSequence, DialogInterface.OnClickListener onClickListener) {
            this.f26P.mNegativeButtonText = charSequence;
            this.f26P.mNegativeButtonListener = onClickListener;
            return this;
        }

        public Builder setNeutralButton(int i, DialogInterface.OnClickListener onClickListener) {
            this.f26P.mNeutralButtonText = this.f26P.mContext.getText(i);
            this.f26P.mNeutralButtonListener = onClickListener;
            return this;
        }

        public Builder setNeutralButton(CharSequence charSequence, DialogInterface.OnClickListener onClickListener) {
            this.f26P.mNeutralButtonText = charSequence;
            this.f26P.mNeutralButtonListener = onClickListener;
            return this;
        }

        public Builder setCancelable(boolean z) {
            this.f26P.mCancelable = z;
            return this;
        }

        public Builder setOnCancelListener(DialogInterface.OnCancelListener onCancelListener) {
            this.f26P.mOnCancelListener = onCancelListener;
            return this;
        }

        public Builder setOnDismissListener(DialogInterface.OnDismissListener onDismissListener) {
            this.f26P.mOnDismissListener = onDismissListener;
            return this;
        }

        public Builder setOnKeyListener(DialogInterface.OnKeyListener onKeyListener) {
            this.f26P.mOnKeyListener = onKeyListener;
            return this;
        }

        public Builder setItems(int i, DialogInterface.OnClickListener onClickListener) {
            this.f26P.mItems = this.f26P.mContext.getResources().getTextArray(i);
            this.f26P.mOnClickListener = onClickListener;
            return this;
        }

        public Builder setItems(CharSequence[] charSequenceArr, DialogInterface.OnClickListener onClickListener) {
            this.f26P.mItems = charSequenceArr;
            this.f26P.mOnClickListener = onClickListener;
            return this;
        }

        public Builder setAdapter(ListAdapter listAdapter, DialogInterface.OnClickListener onClickListener) {
            this.f26P.mAdapter = listAdapter;
            this.f26P.mOnClickListener = onClickListener;
            return this;
        }

        public Builder setCursor(Cursor cursor, DialogInterface.OnClickListener onClickListener, String str) {
            this.f26P.mCursor = cursor;
            this.f26P.mLabelColumn = str;
            this.f26P.mOnClickListener = onClickListener;
            return this;
        }

        public Builder setMultiChoiceItems(int i, boolean[] zArr, DialogInterface.OnMultiChoiceClickListener onMultiChoiceClickListener) {
            this.f26P.mItems = this.f26P.mContext.getResources().getTextArray(i);
            this.f26P.mOnCheckboxClickListener = onMultiChoiceClickListener;
            this.f26P.mCheckedItems = zArr;
            this.f26P.mIsMultiChoice = true;
            return this;
        }

        public Builder setMultiChoiceItems(CharSequence[] charSequenceArr, boolean[] zArr, DialogInterface.OnMultiChoiceClickListener onMultiChoiceClickListener) {
            this.f26P.mItems = charSequenceArr;
            this.f26P.mOnCheckboxClickListener = onMultiChoiceClickListener;
            this.f26P.mCheckedItems = zArr;
            this.f26P.mIsMultiChoice = true;
            return this;
        }

        public Builder setMultiChoiceItems(Cursor cursor, String str, String str2, DialogInterface.OnMultiChoiceClickListener onMultiChoiceClickListener) {
            this.f26P.mCursor = cursor;
            this.f26P.mOnCheckboxClickListener = onMultiChoiceClickListener;
            this.f26P.mIsCheckedColumn = str;
            this.f26P.mLabelColumn = str2;
            this.f26P.mIsMultiChoice = true;
            return this;
        }

        public Builder setSingleChoiceItems(int i, int i2, DialogInterface.OnClickListener onClickListener) {
            this.f26P.mItems = this.f26P.mContext.getResources().getTextArray(i);
            this.f26P.mOnClickListener = onClickListener;
            this.f26P.mCheckedItem = i2;
            this.f26P.mIsSingleChoice = true;
            return this;
        }

        public Builder setSingleChoiceItems(Cursor cursor, int i, String str, DialogInterface.OnClickListener onClickListener) {
            this.f26P.mCursor = cursor;
            this.f26P.mOnClickListener = onClickListener;
            this.f26P.mCheckedItem = i;
            this.f26P.mLabelColumn = str;
            this.f26P.mIsSingleChoice = true;
            return this;
        }

        public Builder setSingleChoiceItems(CharSequence[] charSequenceArr, int i, DialogInterface.OnClickListener onClickListener) {
            this.f26P.mItems = charSequenceArr;
            this.f26P.mOnClickListener = onClickListener;
            this.f26P.mCheckedItem = i;
            this.f26P.mIsSingleChoice = true;
            return this;
        }

        public Builder setSingleChoiceItems(ListAdapter listAdapter, int i, DialogInterface.OnClickListener onClickListener) {
            this.f26P.mAdapter = listAdapter;
            this.f26P.mOnClickListener = onClickListener;
            this.f26P.mCheckedItem = i;
            this.f26P.mIsSingleChoice = true;
            return this;
        }

        public Builder setOnItemSelectedListener(AdapterView.OnItemSelectedListener onItemSelectedListener) {
            this.f26P.mOnItemSelectedListener = onItemSelectedListener;
            return this;
        }

        public Builder setView(int i) {
            this.f26P.mView = null;
            this.f26P.mViewLayoutResId = i;
            this.f26P.mViewSpacingSpecified = false;
            return this;
        }

        public Builder setView(View view) {
            this.f26P.mView = view;
            this.f26P.mViewLayoutResId = 0;
            this.f26P.mViewSpacingSpecified = false;
            return this;
        }

        public Builder setView(View view, int i, int i2, int i3, int i4) {
            this.f26P.mView = view;
            this.f26P.mViewLayoutResId = 0;
            this.f26P.mViewSpacingSpecified = true;
            this.f26P.mViewSpacingLeft = i;
            this.f26P.mViewSpacingTop = i2;
            this.f26P.mViewSpacingRight = i3;
            this.f26P.mViewSpacingBottom = i4;
            return this;
        }

        public Builder setInverseBackgroundForced(boolean z) {
            this.f26P.mForceInverseBackground = z;
            return this;
        }

        public Builder setRecycleOnMeasureEnabled(boolean z) {
            this.f26P.mRecycleOnMeasure = z;
            return this;
        }

        public AlertDialog create() {
            AlertDialog alertDialog;
            new AlertDialog(this.f26P.mContext, this.mTheme, false);
            AlertDialog alertDialog2 = alertDialog;
            this.f26P.apply(alertDialog2.mAlert);
            alertDialog2.setCancelable(this.f26P.mCancelable);
            if (this.f26P.mCancelable) {
                alertDialog2.setCanceledOnTouchOutside(true);
            }
            alertDialog2.setOnCancelListener(this.f26P.mOnCancelListener);
            alertDialog2.setOnDismissListener(this.f26P.mOnDismissListener);
            if (this.f26P.mOnKeyListener != null) {
                alertDialog2.setOnKeyListener(this.f26P.mOnKeyListener);
            }
            return alertDialog2;
        }

        public AlertDialog show() {
            AlertDialog create = create();
            create.show();
            return create;
        }
    }
}
