package android.support.p003v7.app;

@Deprecated
/* renamed from: android.support.v7.app.ActionBarActivity */
public class ActionBarActivity extends AppCompatActivity {
    public ActionBarActivity() {
    }
}
