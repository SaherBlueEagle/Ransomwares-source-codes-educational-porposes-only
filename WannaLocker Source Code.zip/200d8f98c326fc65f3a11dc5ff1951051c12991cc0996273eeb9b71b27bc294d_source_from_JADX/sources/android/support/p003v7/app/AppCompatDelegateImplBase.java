package android.support.p003v7.app;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.p003v7.app.ActionBarDrawerToggle;
import android.support.p003v7.appcompat.C0232R;
import android.support.p003v7.view.ActionMode;
import android.support.p003v7.view.SupportMenuInflater;
import android.support.p003v7.view.WindowCallbackWrapper;
import android.support.p003v7.view.menu.MenuBuilder;
import android.support.p003v7.widget.TintTypedArray;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.Window;

/* renamed from: android.support.v7.app.AppCompatDelegateImplBase */
abstract class AppCompatDelegateImplBase extends AppCompatDelegate {
    ActionBar mActionBar;
    final AppCompatCallback mAppCompatCallback;
    final Window.Callback mAppCompatWindowCallback;
    final Context mContext;
    boolean mHasActionBar;
    private boolean mIsDestroyed;
    boolean mIsFloating;
    MenuInflater mMenuInflater;
    final Window.Callback mOriginalWindowCallback = this.mWindow.getCallback();
    boolean mOverlayActionBar;
    boolean mOverlayActionMode;
    boolean mThemeRead;
    private CharSequence mTitle;
    final Window mWindow;
    boolean mWindowNoTitle;

    /* access modifiers changed from: package-private */
    public abstract boolean dispatchKeyEvent(KeyEvent keyEvent);

    /* access modifiers changed from: package-private */
    public abstract void initWindowDecorActionBar();

    /* access modifiers changed from: package-private */
    public abstract boolean onKeyShortcut(int i, KeyEvent keyEvent);

    /* access modifiers changed from: package-private */
    public abstract boolean onMenuOpened(int i, Menu menu);

    /* access modifiers changed from: package-private */
    public abstract void onPanelClosed(int i, Menu menu);

    /* access modifiers changed from: package-private */
    public abstract void onTitleChanged(CharSequence charSequence);

    /* access modifiers changed from: package-private */
    public abstract ActionMode startSupportActionModeFromWindow(ActionMode.Callback callback);

    AppCompatDelegateImplBase(Context context, Window window, AppCompatCallback appCompatCallback) {
        Throwable th;
        this.mContext = context;
        this.mWindow = window;
        this.mAppCompatCallback = appCompatCallback;
        if (this.mOriginalWindowCallback instanceof AppCompatWindowCallbackBase) {
            Throwable th2 = th;
            new IllegalStateException("AppCompat has already installed itself into the Window");
            throw th2;
        }
        this.mAppCompatWindowCallback = wrapWindowCallback(this.mOriginalWindowCallback);
        this.mWindow.setCallback(this.mAppCompatWindowCallback);
    }

    /* access modifiers changed from: package-private */
    public Window.Callback wrapWindowCallback(Window.Callback callback) {
        Window.Callback callback2;
        new AppCompatWindowCallbackBase(this, callback);
        return callback2;
    }

    public ActionBar getSupportActionBar() {
        initWindowDecorActionBar();
        return this.mActionBar;
    }

    /* access modifiers changed from: package-private */
    public final ActionBar peekSupportActionBar() {
        return this.mActionBar;
    }

    public MenuInflater getMenuInflater() {
        if (this.mMenuInflater == null) {
            initWindowDecorActionBar();
            SupportMenuInflater supportMenuInflater = r5;
            SupportMenuInflater supportMenuInflater2 = new SupportMenuInflater(this.mActionBar != null ? this.mActionBar.getThemedContext() : this.mContext);
            this.mMenuInflater = supportMenuInflater;
        }
        return this.mMenuInflater;
    }

    public final ActionBarDrawerToggle.Delegate getDrawerToggleDelegate() {
        ActionBarDrawerToggle.Delegate delegate;
        new ActionBarDrawableToggleImpl(this, (C02151) null);
        return delegate;
    }

    /* access modifiers changed from: package-private */
    public final Context getActionBarThemedContext() {
        Context context = null;
        ActionBar supportActionBar = getSupportActionBar();
        if (supportActionBar != null) {
            context = supportActionBar.getThemedContext();
        }
        if (context == null) {
            context = this.mContext;
        }
        return context;
    }

    /* renamed from: android.support.v7.app.AppCompatDelegateImplBase$ActionBarDrawableToggleImpl */
    private class ActionBarDrawableToggleImpl implements ActionBarDrawerToggle.Delegate {
        final /* synthetic */ AppCompatDelegateImplBase this$0;

        private ActionBarDrawableToggleImpl(AppCompatDelegateImplBase appCompatDelegateImplBase) {
            this.this$0 = appCompatDelegateImplBase;
        }

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        /* synthetic */ ActionBarDrawableToggleImpl(AppCompatDelegateImplBase appCompatDelegateImplBase, C02151 r7) {
            this(appCompatDelegateImplBase);
            C02151 r2 = r7;
        }

        public Drawable getThemeUpIndicator() {
            int[] iArr = {C0232R.attr.homeAsUpIndicator};
            TintTypedArray obtainStyledAttributes = TintTypedArray.obtainStyledAttributes(getActionBarThemedContext(), (AttributeSet) null, iArr);
            Drawable drawable = obtainStyledAttributes.getDrawable(0);
            obtainStyledAttributes.recycle();
            return drawable;
        }

        public Context getActionBarThemedContext() {
            return this.this$0.getActionBarThemedContext();
        }

        public boolean isNavigationVisible() {
            ActionBar supportActionBar = this.this$0.getSupportActionBar();
            return (supportActionBar == null || (supportActionBar.getDisplayOptions() & 4) == 0) ? false : true;
        }

        public void setActionBarUpIndicator(Drawable drawable, int i) {
            Drawable drawable2 = drawable;
            int i2 = i;
            ActionBar supportActionBar = this.this$0.getSupportActionBar();
            if (supportActionBar != null) {
                supportActionBar.setHomeAsUpIndicator(drawable2);
                supportActionBar.setHomeActionContentDescription(i2);
            }
        }

        public void setActionBarDescription(int i) {
            int i2 = i;
            ActionBar supportActionBar = this.this$0.getSupportActionBar();
            if (supportActionBar != null) {
                supportActionBar.setHomeActionContentDescription(i2);
            }
        }
    }

    public final void onDestroy() {
        this.mIsDestroyed = true;
    }

    public void setHandleNativeActionModesEnabled(boolean z) {
    }

    public boolean isHandleNativeActionModesEnabled() {
        return false;
    }

    /* access modifiers changed from: package-private */
    public final boolean isDestroyed() {
        return this.mIsDestroyed;
    }

    /* access modifiers changed from: package-private */
    public final Window.Callback getWindowCallback() {
        return this.mWindow.getCallback();
    }

    public final void setTitle(CharSequence charSequence) {
        CharSequence charSequence2 = charSequence;
        this.mTitle = charSequence2;
        onTitleChanged(charSequence2);
    }

    /* access modifiers changed from: package-private */
    public final CharSequence getTitle() {
        if (this.mOriginalWindowCallback instanceof Activity) {
            return ((Activity) this.mOriginalWindowCallback).getTitle();
        }
        return this.mTitle;
    }

    /* renamed from: android.support.v7.app.AppCompatDelegateImplBase$AppCompatWindowCallbackBase */
    class AppCompatWindowCallbackBase extends WindowCallbackWrapper {
        final /* synthetic */ AppCompatDelegateImplBase this$0;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        AppCompatWindowCallbackBase(AppCompatDelegateImplBase appCompatDelegateImplBase, Window.Callback callback) {
            super(callback);
            this.this$0 = appCompatDelegateImplBase;
        }

        public boolean dispatchKeyEvent(KeyEvent keyEvent) {
            KeyEvent keyEvent2 = keyEvent;
            return this.this$0.dispatchKeyEvent(keyEvent2) || super.dispatchKeyEvent(keyEvent2);
        }

        public boolean dispatchKeyShortcutEvent(KeyEvent keyEvent) {
            KeyEvent keyEvent2 = keyEvent;
            return super.dispatchKeyShortcutEvent(keyEvent2) || this.this$0.onKeyShortcut(keyEvent2.getKeyCode(), keyEvent2);
        }

        public boolean onCreatePanelMenu(int i, Menu menu) {
            int i2 = i;
            Menu menu2 = menu;
            if (i2 != 0 || (menu2 instanceof MenuBuilder)) {
                return super.onCreatePanelMenu(i2, menu2);
            }
            return false;
        }

        public void onContentChanged() {
        }

        public boolean onPreparePanel(int i, View view, Menu menu) {
            int i2 = i;
            View view2 = view;
            Menu menu2 = menu;
            MenuBuilder menuBuilder = menu2 instanceof MenuBuilder ? (MenuBuilder) menu2 : null;
            if (i2 == 0 && menuBuilder == null) {
                return false;
            }
            if (menuBuilder != null) {
                menuBuilder.setOverrideVisibleItems(true);
            }
            boolean onPreparePanel = super.onPreparePanel(i2, view2, menu2);
            if (menuBuilder != null) {
                menuBuilder.setOverrideVisibleItems(false);
            }
            return onPreparePanel;
        }

        public boolean onMenuOpened(int i, Menu menu) {
            int i2 = i;
            Menu menu2 = menu;
            boolean onMenuOpened = super.onMenuOpened(i2, menu2);
            boolean onMenuOpened2 = this.this$0.onMenuOpened(i2, menu2);
            return true;
        }

        public void onPanelClosed(int i, Menu menu) {
            int i2 = i;
            Menu menu2 = menu;
            super.onPanelClosed(i2, menu2);
            this.this$0.onPanelClosed(i2, menu2);
        }
    }
}
