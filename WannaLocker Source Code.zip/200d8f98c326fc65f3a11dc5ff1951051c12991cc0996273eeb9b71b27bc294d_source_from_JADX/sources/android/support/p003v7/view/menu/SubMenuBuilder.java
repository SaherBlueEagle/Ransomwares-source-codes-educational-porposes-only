package android.support.p003v7.view.menu;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.p000v4.content.ContextCompat;
import android.support.p003v7.view.menu.MenuBuilder;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

/* renamed from: android.support.v7.view.menu.SubMenuBuilder */
public class SubMenuBuilder extends MenuBuilder implements SubMenu {
    private MenuItemImpl mItem;
    private MenuBuilder mParentMenu;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public SubMenuBuilder(Context context, MenuBuilder menuBuilder, MenuItemImpl menuItemImpl) {
        super(context);
        this.mParentMenu = menuBuilder;
        this.mItem = menuItemImpl;
    }

    public void setQwertyMode(boolean z) {
        this.mParentMenu.setQwertyMode(z);
    }

    public boolean isQwertyMode() {
        return this.mParentMenu.isQwertyMode();
    }

    public void setShortcutsVisible(boolean z) {
        this.mParentMenu.setShortcutsVisible(z);
    }

    public boolean isShortcutsVisible() {
        return this.mParentMenu.isShortcutsVisible();
    }

    public Menu getParentMenu() {
        return this.mParentMenu;
    }

    public MenuItem getItem() {
        return this.mItem;
    }

    public void setCallback(MenuBuilder.Callback callback) {
        this.mParentMenu.setCallback(callback);
    }

    public MenuBuilder getRootMenu() {
        return this.mParentMenu;
    }

    /* access modifiers changed from: package-private */
    public boolean dispatchMenuItemSelected(MenuBuilder menuBuilder, MenuItem menuItem) {
        MenuBuilder menuBuilder2 = menuBuilder;
        MenuItem menuItem2 = menuItem;
        return super.dispatchMenuItemSelected(menuBuilder2, menuItem2) || this.mParentMenu.dispatchMenuItemSelected(menuBuilder2, menuItem2);
    }

    public SubMenu setIcon(Drawable drawable) {
        MenuItem icon = this.mItem.setIcon(drawable);
        return this;
    }

    public SubMenu setIcon(int i) {
        MenuItem icon = this.mItem.setIcon(i);
        return this;
    }

    public SubMenu setHeaderIcon(Drawable drawable) {
        MenuBuilder headerIconInt = super.setHeaderIconInt(drawable);
        return this;
    }

    public SubMenu setHeaderIcon(int i) {
        MenuBuilder headerIconInt = super.setHeaderIconInt(ContextCompat.getDrawable(getContext(), i));
        return this;
    }

    public SubMenu setHeaderTitle(CharSequence charSequence) {
        MenuBuilder headerTitleInt = super.setHeaderTitleInt(charSequence);
        return this;
    }

    public SubMenu setHeaderTitle(int i) {
        MenuBuilder headerTitleInt = super.setHeaderTitleInt((CharSequence) getContext().getResources().getString(i));
        return this;
    }

    public SubMenu setHeaderView(View view) {
        MenuBuilder headerViewInt = super.setHeaderViewInt(view);
        return this;
    }

    public boolean expandItemActionView(MenuItemImpl menuItemImpl) {
        return this.mParentMenu.expandItemActionView(menuItemImpl);
    }

    public boolean collapseItemActionView(MenuItemImpl menuItemImpl) {
        return this.mParentMenu.collapseItemActionView(menuItemImpl);
    }

    public String getActionViewStatesKey() {
        StringBuilder sb;
        int itemId = this.mItem != null ? this.mItem.getItemId() : 0;
        if (itemId == 0) {
            return null;
        }
        new StringBuilder();
        return sb.append(super.getActionViewStatesKey()).append(":").append(itemId).toString();
    }
}
