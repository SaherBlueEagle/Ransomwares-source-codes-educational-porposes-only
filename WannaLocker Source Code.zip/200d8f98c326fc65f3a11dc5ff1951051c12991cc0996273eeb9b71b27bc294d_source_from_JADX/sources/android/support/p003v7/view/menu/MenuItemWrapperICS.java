package android.support.p003v7.view.menu;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.support.p000v4.internal.view.SupportMenuItem;
import android.support.p000v4.view.MenuItemCompat;
import android.util.Log;
import android.view.ActionProvider;
import android.view.CollapsibleActionView;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.widget.FrameLayout;
import java.lang.reflect.Method;

@TargetApi(14)
/* renamed from: android.support.v7.view.menu.MenuItemWrapperICS */
public class MenuItemWrapperICS extends BaseMenuWrapper<SupportMenuItem> implements MenuItem {
    static final String LOG_TAG = "MenuItemWrapper";
    private Method mSetExclusiveCheckableMethod;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    MenuItemWrapperICS(Context context, SupportMenuItem supportMenuItem) {
        super(context, supportMenuItem);
    }

    public int getItemId() {
        return ((SupportMenuItem) this.mWrappedObject).getItemId();
    }

    public int getGroupId() {
        return ((SupportMenuItem) this.mWrappedObject).getGroupId();
    }

    public int getOrder() {
        return ((SupportMenuItem) this.mWrappedObject).getOrder();
    }

    public MenuItem setTitle(CharSequence charSequence) {
        MenuItem title = ((SupportMenuItem) this.mWrappedObject).setTitle(charSequence);
        return this;
    }

    public MenuItem setTitle(int i) {
        MenuItem title = ((SupportMenuItem) this.mWrappedObject).setTitle(i);
        return this;
    }

    public CharSequence getTitle() {
        return ((SupportMenuItem) this.mWrappedObject).getTitle();
    }

    public MenuItem setTitleCondensed(CharSequence charSequence) {
        MenuItem titleCondensed = ((SupportMenuItem) this.mWrappedObject).setTitleCondensed(charSequence);
        return this;
    }

    public CharSequence getTitleCondensed() {
        return ((SupportMenuItem) this.mWrappedObject).getTitleCondensed();
    }

    public MenuItem setIcon(Drawable drawable) {
        MenuItem icon = ((SupportMenuItem) this.mWrappedObject).setIcon(drawable);
        return this;
    }

    public MenuItem setIcon(int i) {
        MenuItem icon = ((SupportMenuItem) this.mWrappedObject).setIcon(i);
        return this;
    }

    public Drawable getIcon() {
        return ((SupportMenuItem) this.mWrappedObject).getIcon();
    }

    public MenuItem setIntent(Intent intent) {
        MenuItem intent2 = ((SupportMenuItem) this.mWrappedObject).setIntent(intent);
        return this;
    }

    public Intent getIntent() {
        return ((SupportMenuItem) this.mWrappedObject).getIntent();
    }

    public MenuItem setShortcut(char c, char c2) {
        MenuItem shortcut = ((SupportMenuItem) this.mWrappedObject).setShortcut(c, c2);
        return this;
    }

    public MenuItem setNumericShortcut(char c) {
        MenuItem numericShortcut = ((SupportMenuItem) this.mWrappedObject).setNumericShortcut(c);
        return this;
    }

    public char getNumericShortcut() {
        return ((SupportMenuItem) this.mWrappedObject).getNumericShortcut();
    }

    public MenuItem setAlphabeticShortcut(char c) {
        MenuItem alphabeticShortcut = ((SupportMenuItem) this.mWrappedObject).setAlphabeticShortcut(c);
        return this;
    }

    public char getAlphabeticShortcut() {
        return ((SupportMenuItem) this.mWrappedObject).getAlphabeticShortcut();
    }

    public MenuItem setCheckable(boolean z) {
        MenuItem checkable = ((SupportMenuItem) this.mWrappedObject).setCheckable(z);
        return this;
    }

    public boolean isCheckable() {
        return ((SupportMenuItem) this.mWrappedObject).isCheckable();
    }

    public MenuItem setChecked(boolean z) {
        MenuItem checked = ((SupportMenuItem) this.mWrappedObject).setChecked(z);
        return this;
    }

    public boolean isChecked() {
        return ((SupportMenuItem) this.mWrappedObject).isChecked();
    }

    public MenuItem setVisible(boolean z) {
        return ((SupportMenuItem) this.mWrappedObject).setVisible(z);
    }

    public boolean isVisible() {
        return ((SupportMenuItem) this.mWrappedObject).isVisible();
    }

    public MenuItem setEnabled(boolean z) {
        MenuItem enabled = ((SupportMenuItem) this.mWrappedObject).setEnabled(z);
        return this;
    }

    public boolean isEnabled() {
        return ((SupportMenuItem) this.mWrappedObject).isEnabled();
    }

    public boolean hasSubMenu() {
        return ((SupportMenuItem) this.mWrappedObject).hasSubMenu();
    }

    public SubMenu getSubMenu() {
        return getSubMenuWrapper(((SupportMenuItem) this.mWrappedObject).getSubMenu());
    }

    public MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
        MenuItem.OnMenuItemClickListener onMenuItemClickListener2;
        MenuItem.OnMenuItemClickListener onMenuItemClickListener3;
        MenuItem.OnMenuItemClickListener onMenuItemClickListener4 = onMenuItemClickListener;
        SupportMenuItem supportMenuItem = (SupportMenuItem) this.mWrappedObject;
        if (onMenuItemClickListener4 != null) {
            onMenuItemClickListener2 = onMenuItemClickListener3;
            new OnMenuItemClickListenerWrapper(this, onMenuItemClickListener4);
        } else {
            onMenuItemClickListener2 = null;
        }
        MenuItem onMenuItemClickListener5 = supportMenuItem.setOnMenuItemClickListener(onMenuItemClickListener2);
        return this;
    }

    public ContextMenu.ContextMenuInfo getMenuInfo() {
        return ((SupportMenuItem) this.mWrappedObject).getMenuInfo();
    }

    public void setShowAsAction(int i) {
        ((SupportMenuItem) this.mWrappedObject).setShowAsAction(i);
    }

    public MenuItem setShowAsActionFlags(int i) {
        MenuItem showAsActionFlags = ((SupportMenuItem) this.mWrappedObject).setShowAsActionFlags(i);
        return this;
    }

    public MenuItem setActionView(View view) {
        View view2;
        View view3 = view;
        if (view3 instanceof CollapsibleActionView) {
            new CollapsibleActionViewWrapper(view3);
            view3 = view2;
        }
        MenuItem actionView = ((SupportMenuItem) this.mWrappedObject).setActionView(view3);
        return this;
    }

    public MenuItem setActionView(int i) {
        View view;
        MenuItem actionView = ((SupportMenuItem) this.mWrappedObject).setActionView(i);
        View actionView2 = ((SupportMenuItem) this.mWrappedObject).getActionView();
        if (actionView2 instanceof CollapsibleActionView) {
            new CollapsibleActionViewWrapper(actionView2);
            MenuItem actionView3 = ((SupportMenuItem) this.mWrappedObject).setActionView(view);
        }
        return this;
    }

    public View getActionView() {
        View actionView = ((SupportMenuItem) this.mWrappedObject).getActionView();
        if (actionView instanceof CollapsibleActionViewWrapper) {
            return ((CollapsibleActionViewWrapper) actionView).getWrappedView();
        }
        return actionView;
    }

    public MenuItem setActionProvider(ActionProvider actionProvider) {
        ActionProvider actionProvider2 = actionProvider;
        SupportMenuItem supportActionProvider = ((SupportMenuItem) this.mWrappedObject).setSupportActionProvider(actionProvider2 != null ? createActionProviderWrapper(actionProvider2) : null);
        return this;
    }

    public ActionProvider getActionProvider() {
        android.support.p000v4.view.ActionProvider supportActionProvider = ((SupportMenuItem) this.mWrappedObject).getSupportActionProvider();
        if (supportActionProvider instanceof ActionProviderWrapper) {
            return ((ActionProviderWrapper) supportActionProvider).mInner;
        }
        return null;
    }

    public boolean expandActionView() {
        return ((SupportMenuItem) this.mWrappedObject).expandActionView();
    }

    public boolean collapseActionView() {
        return ((SupportMenuItem) this.mWrappedObject).collapseActionView();
    }

    public boolean isActionViewExpanded() {
        return ((SupportMenuItem) this.mWrappedObject).isActionViewExpanded();
    }

    public MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener onActionExpandListener) {
        MenuItemCompat.OnActionExpandListener onActionExpandListener2;
        MenuItemCompat.OnActionExpandListener onActionExpandListener3;
        MenuItem.OnActionExpandListener onActionExpandListener4 = onActionExpandListener;
        SupportMenuItem supportMenuItem = (SupportMenuItem) this.mWrappedObject;
        if (onActionExpandListener4 != null) {
            onActionExpandListener2 = onActionExpandListener3;
            new OnActionExpandListenerWrapper(this, onActionExpandListener4);
        } else {
            onActionExpandListener2 = null;
        }
        SupportMenuItem supportOnActionExpandListener = supportMenuItem.setSupportOnActionExpandListener(onActionExpandListener2);
        return this;
    }

    public void setExclusiveCheckable(boolean z) {
        boolean z2 = z;
        try {
            if (this.mSetExclusiveCheckableMethod == null) {
                this.mSetExclusiveCheckableMethod = ((SupportMenuItem) this.mWrappedObject).getClass().getDeclaredMethod("setExclusiveCheckable", new Class[]{Boolean.TYPE});
            }
            Object invoke = this.mSetExclusiveCheckableMethod.invoke(this.mWrappedObject, new Object[]{Boolean.valueOf(z2)});
        } catch (Exception e) {
            int w = Log.w(LOG_TAG, "Error while calling setExclusiveCheckable", e);
        }
    }

    /* access modifiers changed from: package-private */
    public ActionProviderWrapper createActionProviderWrapper(ActionProvider actionProvider) {
        ActionProviderWrapper actionProviderWrapper;
        new ActionProviderWrapper(this, this.mContext, actionProvider);
        return actionProviderWrapper;
    }

    /* renamed from: android.support.v7.view.menu.MenuItemWrapperICS$OnMenuItemClickListenerWrapper */
    private class OnMenuItemClickListenerWrapper extends BaseWrapper<MenuItem.OnMenuItemClickListener> implements MenuItem.OnMenuItemClickListener {
        final /* synthetic */ MenuItemWrapperICS this$0;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        OnMenuItemClickListenerWrapper(MenuItemWrapperICS menuItemWrapperICS, MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
            super(onMenuItemClickListener);
            this.this$0 = menuItemWrapperICS;
        }

        public boolean onMenuItemClick(MenuItem menuItem) {
            return ((MenuItem.OnMenuItemClickListener) this.mWrappedObject).onMenuItemClick(this.this$0.getMenuItemWrapper(menuItem));
        }
    }

    /* renamed from: android.support.v7.view.menu.MenuItemWrapperICS$OnActionExpandListenerWrapper */
    private class OnActionExpandListenerWrapper extends BaseWrapper<MenuItem.OnActionExpandListener> implements MenuItemCompat.OnActionExpandListener {
        final /* synthetic */ MenuItemWrapperICS this$0;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        OnActionExpandListenerWrapper(MenuItemWrapperICS menuItemWrapperICS, MenuItem.OnActionExpandListener onActionExpandListener) {
            super(onActionExpandListener);
            this.this$0 = menuItemWrapperICS;
        }

        public boolean onMenuItemActionExpand(MenuItem menuItem) {
            return ((MenuItem.OnActionExpandListener) this.mWrappedObject).onMenuItemActionExpand(this.this$0.getMenuItemWrapper(menuItem));
        }

        public boolean onMenuItemActionCollapse(MenuItem menuItem) {
            return ((MenuItem.OnActionExpandListener) this.mWrappedObject).onMenuItemActionCollapse(this.this$0.getMenuItemWrapper(menuItem));
        }
    }

    /* renamed from: android.support.v7.view.menu.MenuItemWrapperICS$ActionProviderWrapper */
    class ActionProviderWrapper extends android.support.p000v4.view.ActionProvider {
        final ActionProvider mInner;
        final /* synthetic */ MenuItemWrapperICS this$0;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public ActionProviderWrapper(MenuItemWrapperICS menuItemWrapperICS, Context context, ActionProvider actionProvider) {
            super(context);
            this.this$0 = menuItemWrapperICS;
            this.mInner = actionProvider;
        }

        public View onCreateActionView() {
            return this.mInner.onCreateActionView();
        }

        public boolean onPerformDefaultAction() {
            return this.mInner.onPerformDefaultAction();
        }

        public boolean hasSubMenu() {
            return this.mInner.hasSubMenu();
        }

        public void onPrepareSubMenu(SubMenu subMenu) {
            this.mInner.onPrepareSubMenu(this.this$0.getSubMenuWrapper(subMenu));
        }
    }

    /* renamed from: android.support.v7.view.menu.MenuItemWrapperICS$CollapsibleActionViewWrapper */
    static class CollapsibleActionViewWrapper extends FrameLayout implements android.support.p003v7.view.CollapsibleActionView {
        final CollapsibleActionView mWrappedView;

        /* JADX WARNING: Illegal instructions before constructor call */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        CollapsibleActionViewWrapper(android.view.View r5) {
            /*
                r4 = this;
                r0 = r4
                r1 = r5
                r2 = r0
                r3 = r1
                android.content.Context r3 = r3.getContext()
                r2.<init>(r3)
                r2 = r0
                r3 = r1
                android.view.CollapsibleActionView r3 = (android.view.CollapsibleActionView) r3
                r2.mWrappedView = r3
                r2 = r0
                r3 = r1
                r2.addView(r3)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: android.support.p003v7.view.menu.MenuItemWrapperICS.CollapsibleActionViewWrapper.<init>(android.view.View):void");
        }

        public void onActionViewExpanded() {
            this.mWrappedView.onActionViewExpanded();
        }

        public void onActionViewCollapsed() {
            this.mWrappedView.onActionViewCollapsed();
        }

        /* access modifiers changed from: package-private */
        public View getWrappedView() {
            return (View) this.mWrappedView;
        }
    }
}
