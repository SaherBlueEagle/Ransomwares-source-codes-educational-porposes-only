package android.support.p003v7.view.menu;

import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import android.support.p003v7.appcompat.C0232R;
import android.support.p003v7.view.menu.MenuPresenter;
import android.support.p003v7.view.menu.MenuView;
import android.util.SparseArray;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import java.util.ArrayList;

/* renamed from: android.support.v7.view.menu.ListMenuPresenter */
public class ListMenuPresenter implements MenuPresenter, AdapterView.OnItemClickListener {
    private static final String TAG = "ListMenuPresenter";
    public static final String VIEWS_TAG = "android:menu:list";
    MenuAdapter mAdapter;
    private MenuPresenter.Callback mCallback;
    Context mContext;
    private int mId;
    LayoutInflater mInflater;
    /* access modifiers changed from: private */
    public int mItemIndexOffset;
    int mItemLayoutRes;
    MenuBuilder mMenu;
    ExpandedMenuView mMenuView;
    int mThemeRes;

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public ListMenuPresenter(Context context, int i) {
        this(i, 0);
        this.mContext = context;
        this.mInflater = LayoutInflater.from(this.mContext);
    }

    public ListMenuPresenter(int i, int i2) {
        this.mItemLayoutRes = i;
        this.mThemeRes = i2;
    }

    public void initForMenu(Context context, MenuBuilder menuBuilder) {
        Context context2;
        Context context3 = context;
        MenuBuilder menuBuilder2 = menuBuilder;
        if (this.mThemeRes != 0) {
            new ContextThemeWrapper(context3, this.mThemeRes);
            this.mContext = context2;
            this.mInflater = LayoutInflater.from(this.mContext);
        } else if (this.mContext != null) {
            this.mContext = context3;
            if (this.mInflater == null) {
                this.mInflater = LayoutInflater.from(this.mContext);
            }
        }
        this.mMenu = menuBuilder2;
        if (this.mAdapter != null) {
            this.mAdapter.notifyDataSetChanged();
        }
    }

    public MenuView getMenuView(ViewGroup viewGroup) {
        MenuAdapter menuAdapter;
        ViewGroup viewGroup2 = viewGroup;
        if (this.mMenuView == null) {
            this.mMenuView = (ExpandedMenuView) this.mInflater.inflate(C0232R.layout.abc_expanded_menu_layout, viewGroup2, false);
            if (this.mAdapter == null) {
                new MenuAdapter(this);
                this.mAdapter = menuAdapter;
            }
            this.mMenuView.setAdapter(this.mAdapter);
            this.mMenuView.setOnItemClickListener(this);
        }
        return this.mMenuView;
    }

    public ListAdapter getAdapter() {
        MenuAdapter menuAdapter;
        if (this.mAdapter == null) {
            new MenuAdapter(this);
            this.mAdapter = menuAdapter;
        }
        return this.mAdapter;
    }

    public void updateMenuView(boolean z) {
        boolean z2 = z;
        if (this.mAdapter != null) {
            this.mAdapter.notifyDataSetChanged();
        }
    }

    public void setCallback(MenuPresenter.Callback callback) {
        MenuPresenter.Callback callback2 = callback;
        this.mCallback = callback2;
    }

    public boolean onSubMenuSelected(SubMenuBuilder subMenuBuilder) {
        MenuDialogHelper menuDialogHelper;
        SubMenuBuilder subMenuBuilder2 = subMenuBuilder;
        if (!subMenuBuilder2.hasVisibleItems()) {
            return false;
        }
        new MenuDialogHelper(subMenuBuilder2);
        menuDialogHelper.show((IBinder) null);
        if (this.mCallback != null) {
            boolean onOpenSubMenu = this.mCallback.onOpenSubMenu(subMenuBuilder2);
        }
        return true;
    }

    public void onCloseMenu(MenuBuilder menuBuilder, boolean z) {
        MenuBuilder menuBuilder2 = menuBuilder;
        boolean z2 = z;
        if (this.mCallback != null) {
            this.mCallback.onCloseMenu(menuBuilder2, z2);
        }
    }

    /* access modifiers changed from: package-private */
    public int getItemIndexOffset() {
        return this.mItemIndexOffset;
    }

    public void setItemIndexOffset(int i) {
        this.mItemIndexOffset = i;
        if (this.mMenuView != null) {
            updateMenuView(false);
        }
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
        AdapterView<?> adapterView2 = adapterView;
        View view2 = view;
        long j2 = j;
        boolean performItemAction = this.mMenu.performItemAction(this.mAdapter.getItem(i), this, 0);
    }

    public boolean flagActionItems() {
        return false;
    }

    public boolean expandItemActionView(MenuBuilder menuBuilder, MenuItemImpl menuItemImpl) {
        MenuBuilder menuBuilder2 = menuBuilder;
        MenuItemImpl menuItemImpl2 = menuItemImpl;
        return false;
    }

    public boolean collapseItemActionView(MenuBuilder menuBuilder, MenuItemImpl menuItemImpl) {
        MenuBuilder menuBuilder2 = menuBuilder;
        MenuItemImpl menuItemImpl2 = menuItemImpl;
        return false;
    }

    public void saveHierarchyState(Bundle bundle) {
        SparseArray sparseArray;
        Bundle bundle2 = bundle;
        new SparseArray();
        SparseArray sparseArray2 = sparseArray;
        if (this.mMenuView != null) {
            this.mMenuView.saveHierarchyState(sparseArray2);
        }
        bundle2.putSparseParcelableArray(VIEWS_TAG, sparseArray2);
    }

    public void restoreHierarchyState(Bundle bundle) {
        SparseArray sparseParcelableArray = bundle.getSparseParcelableArray(VIEWS_TAG);
        if (sparseParcelableArray != null) {
            this.mMenuView.restoreHierarchyState(sparseParcelableArray);
        }
    }

    public void setId(int i) {
        int i2 = i;
        this.mId = i2;
    }

    public int getId() {
        return this.mId;
    }

    public Parcelable onSaveInstanceState() {
        Bundle bundle;
        if (this.mMenuView == null) {
            return null;
        }
        new Bundle();
        Bundle bundle2 = bundle;
        saveHierarchyState(bundle2);
        return bundle2;
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        restoreHierarchyState((Bundle) parcelable);
    }

    /* renamed from: android.support.v7.view.menu.ListMenuPresenter$MenuAdapter */
    private class MenuAdapter extends BaseAdapter {
        private int mExpandedIndex = -1;
        final /* synthetic */ ListMenuPresenter this$0;

        public MenuAdapter(ListMenuPresenter listMenuPresenter) {
            this.this$0 = listMenuPresenter;
            findExpandedIndex();
        }

        public int getCount() {
            int size = this.this$0.mMenu.getNonActionItems().size() - this.this$0.mItemIndexOffset;
            if (this.mExpandedIndex < 0) {
                return size;
            }
            return size - 1;
        }

        public MenuItemImpl getItem(int i) {
            ArrayList<MenuItemImpl> nonActionItems = this.this$0.mMenu.getNonActionItems();
            int access$000 = i + this.this$0.mItemIndexOffset;
            if (this.mExpandedIndex >= 0 && access$000 >= this.mExpandedIndex) {
                access$000++;
            }
            return nonActionItems.get(access$000);
        }

        public long getItemId(int i) {
            return (long) i;
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            int i2 = i;
            View view2 = view;
            ViewGroup viewGroup2 = viewGroup;
            if (view2 == null) {
                view2 = this.this$0.mInflater.inflate(this.this$0.mItemLayoutRes, viewGroup2, false);
            }
            ((MenuView.ItemView) view2).initialize(getItem(i2), 0);
            return view2;
        }

        /* access modifiers changed from: package-private */
        public void findExpandedIndex() {
            MenuItemImpl expandedItem = this.this$0.mMenu.getExpandedItem();
            if (expandedItem != null) {
                ArrayList<MenuItemImpl> nonActionItems = this.this$0.mMenu.getNonActionItems();
                int size = nonActionItems.size();
                for (int i = 0; i < size; i++) {
                    if (nonActionItems.get(i) == expandedItem) {
                        this.mExpandedIndex = i;
                        return;
                    }
                }
            }
            this.mExpandedIndex = -1;
        }

        public void notifyDataSetChanged() {
            findExpandedIndex();
            super.notifyDataSetChanged();
        }
    }
}
