package android.support.p000v4.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;

/* renamed from: android.support.v4.widget.Space */
public class Space extends View {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public Space(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        if (getVisibility() == 0) {
            setVisibility(4);
        }
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public Space(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public Space(Context context) {
        this(context, (AttributeSet) null);
    }

    public void draw(Canvas canvas) {
    }

    private static int getDefaultSize2(int i, int i2) {
        int i3 = i;
        int i4 = i2;
        int i5 = i3;
        int mode = View.MeasureSpec.getMode(i4);
        int size = View.MeasureSpec.getSize(i4);
        switch (mode) {
            case Integer.MIN_VALUE:
                i5 = Math.min(i3, size);
                break;
            case 0:
                i5 = i3;
                break;
            case 1073741824:
                i5 = size;
                break;
        }
        return i5;
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        setMeasuredDimension(getDefaultSize2(getSuggestedMinimumWidth(), i), getDefaultSize2(getSuggestedMinimumHeight(), i2));
    }
}
