package android.support.p000v4.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.p000v4.media.TransportMediator;
import android.support.p000v4.view.AccessibilityDelegateCompat;
import android.support.p000v4.view.MotionEventCompat;
import android.support.p000v4.view.NestedScrollingChild;
import android.support.p000v4.view.NestedScrollingChildHelper;
import android.support.p000v4.view.NestedScrollingParent;
import android.support.p000v4.view.NestedScrollingParentHelper;
import android.support.p000v4.view.ScrollingView;
import android.support.p000v4.view.ViewCompat;
import android.support.p000v4.view.accessibility.AccessibilityEventCompat;
import android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.support.p000v4.view.accessibility.AccessibilityRecordCompat;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import java.util.ArrayList;

/* renamed from: android.support.v4.widget.NestedScrollView */
public class NestedScrollView extends FrameLayout implements NestedScrollingParent, NestedScrollingChild, ScrollingView {
    private static final AccessibilityDelegate ACCESSIBILITY_DELEGATE;
    static final int ANIMATED_SCROLL_GAP = 250;
    private static final int INVALID_POINTER = -1;
    static final float MAX_SCROLL_FACTOR = 0.5f;
    private static final int[] SCROLLVIEW_STYLEABLE = {16843130};
    private static final String TAG = "NestedScrollView";
    private int mActivePointerId;
    private final NestedScrollingChildHelper mChildHelper;
    private View mChildToScrollTo;
    private EdgeEffectCompat mEdgeGlowBottom;
    private EdgeEffectCompat mEdgeGlowTop;
    private boolean mFillViewport;
    private boolean mIsBeingDragged;
    private boolean mIsLaidOut;
    private boolean mIsLayoutDirty;
    private int mLastMotionY;
    private long mLastScroll;
    private int mMaximumVelocity;
    private int mMinimumVelocity;
    private int mNestedYOffset;
    private OnScrollChangeListener mOnScrollChangeListener;
    private final NestedScrollingParentHelper mParentHelper;
    private SavedState mSavedState;
    private final int[] mScrollConsumed;
    private final int[] mScrollOffset;
    private ScrollerCompat mScroller;
    private boolean mSmoothScrollingEnabled;
    private final Rect mTempRect;
    private int mTouchSlop;
    private VelocityTracker mVelocityTracker;
    private float mVerticalScrollFactor;

    /* renamed from: android.support.v4.widget.NestedScrollView$OnScrollChangeListener */
    public interface OnScrollChangeListener {
        void onScrollChange(NestedScrollView nestedScrollView, int i, int i2, int i3, int i4);
    }

    static {
        AccessibilityDelegate accessibilityDelegate;
        new AccessibilityDelegate();
        ACCESSIBILITY_DELEGATE = accessibilityDelegate;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public NestedScrollView(Context context) {
        this(context, (AttributeSet) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public NestedScrollView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public NestedScrollView(android.content.Context r12, android.util.AttributeSet r13, int r14) {
        /*
            r11 = this;
            r0 = r11
            r1 = r12
            r2 = r13
            r3 = r14
            r5 = r0
            r6 = r1
            r7 = r2
            r8 = r3
            r5.<init>(r6, r7, r8)
            r5 = r0
            android.graphics.Rect r6 = new android.graphics.Rect
            r10 = r6
            r6 = r10
            r7 = r10
            r7.<init>()
            r5.mTempRect = r6
            r5 = r0
            r6 = 1
            r5.mIsLayoutDirty = r6
            r5 = r0
            r6 = 0
            r5.mIsLaidOut = r6
            r5 = r0
            r6 = 0
            r5.mChildToScrollTo = r6
            r5 = r0
            r6 = 0
            r5.mIsBeingDragged = r6
            r5 = r0
            r6 = 1
            r5.mSmoothScrollingEnabled = r6
            r5 = r0
            r6 = -1
            r5.mActivePointerId = r6
            r5 = r0
            r6 = 2
            int[] r6 = new int[r6]
            r5.mScrollOffset = r6
            r5 = r0
            r6 = 2
            int[] r6 = new int[r6]
            r5.mScrollConsumed = r6
            r5 = r0
            r5.initScrollView()
            r5 = r1
            r6 = r2
            int[] r7 = SCROLLVIEW_STYLEABLE
            r8 = r3
            r9 = 0
            android.content.res.TypedArray r5 = r5.obtainStyledAttributes(r6, r7, r8, r9)
            r4 = r5
            r5 = r0
            r6 = r4
            r7 = 0
            r8 = 0
            boolean r6 = r6.getBoolean(r7, r8)
            r5.setFillViewport(r6)
            r5 = r4
            r5.recycle()
            r5 = r0
            android.support.v4.view.NestedScrollingParentHelper r6 = new android.support.v4.view.NestedScrollingParentHelper
            r10 = r6
            r6 = r10
            r7 = r10
            r8 = r0
            r7.<init>(r8)
            r5.mParentHelper = r6
            r5 = r0
            android.support.v4.view.NestedScrollingChildHelper r6 = new android.support.v4.view.NestedScrollingChildHelper
            r10 = r6
            r6 = r10
            r7 = r10
            r8 = r0
            r7.<init>(r8)
            r5.mChildHelper = r6
            r5 = r0
            r6 = 1
            r5.setNestedScrollingEnabled(r6)
            r5 = r0
            android.support.v4.widget.NestedScrollView$AccessibilityDelegate r6 = ACCESSIBILITY_DELEGATE
            android.support.p000v4.view.ViewCompat.setAccessibilityDelegate(r5, r6)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p000v4.widget.NestedScrollView.<init>(android.content.Context, android.util.AttributeSet, int):void");
    }

    public void setNestedScrollingEnabled(boolean z) {
        this.mChildHelper.setNestedScrollingEnabled(z);
    }

    public boolean isNestedScrollingEnabled() {
        return this.mChildHelper.isNestedScrollingEnabled();
    }

    public boolean startNestedScroll(int i) {
        return this.mChildHelper.startNestedScroll(i);
    }

    public void stopNestedScroll() {
        this.mChildHelper.stopNestedScroll();
    }

    public boolean hasNestedScrollingParent() {
        return this.mChildHelper.hasNestedScrollingParent();
    }

    public boolean dispatchNestedScroll(int i, int i2, int i3, int i4, int[] iArr) {
        return this.mChildHelper.dispatchNestedScroll(i, i2, i3, i4, iArr);
    }

    public boolean dispatchNestedPreScroll(int i, int i2, int[] iArr, int[] iArr2) {
        return this.mChildHelper.dispatchNestedPreScroll(i, i2, iArr, iArr2);
    }

    public boolean dispatchNestedFling(float f, float f2, boolean z) {
        return this.mChildHelper.dispatchNestedFling(f, f2, z);
    }

    public boolean dispatchNestedPreFling(float f, float f2) {
        return this.mChildHelper.dispatchNestedPreFling(f, f2);
    }

    public boolean onStartNestedScroll(View view, View view2, int i) {
        View view3 = view;
        View view4 = view2;
        return (i & 2) != 0;
    }

    public void onNestedScrollAccepted(View view, View view2, int i) {
        this.mParentHelper.onNestedScrollAccepted(view, view2, i);
        boolean startNestedScroll = startNestedScroll(2);
    }

    public void onStopNestedScroll(View view) {
        this.mParentHelper.onStopNestedScroll(view);
        stopNestedScroll();
    }

    public void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        View view2 = view;
        int i5 = i;
        int i6 = i2;
        int i7 = i3;
        int i8 = i4;
        int scrollY = getScrollY();
        scrollBy(0, i8);
        int scrollY2 = getScrollY() - scrollY;
        boolean dispatchNestedScroll = dispatchNestedScroll(0, scrollY2, 0, i8 - scrollY2, (int[]) null);
    }

    public void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
    }

    public boolean onNestedFling(View view, float f, float f2, boolean z) {
        View view2 = view;
        float f3 = f;
        float f4 = f2;
        if (z) {
            return false;
        }
        flingWithNestedDispatch((int) f4);
        return true;
    }

    public boolean onNestedPreFling(View view, float f, float f2) {
        View view2 = view;
        float f3 = f;
        float f4 = f2;
        return false;
    }

    public int getNestedScrollAxes() {
        return this.mParentHelper.getNestedScrollAxes();
    }

    public boolean shouldDelayChildPressedState() {
        return true;
    }

    /* access modifiers changed from: protected */
    public float getTopFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int scrollY = getScrollY();
        if (scrollY < verticalFadingEdgeLength) {
            return ((float) scrollY) / ((float) verticalFadingEdgeLength);
        }
        return 1.0f;
    }

    /* access modifiers changed from: protected */
    public float getBottomFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int bottom = (getChildAt(0).getBottom() - getScrollY()) - (getHeight() - getPaddingBottom());
        if (bottom < verticalFadingEdgeLength) {
            return ((float) bottom) / ((float) verticalFadingEdgeLength);
        }
        return 1.0f;
    }

    public int getMaxScrollAmount() {
        return (int) (MAX_SCROLL_FACTOR * ((float) getHeight()));
    }

    private void initScrollView() {
        ScrollerCompat scrollerCompat;
        new ScrollerCompat(getContext(), (Interpolator) null);
        this.mScroller = scrollerCompat;
        setFocusable(true);
        setDescendantFocusability(262144);
        setWillNotDraw(false);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        this.mTouchSlop = viewConfiguration.getScaledTouchSlop();
        this.mMinimumVelocity = viewConfiguration.getScaledMinimumFlingVelocity();
        this.mMaximumVelocity = viewConfiguration.getScaledMaximumFlingVelocity();
    }

    public void addView(View view) {
        Throwable th;
        View view2 = view;
        if (getChildCount() > 0) {
            Throwable th2 = th;
            new IllegalStateException("ScrollView can host only one direct child");
            throw th2;
        }
        super.addView(view2);
    }

    public void addView(View view, int i) {
        Throwable th;
        View view2 = view;
        int i2 = i;
        if (getChildCount() > 0) {
            Throwable th2 = th;
            new IllegalStateException("ScrollView can host only one direct child");
            throw th2;
        }
        super.addView(view2, i2);
    }

    public void addView(View view, ViewGroup.LayoutParams layoutParams) {
        Throwable th;
        View view2 = view;
        ViewGroup.LayoutParams layoutParams2 = layoutParams;
        if (getChildCount() > 0) {
            Throwable th2 = th;
            new IllegalStateException("ScrollView can host only one direct child");
            throw th2;
        }
        super.addView(view2, layoutParams2);
    }

    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        Throwable th;
        View view2 = view;
        int i2 = i;
        ViewGroup.LayoutParams layoutParams2 = layoutParams;
        if (getChildCount() > 0) {
            Throwable th2 = th;
            new IllegalStateException("ScrollView can host only one direct child");
            throw th2;
        }
        super.addView(view2, i2, layoutParams2);
    }

    public void setOnScrollChangeListener(OnScrollChangeListener onScrollChangeListener) {
        OnScrollChangeListener onScrollChangeListener2 = onScrollChangeListener;
        this.mOnScrollChangeListener = onScrollChangeListener2;
    }

    private boolean canScroll() {
        View childAt = getChildAt(0);
        if (childAt == null) {
            return false;
        }
        return getHeight() < (childAt.getHeight() + getPaddingTop()) + getPaddingBottom();
    }

    public boolean isFillViewport() {
        return this.mFillViewport;
    }

    public void setFillViewport(boolean z) {
        boolean z2 = z;
        if (z2 != this.mFillViewport) {
            this.mFillViewport = z2;
            requestLayout();
        }
    }

    public boolean isSmoothScrollingEnabled() {
        return this.mSmoothScrollingEnabled;
    }

    public void setSmoothScrollingEnabled(boolean z) {
        boolean z2 = z;
        this.mSmoothScrollingEnabled = z2;
    }

    /* access modifiers changed from: protected */
    public void onScrollChanged(int i, int i2, int i3, int i4) {
        int i5 = i;
        int i6 = i2;
        int i7 = i3;
        int i8 = i4;
        super.onScrollChanged(i5, i6, i7, i8);
        if (this.mOnScrollChangeListener != null) {
            this.mOnScrollChangeListener.onScrollChange(this, i5, i6, i7, i8);
        }
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        int i3 = i;
        int i4 = i2;
        super.onMeasure(i3, i4);
        if (this.mFillViewport && View.MeasureSpec.getMode(i4) != 0 && getChildCount() > 0) {
            View childAt = getChildAt(0);
            int measuredHeight = getMeasuredHeight();
            if (childAt.getMeasuredHeight() < measuredHeight) {
                childAt.measure(getChildMeasureSpec(i3, getPaddingLeft() + getPaddingRight(), ((FrameLayout.LayoutParams) childAt.getLayoutParams()).width), View.MeasureSpec.makeMeasureSpec((measuredHeight - getPaddingTop()) - getPaddingBottom(), 1073741824));
            }
        }
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        KeyEvent keyEvent2 = keyEvent;
        return super.dispatchKeyEvent(keyEvent2) || executeKeyEvent(keyEvent2);
    }

    public boolean executeKeyEvent(KeyEvent keyEvent) {
        boolean z;
        KeyEvent keyEvent2 = keyEvent;
        this.mTempRect.setEmpty();
        if (canScroll()) {
            boolean z2 = false;
            if (keyEvent2.getAction() == 0) {
                switch (keyEvent2.getKeyCode()) {
                    case 19:
                        if (keyEvent2.isAltPressed()) {
                            z2 = fullScroll(33);
                            break;
                        } else {
                            z2 = arrowScroll(33);
                            break;
                        }
                    case 20:
                        if (keyEvent2.isAltPressed()) {
                            z2 = fullScroll(TransportMediator.KEYCODE_MEDIA_RECORD);
                            break;
                        } else {
                            z2 = arrowScroll(TransportMediator.KEYCODE_MEDIA_RECORD);
                            break;
                        }
                    case 62:
                        boolean pageScroll = pageScroll(keyEvent2.isShiftPressed() ? 33 : TransportMediator.KEYCODE_MEDIA_RECORD);
                        break;
                }
            }
            return z2;
        } else if (!isFocused() || keyEvent2.getKeyCode() == 4) {
            return false;
        } else {
            View findFocus = findFocus();
            if (findFocus == this) {
                findFocus = null;
            }
            View findNextFocus = FocusFinder.getInstance().findNextFocus(this, findFocus, TransportMediator.KEYCODE_MEDIA_RECORD);
            if (findNextFocus == null || findNextFocus == this || !findNextFocus.requestFocus(TransportMediator.KEYCODE_MEDIA_RECORD)) {
                z = false;
            } else {
                z = true;
            }
            return z;
        }
    }

    private boolean inChild(int i, int i2) {
        int i3 = i;
        int i4 = i2;
        if (getChildCount() <= 0) {
            return false;
        }
        int scrollY = getScrollY();
        View childAt = getChildAt(0);
        return i4 >= childAt.getTop() - scrollY && i4 < childAt.getBottom() - scrollY && i3 >= childAt.getLeft() && i3 < childAt.getRight();
    }

    private void initOrResetVelocityTracker() {
        if (this.mVelocityTracker == null) {
            this.mVelocityTracker = VelocityTracker.obtain();
            return;
        }
        this.mVelocityTracker.clear();
    }

    private void initVelocityTrackerIfNotExists() {
        if (this.mVelocityTracker == null) {
            this.mVelocityTracker = VelocityTracker.obtain();
        }
    }

    private void recycleVelocityTracker() {
        if (this.mVelocityTracker != null) {
            this.mVelocityTracker.recycle();
            this.mVelocityTracker = null;
        }
    }

    public void requestDisallowInterceptTouchEvent(boolean z) {
        boolean z2 = z;
        if (z2) {
            recycleVelocityTracker();
        }
        super.requestDisallowInterceptTouchEvent(z2);
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        StringBuilder sb;
        MotionEvent motionEvent2 = motionEvent;
        int action = motionEvent2.getAction();
        if (action == 2 && this.mIsBeingDragged) {
            return true;
        }
        switch (action & 255) {
            case 0:
                int y = (int) motionEvent2.getY();
                if (inChild((int) motionEvent2.getX(), y)) {
                    this.mLastMotionY = y;
                    this.mActivePointerId = MotionEventCompat.getPointerId(motionEvent2, 0);
                    initOrResetVelocityTracker();
                    this.mVelocityTracker.addMovement(motionEvent2);
                    this.mIsBeingDragged = !this.mScroller.isFinished();
                    boolean startNestedScroll = startNestedScroll(2);
                    break;
                } else {
                    this.mIsBeingDragged = false;
                    recycleVelocityTracker();
                    break;
                }
            case 1:
            case 3:
                this.mIsBeingDragged = false;
                this.mActivePointerId = -1;
                recycleVelocityTracker();
                if (this.mScroller.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                    ViewCompat.postInvalidateOnAnimation(this);
                }
                stopNestedScroll();
                break;
            case 2:
                int i = this.mActivePointerId;
                if (i != -1) {
                    int findPointerIndex = MotionEventCompat.findPointerIndex(motionEvent2, i);
                    if (findPointerIndex != -1) {
                        int y2 = (int) MotionEventCompat.getY(motionEvent2, findPointerIndex);
                        if (Math.abs(y2 - this.mLastMotionY) > this.mTouchSlop && (getNestedScrollAxes() & 2) == 0) {
                            this.mIsBeingDragged = true;
                            this.mLastMotionY = y2;
                            initVelocityTrackerIfNotExists();
                            this.mVelocityTracker.addMovement(motionEvent2);
                            this.mNestedYOffset = 0;
                            ViewParent parent = getParent();
                            if (parent != null) {
                                parent.requestDisallowInterceptTouchEvent(true);
                                break;
                            }
                        }
                    } else {
                        new StringBuilder();
                        int e = Log.e(TAG, sb.append("Invalid pointerId=").append(i).append(" in onInterceptTouchEvent").toString());
                        break;
                    }
                }
                break;
            case 6:
                onSecondaryPointerUp(motionEvent2);
                break;
        }
        return this.mIsBeingDragged;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:72:0x03b0, code lost:
        if (r2.mEdgeGlowBottom.isFinished() == false) goto L_0x03b2;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouchEvent(android.view.MotionEvent r29) {
        /*
            r28 = this;
            r2 = r28
            r3 = r29
            r16 = r2
            r16.initVelocityTrackerIfNotExists()
            r16 = r3
            android.view.MotionEvent r16 = android.view.MotionEvent.obtain(r16)
            r4 = r16
            r16 = r3
            int r16 = android.support.p000v4.view.MotionEventCompat.getActionMasked(r16)
            r5 = r16
            r16 = r5
            if (r16 != 0) goto L_0x0027
            r16 = r2
            r17 = 0
            r0 = r17
            r1 = r16
            r1.mNestedYOffset = r0
        L_0x0027:
            r16 = r4
            r17 = 0
            r18 = r2
            r0 = r18
            int r0 = r0.mNestedYOffset
            r18 = r0
            r0 = r18
            float r0 = (float) r0
            r18 = r0
            r16.offsetLocation(r17, r18)
            r16 = r5
            switch(r16) {
                case 0: goto L_0x0061;
                case 1: goto L_0x0418;
                case 2: goto L_0x00ee;
                case 3: goto L_0x04b2;
                case 4: goto L_0x0040;
                case 5: goto L_0x0500;
                case 6: goto L_0x052f;
                default: goto L_0x0040;
            }
        L_0x0040:
            r16 = r2
            r0 = r16
            android.view.VelocityTracker r0 = r0.mVelocityTracker
            r16 = r0
            if (r16 == 0) goto L_0x0057
            r16 = r2
            r0 = r16
            android.view.VelocityTracker r0 = r0.mVelocityTracker
            r16 = r0
            r17 = r4
            r16.addMovement(r17)
        L_0x0057:
            r16 = r4
            r16.recycle()
            r16 = 1
            r2 = r16
        L_0x0060:
            return r2
        L_0x0061:
            r16 = r2
            int r16 = r16.getChildCount()
            if (r16 != 0) goto L_0x006e
            r16 = 0
            r2 = r16
            goto L_0x0060
        L_0x006e:
            r16 = r2
            r17 = r2
            r0 = r17
            android.support.v4.widget.ScrollerCompat r0 = r0.mScroller
            r17 = r0
            boolean r17 = r17.isFinished()
            if (r17 != 0) goto L_0x00eb
            r17 = 1
        L_0x0080:
            r26 = r16
            r27 = r17
            r16 = r27
            r17 = r26
            r18 = r27
            r0 = r18
            r1 = r17
            r1.mIsBeingDragged = r0
            if (r16 == 0) goto L_0x00a5
            r16 = r2
            android.view.ViewParent r16 = r16.getParent()
            r6 = r16
            r16 = r6
            if (r16 == 0) goto L_0x00a5
            r16 = r6
            r17 = 1
            r16.requestDisallowInterceptTouchEvent(r17)
        L_0x00a5:
            r16 = r2
            r0 = r16
            android.support.v4.widget.ScrollerCompat r0 = r0.mScroller
            r16 = r0
            boolean r16 = r16.isFinished()
            if (r16 != 0) goto L_0x00be
            r16 = r2
            r0 = r16
            android.support.v4.widget.ScrollerCompat r0 = r0.mScroller
            r16 = r0
            r16.abortAnimation()
        L_0x00be:
            r16 = r2
            r17 = r3
            float r17 = r17.getY()
            r0 = r17
            int r0 = (int) r0
            r17 = r0
            r0 = r17
            r1 = r16
            r1.mLastMotionY = r0
            r16 = r2
            r17 = r3
            r18 = 0
            int r17 = android.support.p000v4.view.MotionEventCompat.getPointerId(r17, r18)
            r0 = r17
            r1 = r16
            r1.mActivePointerId = r0
            r16 = r2
            r17 = 2
            boolean r16 = r16.startNestedScroll(r17)
            goto L_0x0040
        L_0x00eb:
            r17 = 0
            goto L_0x0080
        L_0x00ee:
            r16 = r3
            r17 = r2
            r0 = r17
            int r0 = r0.mActivePointerId
            r17 = r0
            int r16 = android.support.p000v4.view.MotionEventCompat.findPointerIndex(r16, r17)
            r6 = r16
            r16 = r6
            r17 = -1
            r0 = r16
            r1 = r17
            if (r0 != r1) goto L_0x0137
            java.lang.String r16 = "NestedScrollView"
            java.lang.StringBuilder r17 = new java.lang.StringBuilder
            r26 = r17
            r17 = r26
            r18 = r26
            r18.<init>()
            java.lang.String r18 = "Invalid pointerId="
            java.lang.StringBuilder r17 = r17.append(r18)
            r18 = r2
            r0 = r18
            int r0 = r0.mActivePointerId
            r18 = r0
            java.lang.StringBuilder r17 = r17.append(r18)
            java.lang.String r18 = " in onTouchEvent"
            java.lang.StringBuilder r17 = r17.append(r18)
            java.lang.String r17 = r17.toString()
            int r16 = android.util.Log.e(r16, r17)
            goto L_0x0040
        L_0x0137:
            r16 = r3
            r17 = r6
            float r16 = android.support.p000v4.view.MotionEventCompat.getY(r16, r17)
            r0 = r16
            int r0 = (int) r0
            r16 = r0
            r7 = r16
            r16 = r2
            r0 = r16
            int r0 = r0.mLastMotionY
            r16 = r0
            r17 = r7
            int r16 = r16 - r17
            r8 = r16
            r16 = r2
            r17 = 0
            r18 = r8
            r19 = r2
            r0 = r19
            int[] r0 = r0.mScrollConsumed
            r19 = r0
            r20 = r2
            r0 = r20
            int[] r0 = r0.mScrollOffset
            r20 = r0
            boolean r16 = r16.dispatchNestedPreScroll(r17, r18, r19, r20)
            if (r16 == 0) goto L_0x01bc
            r16 = r8
            r17 = r2
            r0 = r17
            int[] r0 = r0.mScrollConsumed
            r17 = r0
            r18 = 1
            r17 = r17[r18]
            int r16 = r16 - r17
            r8 = r16
            r16 = r4
            r17 = 0
            r18 = r2
            r0 = r18
            int[] r0 = r0.mScrollOffset
            r18 = r0
            r19 = 1
            r18 = r18[r19]
            r0 = r18
            float r0 = (float) r0
            r18 = r0
            r16.offsetLocation(r17, r18)
            r16 = r2
            r26 = r16
            r16 = r26
            r17 = r26
            r0 = r17
            int r0 = r0.mNestedYOffset
            r17 = r0
            r18 = r2
            r0 = r18
            int[] r0 = r0.mScrollOffset
            r18 = r0
            r19 = 1
            r18 = r18[r19]
            int r17 = r17 + r18
            r0 = r17
            r1 = r16
            r1.mNestedYOffset = r0
        L_0x01bc:
            r16 = r2
            r0 = r16
            boolean r0 = r0.mIsBeingDragged
            r16 = r0
            if (r16 != 0) goto L_0x0209
            r16 = r8
            int r16 = java.lang.Math.abs(r16)
            r17 = r2
            r0 = r17
            int r0 = r0.mTouchSlop
            r17 = r0
            r0 = r16
            r1 = r17
            if (r0 <= r1) goto L_0x0209
            r16 = r2
            android.view.ViewParent r16 = r16.getParent()
            r9 = r16
            r16 = r9
            if (r16 == 0) goto L_0x01ed
            r16 = r9
            r17 = 1
            r16.requestDisallowInterceptTouchEvent(r17)
        L_0x01ed:
            r16 = r2
            r17 = 1
            r0 = r17
            r1 = r16
            r1.mIsBeingDragged = r0
            r16 = r8
            if (r16 <= 0) goto L_0x0314
            r16 = r8
            r17 = r2
            r0 = r17
            int r0 = r0.mTouchSlop
            r17 = r0
            int r16 = r16 - r17
            r8 = r16
        L_0x0209:
            r16 = r2
            r0 = r16
            boolean r0 = r0.mIsBeingDragged
            r16 = r0
            if (r16 == 0) goto L_0x0040
            r16 = r2
            r17 = r7
            r18 = r2
            r0 = r18
            int[] r0 = r0.mScrollOffset
            r18 = r0
            r19 = 1
            r18 = r18[r19]
            int r17 = r17 - r18
            r0 = r17
            r1 = r16
            r1.mLastMotionY = r0
            r16 = r2
            int r16 = r16.getScrollY()
            r9 = r16
            r16 = r2
            int r16 = r16.getScrollRange()
            r10 = r16
            r16 = r2
            int r16 = android.support.p000v4.view.ViewCompat.getOverScrollMode(r16)
            r11 = r16
            r16 = r11
            if (r16 == 0) goto L_0x0255
            r16 = r11
            r17 = 1
            r0 = r16
            r1 = r17
            if (r0 != r1) goto L_0x0324
            r16 = r10
            if (r16 <= 0) goto L_0x0324
        L_0x0255:
            r16 = 1
        L_0x0257:
            r12 = r16
            r16 = r2
            r17 = 0
            r18 = r8
            r19 = 0
            r20 = r2
            int r20 = r20.getScrollY()
            r21 = 0
            r22 = r10
            r23 = 0
            r24 = 0
            r25 = 1
            boolean r16 = r16.overScrollByCompat(r17, r18, r19, r20, r21, r22, r23, r24, r25)
            if (r16 == 0) goto L_0x028a
            r16 = r2
            boolean r16 = r16.hasNestedScrollingParent()
            if (r16 != 0) goto L_0x028a
            r16 = r2
            r0 = r16
            android.view.VelocityTracker r0 = r0.mVelocityTracker
            r16 = r0
            r16.clear()
        L_0x028a:
            r16 = r2
            int r16 = r16.getScrollY()
            r17 = r9
            int r16 = r16 - r17
            r13 = r16
            r16 = r8
            r17 = r13
            int r16 = r16 - r17
            r14 = r16
            r16 = r2
            r17 = 0
            r18 = r13
            r19 = 0
            r20 = r14
            r21 = r2
            r0 = r21
            int[] r0 = r0.mScrollOffset
            r21 = r0
            boolean r16 = r16.dispatchNestedScroll(r17, r18, r19, r20, r21)
            if (r16 == 0) goto L_0x0328
            r16 = r2
            r26 = r16
            r16 = r26
            r17 = r26
            r0 = r17
            int r0 = r0.mLastMotionY
            r17 = r0
            r18 = r2
            r0 = r18
            int[] r0 = r0.mScrollOffset
            r18 = r0
            r19 = 1
            r18 = r18[r19]
            int r17 = r17 - r18
            r0 = r17
            r1 = r16
            r1.mLastMotionY = r0
            r16 = r4
            r17 = 0
            r18 = r2
            r0 = r18
            int[] r0 = r0.mScrollOffset
            r18 = r0
            r19 = 1
            r18 = r18[r19]
            r0 = r18
            float r0 = (float) r0
            r18 = r0
            r16.offsetLocation(r17, r18)
            r16 = r2
            r26 = r16
            r16 = r26
            r17 = r26
            r0 = r17
            int r0 = r0.mNestedYOffset
            r17 = r0
            r18 = r2
            r0 = r18
            int[] r0 = r0.mScrollOffset
            r18 = r0
            r19 = 1
            r18 = r18[r19]
            int r17 = r17 + r18
            r0 = r17
            r1 = r16
            r1.mNestedYOffset = r0
        L_0x0312:
            goto L_0x0040
        L_0x0314:
            r16 = r8
            r17 = r2
            r0 = r17
            int r0 = r0.mTouchSlop
            r17 = r0
            int r16 = r16 + r17
            r8 = r16
            goto L_0x0209
        L_0x0324:
            r16 = 0
            goto L_0x0257
        L_0x0328:
            r16 = r12
            if (r16 == 0) goto L_0x0312
            r16 = r2
            r16.ensureGlows()
            r16 = r9
            r17 = r8
            int r16 = r16 + r17
            r15 = r16
            r16 = r15
            if (r16 >= 0) goto L_0x03b9
            r16 = r2
            r0 = r16
            android.support.v4.widget.EdgeEffectCompat r0 = r0.mEdgeGlowTop
            r16 = r0
            r17 = r8
            r0 = r17
            float r0 = (float) r0
            r17 = r0
            r18 = r2
            int r18 = r18.getHeight()
            r0 = r18
            float r0 = (float) r0
            r18 = r0
            float r17 = r17 / r18
            r18 = r3
            r19 = r6
            float r18 = android.support.p000v4.view.MotionEventCompat.getX(r18, r19)
            r19 = r2
            int r19 = r19.getWidth()
            r0 = r19
            float r0 = (float) r0
            r19 = r0
            float r18 = r18 / r19
            boolean r16 = r16.onPull(r17, r18)
            r16 = r2
            r0 = r16
            android.support.v4.widget.EdgeEffectCompat r0 = r0.mEdgeGlowBottom
            r16 = r0
            boolean r16 = r16.isFinished()
            if (r16 != 0) goto L_0x038c
            r16 = r2
            r0 = r16
            android.support.v4.widget.EdgeEffectCompat r0 = r0.mEdgeGlowBottom
            r16 = r0
            boolean r16 = r16.onRelease()
        L_0x038c:
            r16 = r2
            r0 = r16
            android.support.v4.widget.EdgeEffectCompat r0 = r0.mEdgeGlowTop
            r16 = r0
            if (r16 == 0) goto L_0x0312
            r16 = r2
            r0 = r16
            android.support.v4.widget.EdgeEffectCompat r0 = r0.mEdgeGlowTop
            r16 = r0
            boolean r16 = r16.isFinished()
            if (r16 == 0) goto L_0x03b2
            r16 = r2
            r0 = r16
            android.support.v4.widget.EdgeEffectCompat r0 = r0.mEdgeGlowBottom
            r16 = r0
            boolean r16 = r16.isFinished()
            if (r16 != 0) goto L_0x0312
        L_0x03b2:
            r16 = r2
            android.support.p000v4.view.ViewCompat.postInvalidateOnAnimation(r16)
            goto L_0x0312
        L_0x03b9:
            r16 = r15
            r17 = r10
            r0 = r16
            r1 = r17
            if (r0 <= r1) goto L_0x038c
            r16 = r2
            r0 = r16
            android.support.v4.widget.EdgeEffectCompat r0 = r0.mEdgeGlowBottom
            r16 = r0
            r17 = r8
            r0 = r17
            float r0 = (float) r0
            r17 = r0
            r18 = r2
            int r18 = r18.getHeight()
            r0 = r18
            float r0 = (float) r0
            r18 = r0
            float r17 = r17 / r18
            r18 = 1065353216(0x3f800000, float:1.0)
            r19 = r3
            r20 = r6
            float r19 = android.support.p000v4.view.MotionEventCompat.getX(r19, r20)
            r20 = r2
            int r20 = r20.getWidth()
            r0 = r20
            float r0 = (float) r0
            r20 = r0
            float r19 = r19 / r20
            float r18 = r18 - r19
            boolean r16 = r16.onPull(r17, r18)
            r16 = r2
            r0 = r16
            android.support.v4.widget.EdgeEffectCompat r0 = r0.mEdgeGlowTop
            r16 = r0
            boolean r16 = r16.isFinished()
            if (r16 != 0) goto L_0x038c
            r16 = r2
            r0 = r16
            android.support.v4.widget.EdgeEffectCompat r0 = r0.mEdgeGlowTop
            r16 = r0
            boolean r16 = r16.onRelease()
            goto L_0x038c
        L_0x0418:
            r16 = r2
            r0 = r16
            boolean r0 = r0.mIsBeingDragged
            r16 = r0
            if (r16 == 0) goto L_0x0475
            r16 = r2
            r0 = r16
            android.view.VelocityTracker r0 = r0.mVelocityTracker
            r16 = r0
            r9 = r16
            r16 = r9
            r17 = 1000(0x3e8, float:1.401E-42)
            r18 = r2
            r0 = r18
            int r0 = r0.mMaximumVelocity
            r18 = r0
            r0 = r18
            float r0 = (float) r0
            r18 = r0
            r16.computeCurrentVelocity(r17, r18)
            r16 = r9
            r17 = r2
            r0 = r17
            int r0 = r0.mActivePointerId
            r17 = r0
            float r16 = android.support.p000v4.view.VelocityTrackerCompat.getYVelocity(r16, r17)
            r0 = r16
            int r0 = (int) r0
            r16 = r0
            r10 = r16
            r16 = r10
            int r16 = java.lang.Math.abs(r16)
            r17 = r2
            r0 = r17
            int r0 = r0.mMinimumVelocity
            r17 = r0
            r0 = r16
            r1 = r17
            if (r0 <= r1) goto L_0x0486
            r16 = r2
            r17 = r10
            r0 = r17
            int r0 = -r0
            r17 = r0
            r16.flingWithNestedDispatch(r17)
        L_0x0475:
            r16 = r2
            r17 = -1
            r0 = r17
            r1 = r16
            r1.mActivePointerId = r0
            r16 = r2
            r16.endDrag()
            goto L_0x0040
        L_0x0486:
            r16 = r2
            r0 = r16
            android.support.v4.widget.ScrollerCompat r0 = r0.mScroller
            r16 = r0
            r17 = r2
            int r17 = r17.getScrollX()
            r18 = r2
            int r18 = r18.getScrollY()
            r19 = 0
            r20 = 0
            r21 = 0
            r22 = r2
            int r22 = r22.getScrollRange()
            boolean r16 = r16.springBack(r17, r18, r19, r20, r21, r22)
            if (r16 == 0) goto L_0x0475
            r16 = r2
            android.support.p000v4.view.ViewCompat.postInvalidateOnAnimation(r16)
            goto L_0x0475
        L_0x04b2:
            r16 = r2
            r0 = r16
            boolean r0 = r0.mIsBeingDragged
            r16 = r0
            if (r16 == 0) goto L_0x04ef
            r16 = r2
            int r16 = r16.getChildCount()
            if (r16 <= 0) goto L_0x04ef
            r16 = r2
            r0 = r16
            android.support.v4.widget.ScrollerCompat r0 = r0.mScroller
            r16 = r0
            r17 = r2
            int r17 = r17.getScrollX()
            r18 = r2
            int r18 = r18.getScrollY()
            r19 = 0
            r20 = 0
            r21 = 0
            r22 = r2
            int r22 = r22.getScrollRange()
            boolean r16 = r16.springBack(r17, r18, r19, r20, r21, r22)
            if (r16 == 0) goto L_0x04ef
            r16 = r2
            android.support.p000v4.view.ViewCompat.postInvalidateOnAnimation(r16)
        L_0x04ef:
            r16 = r2
            r17 = -1
            r0 = r17
            r1 = r16
            r1.mActivePointerId = r0
            r16 = r2
            r16.endDrag()
            goto L_0x0040
        L_0x0500:
            r16 = r3
            int r16 = android.support.p000v4.view.MotionEventCompat.getActionIndex(r16)
            r9 = r16
            r16 = r2
            r17 = r3
            r18 = r9
            float r17 = android.support.p000v4.view.MotionEventCompat.getY(r17, r18)
            r0 = r17
            int r0 = (int) r0
            r17 = r0
            r0 = r17
            r1 = r16
            r1.mLastMotionY = r0
            r16 = r2
            r17 = r3
            r18 = r9
            int r17 = android.support.p000v4.view.MotionEventCompat.getPointerId(r17, r18)
            r0 = r17
            r1 = r16
            r1.mActivePointerId = r0
            goto L_0x0040
        L_0x052f:
            r16 = r2
            r17 = r3
            r16.onSecondaryPointerUp(r17)
            r16 = r2
            r17 = r3
            r18 = r3
            r19 = r2
            r0 = r19
            int r0 = r0.mActivePointerId
            r19 = r0
            int r18 = android.support.p000v4.view.MotionEventCompat.findPointerIndex(r18, r19)
            float r17 = android.support.p000v4.view.MotionEventCompat.getY(r17, r18)
            r0 = r17
            int r0 = (int) r0
            r17 = r0
            r0 = r17
            r1 = r16
            r1.mLastMotionY = r0
            goto L_0x0040
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p000v4.widget.NestedScrollView.onTouchEvent(android.view.MotionEvent):boolean");
    }

    private void onSecondaryPointerUp(MotionEvent motionEvent) {
        MotionEvent motionEvent2 = motionEvent;
        int action = (motionEvent2.getAction() & MotionEventCompat.ACTION_POINTER_INDEX_MASK) >> 8;
        if (MotionEventCompat.getPointerId(motionEvent2, action) == this.mActivePointerId) {
            int i = action == 0 ? 1 : 0;
            this.mLastMotionY = (int) MotionEventCompat.getY(motionEvent2, i);
            this.mActivePointerId = MotionEventCompat.getPointerId(motionEvent2, i);
            if (this.mVelocityTracker != null) {
                this.mVelocityTracker.clear();
            }
        }
    }

    public boolean onGenericMotionEvent(MotionEvent motionEvent) {
        MotionEvent motionEvent2 = motionEvent;
        if ((MotionEventCompat.getSource(motionEvent2) & 2) != 0) {
            switch (motionEvent2.getAction()) {
                case 8:
                    if (!this.mIsBeingDragged) {
                        float axisValue = MotionEventCompat.getAxisValue(motionEvent2, 9);
                        if (axisValue != 0.0f) {
                            int verticalScrollFactorCompat = (int) (axisValue * getVerticalScrollFactorCompat());
                            int scrollRange = getScrollRange();
                            int scrollY = getScrollY();
                            int i = scrollY - verticalScrollFactorCompat;
                            if (i < 0) {
                                i = 0;
                            } else if (i > scrollRange) {
                                i = scrollRange;
                            }
                            if (i != scrollY) {
                                super.scrollTo(getScrollX(), i);
                                return true;
                            }
                        }
                    }
                    break;
            }
        }
        return false;
    }

    private float getVerticalScrollFactorCompat() {
        TypedValue typedValue;
        Throwable th;
        if (this.mVerticalScrollFactor == 0.0f) {
            new TypedValue();
            TypedValue typedValue2 = typedValue;
            Context context = getContext();
            if (!context.getTheme().resolveAttribute(16842829, typedValue2, true)) {
                Throwable th2 = th;
                new IllegalStateException("Expected theme to define listPreferredItemHeight.");
                throw th2;
            }
            this.mVerticalScrollFactor = typedValue2.getDimension(context.getResources().getDisplayMetrics());
        }
        return this.mVerticalScrollFactor;
    }

    /* access modifiers changed from: protected */
    public void onOverScrolled(int i, int i2, boolean z, boolean z2) {
        boolean z3 = z;
        boolean z4 = z2;
        super.scrollTo(i, i2);
    }

    /* access modifiers changed from: package-private */
    public boolean overScrollByCompat(int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8, boolean z) {
        boolean z2;
        int i9 = i;
        int i10 = i2;
        int i11 = i3;
        int i12 = i4;
        int i13 = i5;
        int i14 = i6;
        int i15 = i7;
        int i16 = i8;
        boolean z3 = z;
        int overScrollMode = ViewCompat.getOverScrollMode(this);
        boolean z4 = computeHorizontalScrollRange() > computeHorizontalScrollExtent();
        boolean z5 = computeVerticalScrollRange() > computeVerticalScrollExtent();
        boolean z6 = overScrollMode == 0 || (overScrollMode == 1 && z4);
        boolean z7 = overScrollMode == 0 || (overScrollMode == 1 && z5);
        int i17 = i11 + i9;
        if (!z6) {
            i15 = 0;
        }
        int i18 = i12 + i10;
        if (!z7) {
            i16 = 0;
        }
        int i19 = -i15;
        int i20 = i15 + i13;
        int i21 = -i16;
        int i22 = i16 + i14;
        boolean z8 = false;
        if (i17 > i20) {
            i17 = i20;
            z8 = true;
        } else if (i17 < i19) {
            i17 = i19;
            z8 = true;
        }
        boolean z9 = false;
        if (i18 > i22) {
            i18 = i22;
            z9 = true;
        } else if (i18 < i21) {
            i18 = i21;
            z9 = true;
        }
        if (z9) {
            boolean springBack = this.mScroller.springBack(i17, i18, 0, 0, 0, getScrollRange());
        }
        onOverScrolled(i17, i18, z8, z9);
        if (z8 || z9) {
            z2 = true;
        } else {
            z2 = false;
        }
        return z2;
    }

    /* access modifiers changed from: private */
    public int getScrollRange() {
        int i = 0;
        if (getChildCount() > 0) {
            i = Math.max(0, getChildAt(0).getHeight() - ((getHeight() - getPaddingBottom()) - getPaddingTop()));
        }
        return i;
    }

    private View findFocusableViewInBounds(boolean z, int i, int i2) {
        boolean z2 = z;
        int i3 = i;
        int i4 = i2;
        ArrayList focusables = getFocusables(2);
        View view = null;
        boolean z3 = false;
        int size = focusables.size();
        for (int i5 = 0; i5 < size; i5++) {
            View view2 = (View) focusables.get(i5);
            int top = view2.getTop();
            int bottom = view2.getBottom();
            if (i3 < bottom && top < i4) {
                boolean z4 = i3 < top && bottom < i4;
                if (view == null) {
                    view = view2;
                    z3 = z4;
                } else {
                    boolean z5 = (z2 && top < view.getTop()) || (!z2 && bottom > view.getBottom());
                    if (z3) {
                        if (z4 && z5) {
                            view = view2;
                        }
                    } else if (z4) {
                        view = view2;
                        z3 = true;
                    } else if (z5) {
                        view = view2;
                    }
                }
            }
        }
        return view;
    }

    public boolean pageScroll(int i) {
        int i2 = i;
        boolean z = i2 == 130;
        int height = getHeight();
        if (z) {
            this.mTempRect.top = getScrollY() + height;
            int childCount = getChildCount();
            if (childCount > 0) {
                View childAt = getChildAt(childCount - 1);
                if (this.mTempRect.top + height > childAt.getBottom()) {
                    this.mTempRect.top = childAt.getBottom() - height;
                }
            }
        } else {
            this.mTempRect.top = getScrollY() - height;
            if (this.mTempRect.top < 0) {
                this.mTempRect.top = 0;
            }
        }
        this.mTempRect.bottom = this.mTempRect.top + height;
        return scrollAndFocus(i2, this.mTempRect.top, this.mTempRect.bottom);
    }

    public boolean fullScroll(int i) {
        int childCount;
        int i2 = i;
        boolean z = i2 == 130;
        int height = getHeight();
        this.mTempRect.top = 0;
        this.mTempRect.bottom = height;
        if (z && (childCount = getChildCount()) > 0) {
            this.mTempRect.bottom = getChildAt(childCount - 1).getBottom() + getPaddingBottom();
            this.mTempRect.top = this.mTempRect.bottom - height;
        }
        return scrollAndFocus(i2, this.mTempRect.top, this.mTempRect.bottom);
    }

    private boolean scrollAndFocus(int i, int i2, int i3) {
        int i4 = i;
        int i5 = i2;
        int i6 = i3;
        boolean z = true;
        int height = getHeight();
        int scrollY = getScrollY();
        int i7 = scrollY + height;
        boolean z2 = i4 == 33;
        View findFocusableViewInBounds = findFocusableViewInBounds(z2, i5, i6);
        if (findFocusableViewInBounds == null) {
            findFocusableViewInBounds = this;
        }
        if (i5 < scrollY || i6 > i7) {
            doScrollY(z2 ? i5 - scrollY : i6 - i7);
        } else {
            z = false;
        }
        if (findFocusableViewInBounds != findFocus()) {
            boolean requestFocus = findFocusableViewInBounds.requestFocus(i4);
        }
        return z;
    }

    public boolean arrowScroll(int i) {
        int i2 = i;
        View findFocus = findFocus();
        if (findFocus == this) {
            findFocus = null;
        }
        View findNextFocus = FocusFinder.getInstance().findNextFocus(this, findFocus, i2);
        int maxScrollAmount = getMaxScrollAmount();
        if (findNextFocus == null || !isWithinDeltaOfScreen(findNextFocus, maxScrollAmount, getHeight())) {
            int i3 = maxScrollAmount;
            if (i2 == 33 && getScrollY() < i3) {
                i3 = getScrollY();
            } else if (i2 == 130 && getChildCount() > 0) {
                int bottom = getChildAt(0).getBottom();
                int scrollY = (getScrollY() + getHeight()) - getPaddingBottom();
                if (bottom - scrollY < maxScrollAmount) {
                    i3 = bottom - scrollY;
                }
            }
            if (i3 == 0) {
                return false;
            }
            doScrollY(i2 == 130 ? i3 : -i3);
        } else {
            findNextFocus.getDrawingRect(this.mTempRect);
            offsetDescendantRectToMyCoords(findNextFocus, this.mTempRect);
            doScrollY(computeScrollDeltaToGetChildRectOnScreen(this.mTempRect));
            boolean requestFocus = findNextFocus.requestFocus(i2);
        }
        if (findFocus != null && findFocus.isFocused() && isOffScreen(findFocus)) {
            int descendantFocusability = getDescendantFocusability();
            setDescendantFocusability(131072);
            boolean requestFocus2 = requestFocus();
            setDescendantFocusability(descendantFocusability);
        }
        return true;
    }

    private boolean isOffScreen(View view) {
        return !isWithinDeltaOfScreen(view, 0, getHeight());
    }

    private boolean isWithinDeltaOfScreen(View view, int i, int i2) {
        View view2 = view;
        int i3 = i;
        int i4 = i2;
        view2.getDrawingRect(this.mTempRect);
        offsetDescendantRectToMyCoords(view2, this.mTempRect);
        return this.mTempRect.bottom + i3 >= getScrollY() && this.mTempRect.top - i3 <= getScrollY() + i4;
    }

    private void doScrollY(int i) {
        int i2 = i;
        if (i2 == 0) {
            return;
        }
        if (this.mSmoothScrollingEnabled) {
            smoothScrollBy(0, i2);
        } else {
            scrollBy(0, i2);
        }
    }

    public final void smoothScrollBy(int i, int i2) {
        int i3 = i;
        int i4 = i2;
        if (getChildCount() != 0) {
            if (AnimationUtils.currentAnimationTimeMillis() - this.mLastScroll > 250) {
                int max = Math.max(0, getChildAt(0).getHeight() - ((getHeight() - getPaddingBottom()) - getPaddingTop()));
                int scrollY = getScrollY();
                this.mScroller.startScroll(getScrollX(), scrollY, 0, Math.max(0, Math.min(scrollY + i4, max)) - scrollY);
                ViewCompat.postInvalidateOnAnimation(this);
            } else {
                if (!this.mScroller.isFinished()) {
                    this.mScroller.abortAnimation();
                }
                scrollBy(i3, i4);
            }
            this.mLastScroll = AnimationUtils.currentAnimationTimeMillis();
        }
    }

    public final void smoothScrollTo(int i, int i2) {
        smoothScrollBy(i - getScrollX(), i2 - getScrollY());
    }

    public int computeVerticalScrollRange() {
        int childCount = getChildCount();
        int height = (getHeight() - getPaddingBottom()) - getPaddingTop();
        if (childCount == 0) {
            return height;
        }
        int bottom = getChildAt(0).getBottom();
        int scrollY = getScrollY();
        int max = Math.max(0, bottom - height);
        if (scrollY < 0) {
            bottom -= scrollY;
        } else if (scrollY > max) {
            bottom += scrollY - max;
        }
        return bottom;
    }

    public int computeVerticalScrollOffset() {
        return Math.max(0, super.computeVerticalScrollOffset());
    }

    public int computeVerticalScrollExtent() {
        return super.computeVerticalScrollExtent();
    }

    public int computeHorizontalScrollRange() {
        return super.computeHorizontalScrollRange();
    }

    public int computeHorizontalScrollOffset() {
        return super.computeHorizontalScrollOffset();
    }

    public int computeHorizontalScrollExtent() {
        return super.computeHorizontalScrollExtent();
    }

    /* access modifiers changed from: protected */
    public void measureChild(View view, int i, int i2) {
        View view2 = view;
        int i3 = i2;
        view2.measure(getChildMeasureSpec(i, getPaddingLeft() + getPaddingRight(), view2.getLayoutParams().width), View.MeasureSpec.makeMeasureSpec(0, 0));
    }

    /* access modifiers changed from: protected */
    public void measureChildWithMargins(View view, int i, int i2, int i3, int i4) {
        View view2 = view;
        int i5 = i3;
        int i6 = i4;
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view2.getLayoutParams();
        view2.measure(getChildMeasureSpec(i, getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i2, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
    }

    public void computeScroll() {
        if (this.mScroller.computeScrollOffset()) {
            int scrollX = getScrollX();
            int scrollY = getScrollY();
            int currX = this.mScroller.getCurrX();
            int currY = this.mScroller.getCurrY();
            if (scrollX != currX || scrollY != currY) {
                int scrollRange = getScrollRange();
                int overScrollMode = ViewCompat.getOverScrollMode(this);
                boolean z = overScrollMode == 0 || (overScrollMode == 1 && scrollRange > 0);
                boolean overScrollByCompat = overScrollByCompat(currX - scrollX, currY - scrollY, scrollX, scrollY, 0, scrollRange, 0, 0, false);
                if (z) {
                    ensureGlows();
                    if (currY <= 0 && scrollY > 0) {
                        boolean onAbsorb = this.mEdgeGlowTop.onAbsorb((int) this.mScroller.getCurrVelocity());
                    } else if (currY >= scrollRange && scrollY < scrollRange) {
                        boolean onAbsorb2 = this.mEdgeGlowBottom.onAbsorb((int) this.mScroller.getCurrVelocity());
                    }
                }
            }
        }
    }

    private void scrollToChild(View view) {
        View view2 = view;
        view2.getDrawingRect(this.mTempRect);
        offsetDescendantRectToMyCoords(view2, this.mTempRect);
        int computeScrollDeltaToGetChildRectOnScreen = computeScrollDeltaToGetChildRectOnScreen(this.mTempRect);
        if (computeScrollDeltaToGetChildRectOnScreen != 0) {
            scrollBy(0, computeScrollDeltaToGetChildRectOnScreen);
        }
    }

    private boolean scrollToChildRect(Rect rect, boolean z) {
        boolean z2 = z;
        int computeScrollDeltaToGetChildRectOnScreen = computeScrollDeltaToGetChildRectOnScreen(rect);
        boolean z3 = computeScrollDeltaToGetChildRectOnScreen != 0;
        if (z3) {
            if (z2) {
                scrollBy(0, computeScrollDeltaToGetChildRectOnScreen);
            } else {
                smoothScrollBy(0, computeScrollDeltaToGetChildRectOnScreen);
            }
        }
        return z3;
    }

    /* access modifiers changed from: protected */
    public int computeScrollDeltaToGetChildRectOnScreen(Rect rect) {
        int i;
        int i2;
        Rect rect2 = rect;
        if (getChildCount() == 0) {
            return 0;
        }
        int height = getHeight();
        int scrollY = getScrollY();
        int i3 = scrollY + height;
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        if (rect2.top > 0) {
            scrollY += verticalFadingEdgeLength;
        }
        if (rect2.bottom < getChildAt(0).getHeight()) {
            i3 -= verticalFadingEdgeLength;
        }
        int i4 = 0;
        if (rect2.bottom > i3 && rect2.top > scrollY) {
            if (rect2.height() > height) {
                i2 = 0 + (rect2.top - scrollY);
            } else {
                i2 = 0 + (rect2.bottom - i3);
            }
            i4 = Math.min(i2, getChildAt(0).getBottom() - i3);
        } else if (rect2.top < scrollY && rect2.bottom < i3) {
            if (rect2.height() > height) {
                i = 0 - (i3 - rect2.bottom);
            } else {
                i = 0 - (scrollY - rect2.top);
            }
            i4 = Math.max(i, -getScrollY());
        }
        return i4;
    }

    public void requestChildFocus(View view, View view2) {
        View view3 = view;
        View view4 = view2;
        if (!this.mIsLayoutDirty) {
            scrollToChild(view4);
        } else {
            this.mChildToScrollTo = view4;
        }
        super.requestChildFocus(view3, view4);
    }

    /* access modifiers changed from: protected */
    public boolean onRequestFocusInDescendants(int i, Rect rect) {
        int i2 = i;
        Rect rect2 = rect;
        if (i2 == 2) {
            i2 = 130;
        } else if (i2 == 1) {
            i2 = 33;
        }
        View findNextFocus = rect2 == null ? FocusFinder.getInstance().findNextFocus(this, (View) null, i2) : FocusFinder.getInstance().findNextFocusFromRect(this, rect2, i2);
        if (findNextFocus == null) {
            return false;
        }
        if (isOffScreen(findNextFocus)) {
            return false;
        }
        return findNextFocus.requestFocus(i2, rect2);
    }

    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z) {
        View view2 = view;
        Rect rect2 = rect;
        rect2.offset(view2.getLeft() - view2.getScrollX(), view2.getTop() - view2.getScrollY());
        return scrollToChildRect(rect2, z);
    }

    public void requestLayout() {
        this.mIsLayoutDirty = true;
        super.requestLayout();
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int i5 = i2;
        int i6 = i4;
        super.onLayout(z, i, i5, i3, i6);
        this.mIsLayoutDirty = false;
        if (this.mChildToScrollTo != null && isViewDescendantOf(this.mChildToScrollTo, this)) {
            scrollToChild(this.mChildToScrollTo);
        }
        this.mChildToScrollTo = null;
        if (!this.mIsLaidOut) {
            if (this.mSavedState != null) {
                scrollTo(getScrollX(), this.mSavedState.scrollPosition);
                this.mSavedState = null;
            }
            int max = Math.max(0, (getChildCount() > 0 ? getChildAt(0).getMeasuredHeight() : 0) - (((i6 - i5) - getPaddingBottom()) - getPaddingTop()));
            if (getScrollY() > max) {
                scrollTo(getScrollX(), max);
            } else if (getScrollY() < 0) {
                scrollTo(getScrollX(), 0);
            }
        }
        scrollTo(getScrollX(), getScrollY());
        this.mIsLaidOut = true;
    }

    public void onAttachedToWindow() {
        this.mIsLaidOut = false;
    }

    /* access modifiers changed from: protected */
    public void onSizeChanged(int i, int i2, int i3, int i4) {
        int i5 = i4;
        super.onSizeChanged(i, i2, i3, i5);
        View findFocus = findFocus();
        if (null != findFocus && this != findFocus && isWithinDeltaOfScreen(findFocus, 0, i5)) {
            findFocus.getDrawingRect(this.mTempRect);
            offsetDescendantRectToMyCoords(findFocus, this.mTempRect);
            doScrollY(computeScrollDeltaToGetChildRectOnScreen(this.mTempRect));
        }
    }

    private static boolean isViewDescendantOf(View view, View view2) {
        View view3 = view;
        View view4 = view2;
        if (view3 == view4) {
            return true;
        }
        ViewParent parent = view3.getParent();
        return (parent instanceof ViewGroup) && isViewDescendantOf((View) parent, view4);
    }

    public void fling(int i) {
        int i2 = i;
        if (getChildCount() > 0) {
            int height = (getHeight() - getPaddingBottom()) - getPaddingTop();
            this.mScroller.fling(getScrollX(), getScrollY(), 0, i2, 0, 0, 0, Math.max(0, getChildAt(0).getHeight() - height), 0, height / 2);
            ViewCompat.postInvalidateOnAnimation(this);
        }
    }

    private void flingWithNestedDispatch(int i) {
        int i2 = i;
        int scrollY = getScrollY();
        boolean z = (scrollY > 0 || i2 > 0) && (scrollY < getScrollRange() || i2 < 0);
        if (!dispatchNestedPreFling(0.0f, (float) i2)) {
            boolean dispatchNestedFling = dispatchNestedFling(0.0f, (float) i2, z);
            if (z) {
                fling(i2);
            }
        }
    }

    private void endDrag() {
        this.mIsBeingDragged = false;
        recycleVelocityTracker();
        stopNestedScroll();
        if (this.mEdgeGlowTop != null) {
            boolean onRelease = this.mEdgeGlowTop.onRelease();
            boolean onRelease2 = this.mEdgeGlowBottom.onRelease();
        }
    }

    public void scrollTo(int i, int i2) {
        int i3 = i;
        int i4 = i2;
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            int clamp = clamp(i3, (getWidth() - getPaddingRight()) - getPaddingLeft(), childAt.getWidth());
            int clamp2 = clamp(i4, (getHeight() - getPaddingBottom()) - getPaddingTop(), childAt.getHeight());
            if (clamp != getScrollX() || clamp2 != getScrollY()) {
                super.scrollTo(clamp, clamp2);
            }
        }
    }

    private void ensureGlows() {
        EdgeEffectCompat edgeEffectCompat;
        EdgeEffectCompat edgeEffectCompat2;
        if (ViewCompat.getOverScrollMode(this) == 2) {
            this.mEdgeGlowTop = null;
            this.mEdgeGlowBottom = null;
        } else if (this.mEdgeGlowTop == null) {
            Context context = getContext();
            new EdgeEffectCompat(context);
            this.mEdgeGlowTop = edgeEffectCompat;
            new EdgeEffectCompat(context);
            this.mEdgeGlowBottom = edgeEffectCompat2;
        }
    }

    public void draw(Canvas canvas) {
        Canvas canvas2 = canvas;
        super.draw(canvas2);
        if (this.mEdgeGlowTop != null) {
            int scrollY = getScrollY();
            if (!this.mEdgeGlowTop.isFinished()) {
                int save = canvas2.save();
                int width = (getWidth() - getPaddingLeft()) - getPaddingRight();
                canvas2.translate((float) getPaddingLeft(), (float) Math.min(0, scrollY));
                this.mEdgeGlowTop.setSize(width, getHeight());
                if (this.mEdgeGlowTop.draw(canvas2)) {
                    ViewCompat.postInvalidateOnAnimation(this);
                }
                canvas2.restoreToCount(save);
            }
            if (!this.mEdgeGlowBottom.isFinished()) {
                int save2 = canvas2.save();
                int width2 = (getWidth() - getPaddingLeft()) - getPaddingRight();
                int height = getHeight();
                canvas2.translate((float) ((-width2) + getPaddingLeft()), (float) (Math.max(getScrollRange(), scrollY) + height));
                canvas2.rotate(180.0f, (float) width2, 0.0f);
                this.mEdgeGlowBottom.setSize(width2, height);
                if (this.mEdgeGlowBottom.draw(canvas2)) {
                    ViewCompat.postInvalidateOnAnimation(this);
                }
                canvas2.restoreToCount(save2);
            }
        }
    }

    private static int clamp(int i, int i2, int i3) {
        int i4 = i;
        int i5 = i2;
        int i6 = i3;
        if (i5 >= i6 || i4 < 0) {
            return 0;
        }
        if (i5 + i4 > i6) {
            return i6 - i5;
        }
        return i4;
    }

    /* access modifiers changed from: protected */
    public void onRestoreInstanceState(Parcelable parcelable) {
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        this.mSavedState = savedState;
        requestLayout();
    }

    /* access modifiers changed from: protected */
    public Parcelable onSaveInstanceState() {
        SavedState savedState;
        new SavedState(super.onSaveInstanceState());
        SavedState savedState2 = savedState;
        savedState2.scrollPosition = getScrollY();
        return savedState2;
    }

    /* renamed from: android.support.v4.widget.NestedScrollView$SavedState */
    static class SavedState extends View.BaseSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR;
        public int scrollPosition;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        /* JADX WARNING: Illegal instructions before constructor call */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public SavedState(android.os.Parcel r5) {
            /*
                r4 = this;
                r0 = r4
                r1 = r5
                r2 = r0
                r3 = r1
                r2.<init>(r3)
                r2 = r0
                r3 = r1
                int r3 = r3.readInt()
                r2.scrollPosition = r3
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: android.support.p000v4.widget.NestedScrollView.SavedState.<init>(android.os.Parcel):void");
        }

        public void writeToParcel(Parcel parcel, int i) {
            Parcel parcel2 = parcel;
            super.writeToParcel(parcel2, i);
            parcel2.writeInt(this.scrollPosition);
        }

        public String toString() {
            StringBuilder sb;
            new StringBuilder();
            return sb.append("HorizontalScrollView.SavedState{").append(Integer.toHexString(System.identityHashCode(this))).append(" scrollPosition=").append(this.scrollPosition).append("}").toString();
        }

        static {
            Parcelable.Creator<SavedState> creator;
            new Parcelable.Creator<SavedState>() {
                public SavedState createFromParcel(Parcel parcel) {
                    SavedState savedState;
                    new SavedState(parcel);
                    return savedState;
                }

                public SavedState[] newArray(int i) {
                    return new SavedState[i];
                }
            };
            CREATOR = creator;
        }
    }

    /* renamed from: android.support.v4.widget.NestedScrollView$AccessibilityDelegate */
    static class AccessibilityDelegate extends AccessibilityDelegateCompat {
        AccessibilityDelegate() {
        }

        public boolean performAccessibilityAction(View view, int i, Bundle bundle) {
            View view2 = view;
            int i2 = i;
            if (super.performAccessibilityAction(view2, i2, bundle)) {
                return true;
            }
            NestedScrollView nestedScrollView = (NestedScrollView) view2;
            if (!nestedScrollView.isEnabled()) {
                return false;
            }
            switch (i2) {
                case 4096:
                    int min = Math.min(nestedScrollView.getScrollY() + ((nestedScrollView.getHeight() - nestedScrollView.getPaddingBottom()) - nestedScrollView.getPaddingTop()), nestedScrollView.getScrollRange());
                    if (min == nestedScrollView.getScrollY()) {
                        return false;
                    }
                    nestedScrollView.smoothScrollTo(0, min);
                    return true;
                case 8192:
                    int max = Math.max(nestedScrollView.getScrollY() - ((nestedScrollView.getHeight() - nestedScrollView.getPaddingBottom()) - nestedScrollView.getPaddingTop()), 0);
                    if (max == nestedScrollView.getScrollY()) {
                        return false;
                    }
                    nestedScrollView.smoothScrollTo(0, max);
                    return true;
                default:
                    return false;
            }
        }

        public void onInitializeAccessibilityNodeInfo(View view, AccessibilityNodeInfoCompat accessibilityNodeInfoCompat) {
            int access$000;
            View view2 = view;
            AccessibilityNodeInfoCompat accessibilityNodeInfoCompat2 = accessibilityNodeInfoCompat;
            super.onInitializeAccessibilityNodeInfo(view2, accessibilityNodeInfoCompat2);
            NestedScrollView nestedScrollView = (NestedScrollView) view2;
            accessibilityNodeInfoCompat2.setClassName(ScrollView.class.getName());
            if (nestedScrollView.isEnabled() && (access$000 = nestedScrollView.getScrollRange()) > 0) {
                accessibilityNodeInfoCompat2.setScrollable(true);
                if (nestedScrollView.getScrollY() > 0) {
                    accessibilityNodeInfoCompat2.addAction(8192);
                }
                if (nestedScrollView.getScrollY() < access$000) {
                    accessibilityNodeInfoCompat2.addAction(4096);
                }
            }
        }

        public void onInitializeAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            View view2 = view;
            AccessibilityEvent accessibilityEvent2 = accessibilityEvent;
            super.onInitializeAccessibilityEvent(view2, accessibilityEvent2);
            NestedScrollView nestedScrollView = (NestedScrollView) view2;
            accessibilityEvent2.setClassName(ScrollView.class.getName());
            AccessibilityRecordCompat asRecord = AccessibilityEventCompat.asRecord(accessibilityEvent2);
            asRecord.setScrollable(nestedScrollView.getScrollRange() > 0);
            asRecord.setScrollX(nestedScrollView.getScrollX());
            asRecord.setScrollY(nestedScrollView.getScrollY());
            asRecord.setMaxScrollX(nestedScrollView.getScrollX());
            asRecord.setMaxScrollY(nestedScrollView.getScrollRange());
        }
    }
}
