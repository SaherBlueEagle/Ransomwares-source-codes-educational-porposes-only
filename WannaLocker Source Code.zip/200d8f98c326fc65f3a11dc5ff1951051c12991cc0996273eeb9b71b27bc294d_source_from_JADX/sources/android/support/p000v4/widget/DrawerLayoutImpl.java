package android.support.p000v4.widget;

/* renamed from: android.support.v4.widget.DrawerLayoutImpl */
interface DrawerLayoutImpl {
    void setChildInsets(Object obj, boolean z);
}
