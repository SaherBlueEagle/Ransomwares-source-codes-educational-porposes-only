package android.support.p000v4.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.ColorInt;
import android.support.annotation.DrawableRes;
import android.support.p000v4.view.AccessibilityDelegateCompat;
import android.support.p000v4.view.MotionEventCompat;
import android.support.p000v4.view.ViewCompat;
import android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.support.p000v4.widget.ViewDragHelper;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;

/* renamed from: android.support.v4.widget.SlidingPaneLayout */
public class SlidingPaneLayout extends ViewGroup {
    private static final int DEFAULT_FADE_COLOR = -858993460;
    private static final int DEFAULT_OVERHANG_SIZE = 32;
    static final SlidingPanelLayoutImpl IMPL;
    private static final int MIN_FLING_VELOCITY = 400;
    private static final String TAG = "SlidingPaneLayout";
    private boolean mCanSlide;
    private int mCoveredFadeColor;
    /* access modifiers changed from: private */
    public final ViewDragHelper mDragHelper;
    private boolean mFirstLayout;
    private float mInitialMotionX;
    private float mInitialMotionY;
    /* access modifiers changed from: private */
    public boolean mIsUnableToDrag;
    private final int mOverhangSize;
    private PanelSlideListener mPanelSlideListener;
    private int mParallaxBy;
    private float mParallaxOffset;
    /* access modifiers changed from: private */
    public final ArrayList<DisableLayerRunnable> mPostedRunnables;
    private boolean mPreservedOpenState;
    private Drawable mShadowDrawableLeft;
    private Drawable mShadowDrawableRight;
    /* access modifiers changed from: private */
    public float mSlideOffset;
    /* access modifiers changed from: private */
    public int mSlideRange;
    /* access modifiers changed from: private */
    public View mSlideableView;
    private int mSliderFadeColor;
    private final Rect mTmpRect;

    /* renamed from: android.support.v4.widget.SlidingPaneLayout$PanelSlideListener */
    public interface PanelSlideListener {
        void onPanelClosed(View view);

        void onPanelOpened(View view);

        void onPanelSlide(View view, float f);
    }

    /* renamed from: android.support.v4.widget.SlidingPaneLayout$SlidingPanelLayoutImpl */
    interface SlidingPanelLayoutImpl {
        void invalidateChildRegion(SlidingPaneLayout slidingPaneLayout, View view);
    }

    static /* synthetic */ boolean access$502(SlidingPaneLayout slidingPaneLayout, boolean z) {
        boolean z2 = z;
        boolean z3 = z2;
        slidingPaneLayout.mPreservedOpenState = z3;
        return z2;
    }

    static {
        SlidingPanelLayoutImpl slidingPanelLayoutImpl;
        SlidingPanelLayoutImpl slidingPanelLayoutImpl2;
        SlidingPanelLayoutImpl slidingPanelLayoutImpl3;
        int i = Build.VERSION.SDK_INT;
        if (i >= 17) {
            new SlidingPanelLayoutImplJBMR1();
            IMPL = slidingPanelLayoutImpl3;
        } else if (i >= 16) {
            new SlidingPanelLayoutImplJB();
            IMPL = slidingPanelLayoutImpl2;
        } else {
            new SlidingPanelLayoutImplBase();
            IMPL = slidingPanelLayoutImpl;
        }
    }

    /* renamed from: android.support.v4.widget.SlidingPaneLayout$SimplePanelSlideListener */
    public static class SimplePanelSlideListener implements PanelSlideListener {
        public SimplePanelSlideListener() {
        }

        public void onPanelSlide(View view, float f) {
        }

        public void onPanelOpened(View view) {
        }

        public void onPanelClosed(View view) {
        }
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public SlidingPaneLayout(Context context) {
        this(context, (AttributeSet) null);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public SlidingPaneLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public SlidingPaneLayout(android.content.Context r15, android.util.AttributeSet r16, int r17) {
        /*
            r14 = this;
            r0 = r14
            r1 = r15
            r2 = r16
            r3 = r17
            r6 = r0
            r7 = r1
            r8 = r2
            r9 = r3
            r6.<init>(r7, r8, r9)
            r6 = r0
            r7 = -858993460(0xffffffffcccccccc, float:-1.07374176E8)
            r6.mSliderFadeColor = r7
            r6 = r0
            r7 = 1
            r6.mFirstLayout = r7
            r6 = r0
            android.graphics.Rect r7 = new android.graphics.Rect
            r13 = r7
            r7 = r13
            r8 = r13
            r8.<init>()
            r6.mTmpRect = r7
            r6 = r0
            java.util.ArrayList r7 = new java.util.ArrayList
            r13 = r7
            r7 = r13
            r8 = r13
            r8.<init>()
            r6.mPostedRunnables = r7
            r6 = r1
            android.content.res.Resources r6 = r6.getResources()
            android.util.DisplayMetrics r6 = r6.getDisplayMetrics()
            float r6 = r6.density
            r4 = r6
            r6 = r0
            r7 = 1107296256(0x42000000, float:32.0)
            r8 = r4
            float r7 = r7 * r8
            r8 = 1056964608(0x3f000000, float:0.5)
            float r7 = r7 + r8
            int r7 = (int) r7
            r6.mOverhangSize = r7
            r6 = r1
            android.view.ViewConfiguration r6 = android.view.ViewConfiguration.get(r6)
            r5 = r6
            r6 = r0
            r7 = 0
            r6.setWillNotDraw(r7)
            r6 = r0
            android.support.v4.widget.SlidingPaneLayout$AccessibilityDelegate r7 = new android.support.v4.widget.SlidingPaneLayout$AccessibilityDelegate
            r13 = r7
            r7 = r13
            r8 = r13
            r9 = r0
            r8.<init>(r9)
            android.support.p000v4.view.ViewCompat.setAccessibilityDelegate(r6, r7)
            r6 = r0
            r7 = 1
            android.support.p000v4.view.ViewCompat.setImportantForAccessibility(r6, r7)
            r6 = r0
            r7 = r0
            r8 = 1056964608(0x3f000000, float:0.5)
            android.support.v4.widget.SlidingPaneLayout$DragHelperCallback r9 = new android.support.v4.widget.SlidingPaneLayout$DragHelperCallback
            r13 = r9
            r9 = r13
            r10 = r13
            r11 = r0
            r12 = 0
            r10.<init>(r11, r12)
            android.support.v4.widget.ViewDragHelper r7 = android.support.p000v4.widget.ViewDragHelper.create(r7, r8, r9)
            r6.mDragHelper = r7
            r6 = r0
            android.support.v4.widget.ViewDragHelper r6 = r6.mDragHelper
            r7 = 1137180672(0x43c80000, float:400.0)
            r8 = r4
            float r7 = r7 * r8
            r6.setMinVelocity(r7)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p000v4.widget.SlidingPaneLayout.<init>(android.content.Context, android.util.AttributeSet, int):void");
    }

    public void setParallaxDistance(int i) {
        this.mParallaxBy = i;
        requestLayout();
    }

    public int getParallaxDistance() {
        return this.mParallaxBy;
    }

    public void setSliderFadeColor(@ColorInt int i) {
        int i2 = i;
        this.mSliderFadeColor = i2;
    }

    @ColorInt
    public int getSliderFadeColor() {
        return this.mSliderFadeColor;
    }

    public void setCoveredFadeColor(@ColorInt int i) {
        int i2 = i;
        this.mCoveredFadeColor = i2;
    }

    @ColorInt
    public int getCoveredFadeColor() {
        return this.mCoveredFadeColor;
    }

    public void setPanelSlideListener(PanelSlideListener panelSlideListener) {
        PanelSlideListener panelSlideListener2 = panelSlideListener;
        this.mPanelSlideListener = panelSlideListener2;
    }

    /* access modifiers changed from: package-private */
    public void dispatchOnPanelSlide(View view) {
        View view2 = view;
        if (this.mPanelSlideListener != null) {
            this.mPanelSlideListener.onPanelSlide(view2, this.mSlideOffset);
        }
    }

    /* access modifiers changed from: package-private */
    public void dispatchOnPanelOpened(View view) {
        View view2 = view;
        if (this.mPanelSlideListener != null) {
            this.mPanelSlideListener.onPanelOpened(view2);
        }
        sendAccessibilityEvent(32);
    }

    /* access modifiers changed from: package-private */
    public void dispatchOnPanelClosed(View view) {
        View view2 = view;
        if (this.mPanelSlideListener != null) {
            this.mPanelSlideListener.onPanelClosed(view2);
        }
        sendAccessibilityEvent(32);
    }

    /* access modifiers changed from: package-private */
    public void updateObscuredViewsVisibility(View view) {
        int width;
        int i;
        int i2;
        int i3;
        int i4;
        View childAt;
        int i5;
        View view2 = view;
        boolean isLayoutRtlSupport = isLayoutRtlSupport();
        int width2 = isLayoutRtlSupport ? getWidth() - getPaddingRight() : getPaddingLeft();
        if (isLayoutRtlSupport) {
            width = getPaddingLeft();
        } else {
            width = getWidth() - getPaddingRight();
        }
        int i6 = width;
        int paddingTop = getPaddingTop();
        int height = getHeight() - getPaddingBottom();
        if (view2 == null || !viewIsOpaque(view2)) {
            i = 0;
            i2 = 0;
            i3 = 0;
            i4 = 0;
        } else {
            i4 = view2.getLeft();
            i3 = view2.getRight();
            i2 = view2.getTop();
            i = view2.getBottom();
        }
        int i7 = 0;
        int childCount = getChildCount();
        while (i7 < childCount && (childAt = getChildAt(i7)) != view2) {
            int max = Math.max(isLayoutRtlSupport ? i6 : width2, childAt.getLeft());
            int max2 = Math.max(paddingTop, childAt.getTop());
            int min = Math.min(isLayoutRtlSupport ? width2 : i6, childAt.getRight());
            int min2 = Math.min(height, childAt.getBottom());
            if (max < i4 || max2 < i2 || min > i3 || min2 > i) {
                i5 = 0;
            } else {
                i5 = 4;
            }
            childAt.setVisibility(i5);
            i7++;
        }
    }

    /* access modifiers changed from: package-private */
    public void setAllChildrenVisible() {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (childAt.getVisibility() == 4) {
                childAt.setVisibility(0);
            }
        }
    }

    private static boolean viewIsOpaque(View view) {
        View view2 = view;
        if (ViewCompat.isOpaque(view2)) {
            return true;
        }
        if (Build.VERSION.SDK_INT >= 18) {
            return false;
        }
        Drawable background = view2.getBackground();
        if (background == null) {
            return false;
        }
        return background.getOpacity() == -1;
    }

    /* access modifiers changed from: protected */
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.mFirstLayout = true;
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.mFirstLayout = true;
        int size = this.mPostedRunnables.size();
        for (int i = 0; i < size; i++) {
            this.mPostedRunnables.get(i).run();
        }
        this.mPostedRunnables.clear();
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        Throwable th;
        int measuredWidth;
        int makeMeasureSpec;
        int makeMeasureSpec2;
        int makeMeasureSpec3;
        int makeMeasureSpec4;
        Throwable th2;
        int i3 = i;
        int i4 = i2;
        int mode = View.MeasureSpec.getMode(i3);
        int size = View.MeasureSpec.getSize(i3);
        int mode2 = View.MeasureSpec.getMode(i4);
        int size2 = View.MeasureSpec.getSize(i4);
        if (mode != 1073741824) {
            if (!isInEditMode()) {
                Throwable th3 = th2;
                new IllegalStateException("Width must have an exact value or MATCH_PARENT");
                throw th3;
            } else if (mode != Integer.MIN_VALUE) {
                if (mode == 0) {
                    size = 300;
                }
            }
        } else if (mode2 == 0) {
            if (!isInEditMode()) {
                Throwable th4 = th;
                new IllegalStateException("Height must not be UNSPECIFIED");
                throw th4;
            } else if (mode2 == 0) {
                mode2 = Integer.MIN_VALUE;
                size2 = 300;
            }
        }
        int i5 = 0;
        int i6 = -1;
        switch (mode2) {
            case Integer.MIN_VALUE:
                i6 = (size2 - getPaddingTop()) - getPaddingBottom();
                break;
            case 1073741824:
                int paddingTop = (size2 - getPaddingTop()) - getPaddingBottom();
                i6 = paddingTop;
                i5 = paddingTop;
                break;
        }
        float f = 0.0f;
        boolean z = false;
        int paddingLeft = (size - getPaddingLeft()) - getPaddingRight();
        int i7 = paddingLeft;
        int childCount = getChildCount();
        if (childCount > 2) {
            int e = Log.e(TAG, "onMeasure: More than two child views are not supported.");
        }
        this.mSlideableView = null;
        for (int i8 = 0; i8 < childCount; i8++) {
            View childAt = getChildAt(i8);
            LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
            if (childAt.getVisibility() == 8) {
                layoutParams.dimWhenOffset = false;
            } else {
                if (layoutParams.weight > 0.0f) {
                    f += layoutParams.weight;
                    if (layoutParams.width == 0) {
                    }
                }
                int i9 = layoutParams.leftMargin + layoutParams.rightMargin;
                if (layoutParams.width == -2) {
                    makeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(paddingLeft - i9, Integer.MIN_VALUE);
                } else if (layoutParams.width == -1) {
                    makeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(paddingLeft - i9, 1073741824);
                } else {
                    makeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(layoutParams.width, 1073741824);
                }
                if (layoutParams.height == -2) {
                    makeMeasureSpec4 = View.MeasureSpec.makeMeasureSpec(i6, Integer.MIN_VALUE);
                } else if (layoutParams.height == -1) {
                    makeMeasureSpec4 = View.MeasureSpec.makeMeasureSpec(i6, 1073741824);
                } else {
                    makeMeasureSpec4 = View.MeasureSpec.makeMeasureSpec(layoutParams.height, 1073741824);
                }
                childAt.measure(makeMeasureSpec3, makeMeasureSpec4);
                int measuredWidth2 = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                if (mode2 == Integer.MIN_VALUE && measuredHeight > i5) {
                    i5 = Math.min(measuredHeight, i6);
                }
                i7 -= measuredWidth2;
                boolean z2 = z;
                LayoutParams layoutParams2 = layoutParams;
                boolean z3 = i7 < 0;
                layoutParams2.slideable = z3;
                z = z2 | z3;
                if (layoutParams.slideable) {
                    this.mSlideableView = childAt;
                }
            }
        }
        if (z || f > 0.0f) {
            int i10 = paddingLeft - this.mOverhangSize;
            for (int i11 = 0; i11 < childCount; i11++) {
                View childAt2 = getChildAt(i11);
                if (childAt2.getVisibility() != 8) {
                    LayoutParams layoutParams3 = (LayoutParams) childAt2.getLayoutParams();
                    if (childAt2.getVisibility() != 8) {
                        boolean z4 = layoutParams3.width == 0 && layoutParams3.weight > 0.0f;
                        if (z4) {
                            measuredWidth = 0;
                        } else {
                            measuredWidth = childAt2.getMeasuredWidth();
                        }
                        int i12 = measuredWidth;
                        if (!z || childAt2 == this.mSlideableView) {
                            if (layoutParams3.weight > 0.0f) {
                                if (layoutParams3.width != 0) {
                                    makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(childAt2.getMeasuredHeight(), 1073741824);
                                } else if (layoutParams3.height == -2) {
                                    makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i6, Integer.MIN_VALUE);
                                } else if (layoutParams3.height == -1) {
                                    makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i6, 1073741824);
                                } else {
                                    makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(layoutParams3.height, 1073741824);
                                }
                                if (z) {
                                    int i13 = paddingLeft - (layoutParams3.leftMargin + layoutParams3.rightMargin);
                                    int makeMeasureSpec5 = View.MeasureSpec.makeMeasureSpec(i13, 1073741824);
                                    if (i12 != i13) {
                                        childAt2.measure(makeMeasureSpec5, makeMeasureSpec);
                                    }
                                } else {
                                    childAt2.measure(View.MeasureSpec.makeMeasureSpec(i12 + ((int) ((layoutParams3.weight * ((float) Math.max(0, i7))) / f)), 1073741824), makeMeasureSpec);
                                }
                            }
                        } else if (layoutParams3.width < 0 && (i12 > i10 || layoutParams3.weight > 0.0f)) {
                            if (!z4) {
                                makeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(childAt2.getMeasuredHeight(), 1073741824);
                            } else if (layoutParams3.height == -2) {
                                makeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i6, Integer.MIN_VALUE);
                            } else if (layoutParams3.height == -1) {
                                makeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i6, 1073741824);
                            } else {
                                makeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(layoutParams3.height, 1073741824);
                            }
                            childAt2.measure(View.MeasureSpec.makeMeasureSpec(i10, 1073741824), makeMeasureSpec2);
                        }
                    }
                }
            }
        }
        setMeasuredDimension(size, i5 + getPaddingTop() + getPaddingBottom());
        this.mCanSlide = z;
        if (this.mDragHelper.getViewDragState() != 0 && !z) {
            this.mDragHelper.abort();
        }
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int i5;
        int i6;
        float f;
        boolean z2 = z;
        int i7 = i;
        int i8 = i2;
        int i9 = i3;
        int i10 = i4;
        boolean isLayoutRtlSupport = isLayoutRtlSupport();
        if (isLayoutRtlSupport) {
            this.mDragHelper.setEdgeTrackingEnabled(2);
        } else {
            this.mDragHelper.setEdgeTrackingEnabled(1);
        }
        int i11 = i9 - i7;
        int paddingRight = isLayoutRtlSupport ? getPaddingRight() : getPaddingLeft();
        int paddingLeft = isLayoutRtlSupport ? getPaddingLeft() : getPaddingRight();
        int paddingTop = getPaddingTop();
        int childCount = getChildCount();
        int i12 = paddingRight;
        int i13 = i12;
        if (this.mFirstLayout) {
            if (this.mCanSlide) {
                if (this.mPreservedOpenState) {
                    f = 1.0f;
                    this.mSlideOffset = f;
                }
            }
            f = 0.0f;
            this.mSlideOffset = f;
        }
        for (int i14 = 0; i14 < childCount; i14++) {
            View childAt = getChildAt(i14);
            if (childAt.getVisibility() != 8) {
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int i15 = 0;
                if (layoutParams.slideable) {
                    int min = (Math.min(i13, (i11 - paddingLeft) - this.mOverhangSize) - i12) - (layoutParams.leftMargin + layoutParams.rightMargin);
                    this.mSlideRange = min;
                    int i16 = isLayoutRtlSupport ? layoutParams.rightMargin : layoutParams.leftMargin;
                    layoutParams.dimWhenOffset = ((i12 + i16) + min) + (measuredWidth / 2) > i11 - paddingLeft;
                    int i17 = (int) (((float) min) * this.mSlideOffset);
                    i12 += i17 + i16;
                    this.mSlideOffset = ((float) i17) / ((float) this.mSlideRange);
                } else {
                    if (this.mCanSlide) {
                        if (this.mParallaxBy != 0) {
                            i15 = (int) ((1.0f - this.mSlideOffset) * ((float) this.mParallaxBy));
                            i12 = i13;
                        }
                    }
                    i12 = i13;
                }
                if (isLayoutRtlSupport) {
                    i6 = (i11 - i12) + i15;
                    i5 = i6 - measuredWidth;
                } else {
                    i5 = i12 - i15;
                    i6 = i5 + measuredWidth;
                }
                childAt.layout(i5, paddingTop, i6, paddingTop + childAt.getMeasuredHeight());
                i13 += childAt.getWidth();
            }
        }
        if (this.mFirstLayout) {
            if (this.mCanSlide) {
                if (this.mParallaxBy != 0) {
                    parallaxOtherViews(this.mSlideOffset);
                }
                if (((LayoutParams) this.mSlideableView.getLayoutParams()).dimWhenOffset) {
                    dimChildView(this.mSlideableView, this.mSlideOffset, this.mSliderFadeColor);
                }
            } else {
                for (int i18 = 0; i18 < childCount; i18++) {
                    dimChildView(getChildAt(i18), 0.0f, this.mSliderFadeColor);
                }
            }
            updateObscuredViewsVisibility(this.mSlideableView);
        }
        this.mFirstLayout = false;
    }

    /* access modifiers changed from: protected */
    public void onSizeChanged(int i, int i2, int i3, int i4) {
        int i5 = i;
        int i6 = i3;
        super.onSizeChanged(i5, i2, i6, i4);
        if (i5 != i6) {
            this.mFirstLayout = true;
        }
    }

    public void requestChildFocus(View view, View view2) {
        View view3 = view;
        super.requestChildFocus(view3, view2);
        if (!isInTouchMode() && !this.mCanSlide) {
            this.mPreservedOpenState = view3 == this.mSlideableView;
        }
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z;
        View childAt;
        MotionEvent motionEvent2 = motionEvent;
        int actionMasked = MotionEventCompat.getActionMasked(motionEvent2);
        if (!this.mCanSlide && actionMasked == 0 && getChildCount() > 1 && (childAt = getChildAt(1)) != null) {
            this.mPreservedOpenState = !this.mDragHelper.isViewUnder(childAt, (int) motionEvent2.getX(), (int) motionEvent2.getY());
        }
        if (!this.mCanSlide || (this.mIsUnableToDrag && actionMasked != 0)) {
            this.mDragHelper.cancel();
            return super.onInterceptTouchEvent(motionEvent2);
        } else if (actionMasked == 3 || actionMasked == 1) {
            this.mDragHelper.cancel();
            return false;
        } else {
            boolean z2 = false;
            switch (actionMasked) {
                case 0:
                    this.mIsUnableToDrag = false;
                    float x = motionEvent2.getX();
                    float y = motionEvent2.getY();
                    this.mInitialMotionX = x;
                    this.mInitialMotionY = y;
                    if (this.mDragHelper.isViewUnder(this.mSlideableView, (int) x, (int) y) && isDimmed(this.mSlideableView)) {
                        z2 = true;
                        break;
                    }
                case 2:
                    float x2 = motionEvent2.getX();
                    float y2 = motionEvent2.getY();
                    float abs = Math.abs(x2 - this.mInitialMotionX);
                    float abs2 = Math.abs(y2 - this.mInitialMotionY);
                    if (abs > ((float) this.mDragHelper.getTouchSlop()) && abs2 > abs) {
                        this.mDragHelper.cancel();
                        this.mIsUnableToDrag = true;
                        return false;
                    }
            }
            if (this.mDragHelper.shouldInterceptTouchEvent(motionEvent2) || z2) {
                z = true;
            } else {
                z = false;
            }
            return z;
        }
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        MotionEvent motionEvent2 = motionEvent;
        if (!this.mCanSlide) {
            return super.onTouchEvent(motionEvent2);
        }
        this.mDragHelper.processTouchEvent(motionEvent2);
        switch (motionEvent2.getAction() & 255) {
            case 0:
                float x = motionEvent2.getX();
                float y = motionEvent2.getY();
                this.mInitialMotionX = x;
                this.mInitialMotionY = y;
                break;
            case 1:
                if (isDimmed(this.mSlideableView)) {
                    float x2 = motionEvent2.getX();
                    float y2 = motionEvent2.getY();
                    float f = x2 - this.mInitialMotionX;
                    float f2 = y2 - this.mInitialMotionY;
                    int touchSlop = this.mDragHelper.getTouchSlop();
                    if ((f * f) + (f2 * f2) < ((float) (touchSlop * touchSlop)) && this.mDragHelper.isViewUnder(this.mSlideableView, (int) x2, (int) y2)) {
                        boolean closePane = closePane(this.mSlideableView, 0);
                        break;
                    }
                }
                break;
        }
        return true;
    }

    private boolean closePane(View view, int i) {
        View view2 = view;
        int i2 = i;
        if (!this.mFirstLayout && !smoothSlideTo(0.0f, i2)) {
            return false;
        }
        this.mPreservedOpenState = false;
        return true;
    }

    private boolean openPane(View view, int i) {
        View view2 = view;
        int i2 = i;
        if (!this.mFirstLayout && !smoothSlideTo(1.0f, i2)) {
            return false;
        }
        this.mPreservedOpenState = true;
        return true;
    }

    @Deprecated
    public void smoothSlideOpen() {
        boolean openPane = openPane();
    }

    public boolean openPane() {
        return openPane(this.mSlideableView, 0);
    }

    @Deprecated
    public void smoothSlideClosed() {
        boolean closePane = closePane();
    }

    public boolean closePane() {
        return closePane(this.mSlideableView, 0);
    }

    public boolean isOpen() {
        return !this.mCanSlide || this.mSlideOffset == 1.0f;
    }

    @Deprecated
    public boolean canSlide() {
        return this.mCanSlide;
    }

    public boolean isSlideable() {
        return this.mCanSlide;
    }

    /* access modifiers changed from: private */
    public void onPanelDragged(int i) {
        int i2 = i;
        if (this.mSlideableView == null) {
            this.mSlideOffset = 0.0f;
            return;
        }
        boolean isLayoutRtlSupport = isLayoutRtlSupport();
        LayoutParams layoutParams = (LayoutParams) this.mSlideableView.getLayoutParams();
        this.mSlideOffset = ((float) ((isLayoutRtlSupport ? (getWidth() - i2) - this.mSlideableView.getWidth() : i2) - ((isLayoutRtlSupport ? getPaddingRight() : getPaddingLeft()) + (isLayoutRtlSupport ? layoutParams.rightMargin : layoutParams.leftMargin)))) / ((float) this.mSlideRange);
        if (this.mParallaxBy != 0) {
            parallaxOtherViews(this.mSlideOffset);
        }
        if (layoutParams.dimWhenOffset) {
            dimChildView(this.mSlideableView, this.mSlideOffset, this.mSliderFadeColor);
        }
        dispatchOnPanelSlide(this.mSlideableView);
    }

    private void dimChildView(View view, float f, int i) {
        Runnable runnable;
        ColorFilter colorFilter;
        Paint paint;
        View view2 = view;
        float f2 = f;
        int i2 = i;
        LayoutParams layoutParams = (LayoutParams) view2.getLayoutParams();
        if (f2 > 0.0f && i2 != 0) {
            int i3 = (((int) (((float) ((i2 & ViewCompat.MEASURED_STATE_MASK) >>> 24)) * f2)) << 24) | (i2 & ViewCompat.MEASURED_SIZE_MASK);
            if (layoutParams.dimPaint == null) {
                new Paint();
                layoutParams.dimPaint = paint;
            }
            new PorterDuffColorFilter(i3, PorterDuff.Mode.SRC_OVER);
            ColorFilter colorFilter2 = layoutParams.dimPaint.setColorFilter(colorFilter);
            if (ViewCompat.getLayerType(view2) != 2) {
                ViewCompat.setLayerType(view2, 2, layoutParams.dimPaint);
            }
            invalidateChildRegion(view2);
        } else if (ViewCompat.getLayerType(view2) != 0) {
            if (layoutParams.dimPaint != null) {
                ColorFilter colorFilter3 = layoutParams.dimPaint.setColorFilter((ColorFilter) null);
            }
            new DisableLayerRunnable(this, view2);
            Runnable runnable2 = runnable;
            boolean add = this.mPostedRunnables.add(runnable2);
            ViewCompat.postOnAnimation(this, runnable2);
        }
    }

    /* access modifiers changed from: protected */
    public boolean drawChild(Canvas canvas, View view, long j) {
        boolean drawChild;
        StringBuilder sb;
        Canvas canvas2 = canvas;
        View view2 = view;
        long j2 = j;
        LayoutParams layoutParams = (LayoutParams) view2.getLayoutParams();
        int save = canvas2.save(2);
        if (this.mCanSlide && !layoutParams.slideable && this.mSlideableView != null) {
            boolean clipBounds = canvas2.getClipBounds(this.mTmpRect);
            if (isLayoutRtlSupport()) {
                this.mTmpRect.left = Math.max(this.mTmpRect.left, this.mSlideableView.getRight());
            } else {
                this.mTmpRect.right = Math.min(this.mTmpRect.right, this.mSlideableView.getLeft());
            }
            boolean clipRect = canvas2.clipRect(this.mTmpRect);
        }
        if (Build.VERSION.SDK_INT >= 11) {
            drawChild = super.drawChild(canvas2, view2, j2);
        } else if (!layoutParams.dimWhenOffset || this.mSlideOffset <= 0.0f) {
            if (view2.isDrawingCacheEnabled()) {
                view2.setDrawingCacheEnabled(false);
            }
            drawChild = super.drawChild(canvas2, view2, j2);
        } else {
            if (!view2.isDrawingCacheEnabled()) {
                view2.setDrawingCacheEnabled(true);
            }
            Bitmap drawingCache = view2.getDrawingCache();
            if (drawingCache != null) {
                canvas2.drawBitmap(drawingCache, (float) view2.getLeft(), (float) view2.getTop(), layoutParams.dimPaint);
                drawChild = false;
            } else {
                new StringBuilder();
                int e = Log.e(TAG, sb.append("drawChild: child view ").append(view2).append(" returned null drawing cache").toString());
                drawChild = super.drawChild(canvas2, view2, j2);
            }
        }
        canvas2.restoreToCount(save);
        return drawChild;
    }

    /* access modifiers changed from: private */
    public void invalidateChildRegion(View view) {
        IMPL.invalidateChildRegion(this, view);
    }

    /* access modifiers changed from: package-private */
    public boolean smoothSlideTo(float f, int i) {
        int paddingLeft;
        float f2 = f;
        int i2 = i;
        if (!this.mCanSlide) {
            return false;
        }
        boolean isLayoutRtlSupport = isLayoutRtlSupport();
        LayoutParams layoutParams = (LayoutParams) this.mSlideableView.getLayoutParams();
        if (isLayoutRtlSupport) {
            paddingLeft = (int) (((float) getWidth()) - ((((float) (getPaddingRight() + layoutParams.rightMargin)) + (f2 * ((float) this.mSlideRange))) + ((float) this.mSlideableView.getWidth())));
        } else {
            paddingLeft = (int) (((float) (getPaddingLeft() + layoutParams.leftMargin)) + (f2 * ((float) this.mSlideRange)));
        }
        if (!this.mDragHelper.smoothSlideViewTo(this.mSlideableView, paddingLeft, this.mSlideableView.getTop())) {
            return false;
        }
        setAllChildrenVisible();
        ViewCompat.postInvalidateOnAnimation(this);
        return true;
    }

    public void computeScroll() {
        if (!this.mDragHelper.continueSettling(true)) {
            return;
        }
        if (!this.mCanSlide) {
            this.mDragHelper.abort();
        } else {
            ViewCompat.postInvalidateOnAnimation(this);
        }
    }

    @Deprecated
    public void setShadowDrawable(Drawable drawable) {
        setShadowDrawableLeft(drawable);
    }

    public void setShadowDrawableLeft(Drawable drawable) {
        Drawable drawable2 = drawable;
        this.mShadowDrawableLeft = drawable2;
    }

    public void setShadowDrawableRight(Drawable drawable) {
        Drawable drawable2 = drawable;
        this.mShadowDrawableRight = drawable2;
    }

    @Deprecated
    public void setShadowResource(@DrawableRes int i) {
        setShadowDrawable(getResources().getDrawable(i));
    }

    public void setShadowResourceLeft(int i) {
        setShadowDrawableLeft(getResources().getDrawable(i));
    }

    public void setShadowResourceRight(int i) {
        setShadowDrawableRight(getResources().getDrawable(i));
    }

    public void draw(Canvas canvas) {
        Drawable drawable;
        int left;
        int i;
        Canvas canvas2 = canvas;
        super.draw(canvas2);
        if (isLayoutRtlSupport()) {
            drawable = this.mShadowDrawableRight;
        } else {
            drawable = this.mShadowDrawableLeft;
        }
        View childAt = getChildCount() > 1 ? getChildAt(1) : null;
        if (childAt != null && drawable != null) {
            int top = childAt.getTop();
            int bottom = childAt.getBottom();
            int intrinsicWidth = drawable.getIntrinsicWidth();
            if (isLayoutRtlSupport()) {
                i = childAt.getRight();
                left = i + intrinsicWidth;
            } else {
                left = childAt.getLeft();
                i = left - intrinsicWidth;
            }
            drawable.setBounds(i, top, left, bottom);
            drawable.draw(canvas2);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:10:0x002e  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void parallaxOtherViews(float r16) {
        /*
            r15 = this;
            r0 = r15
            r1 = r16
            r11 = r0
            boolean r11 = r11.isLayoutRtlSupport()
            r2 = r11
            r11 = r0
            android.view.View r11 = r11.mSlideableView
            android.view.ViewGroup$LayoutParams r11 = r11.getLayoutParams()
            android.support.v4.widget.SlidingPaneLayout$LayoutParams r11 = (android.support.p000v4.widget.SlidingPaneLayout.LayoutParams) r11
            r3 = r11
            r11 = r3
            boolean r11 = r11.dimWhenOffset
            if (r11 == 0) goto L_0x0042
            r11 = r2
            if (r11 == 0) goto L_0x003e
            r11 = r3
            int r11 = r11.rightMargin
        L_0x001e:
            if (r11 > 0) goto L_0x0042
            r11 = 1
        L_0x0021:
            r4 = r11
            r11 = r0
            int r11 = r11.getChildCount()
            r5 = r11
            r11 = 0
            r6 = r11
        L_0x002a:
            r11 = r6
            r12 = r5
            if (r11 >= r12) goto L_0x008b
            r11 = r0
            r12 = r6
            android.view.View r11 = r11.getChildAt(r12)
            r7 = r11
            r11 = r7
            r12 = r0
            android.view.View r12 = r12.mSlideableView
            if (r11 != r12) goto L_0x0044
        L_0x003b:
            int r6 = r6 + 1
            goto L_0x002a
        L_0x003e:
            r11 = r3
            int r11 = r11.leftMargin
            goto L_0x001e
        L_0x0042:
            r11 = 0
            goto L_0x0021
        L_0x0044:
            r11 = 1065353216(0x3f800000, float:1.0)
            r12 = r0
            float r12 = r12.mParallaxOffset
            float r11 = r11 - r12
            r12 = r0
            int r12 = r12.mParallaxBy
            float r12 = (float) r12
            float r11 = r11 * r12
            int r11 = (int) r11
            r8 = r11
            r11 = r0
            r12 = r1
            r11.mParallaxOffset = r12
            r11 = 1065353216(0x3f800000, float:1.0)
            r12 = r1
            float r11 = r11 - r12
            r12 = r0
            int r12 = r12.mParallaxBy
            float r12 = (float) r12
            float r11 = r11 * r12
            int r11 = (int) r11
            r9 = r11
            r11 = r8
            r12 = r9
            int r11 = r11 - r12
            r10 = r11
            r11 = r7
            r12 = r2
            if (r12 == 0) goto L_0x0082
            r12 = r10
            int r12 = -r12
        L_0x006a:
            r11.offsetLeftAndRight(r12)
            r11 = r4
            if (r11 == 0) goto L_0x003b
            r11 = r0
            r12 = r7
            r13 = r2
            if (r13 == 0) goto L_0x0084
            r13 = r0
            float r13 = r13.mParallaxOffset
            r14 = 1065353216(0x3f800000, float:1.0)
            float r13 = r13 - r14
        L_0x007b:
            r14 = r0
            int r14 = r14.mCoveredFadeColor
            r11.dimChildView(r12, r13, r14)
            goto L_0x003b
        L_0x0082:
            r12 = r10
            goto L_0x006a
        L_0x0084:
            r13 = 1065353216(0x3f800000, float:1.0)
            r14 = r0
            float r14 = r14.mParallaxOffset
            float r13 = r13 - r14
            goto L_0x007b
        L_0x008b:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p000v4.widget.SlidingPaneLayout.parallaxOtherViews(float):void");
    }

    /* access modifiers changed from: protected */
    public boolean canScroll(View view, boolean z, int i, int i2, int i3) {
        boolean z2;
        View view2 = view;
        boolean z3 = z;
        int i4 = i;
        int i5 = i2;
        int i6 = i3;
        if (view2 instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view2;
            int scrollX = view2.getScrollX();
            int scrollY = view2.getScrollY();
            for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                View childAt = viewGroup.getChildAt(childCount);
                if (i5 + scrollX >= childAt.getLeft() && i5 + scrollX < childAt.getRight() && i6 + scrollY >= childAt.getTop() && i6 + scrollY < childAt.getBottom() && canScroll(childAt, true, i4, (i5 + scrollX) - childAt.getLeft(), (i6 + scrollY) - childAt.getTop())) {
                    return true;
                }
            }
        }
        if (z3) {
            if (ViewCompat.canScrollHorizontally(view2, isLayoutRtlSupport() ? i4 : -i4)) {
                z2 = true;
                return z2;
            }
        }
        z2 = false;
        return z2;
    }

    /* access modifiers changed from: package-private */
    public boolean isDimmed(View view) {
        View view2 = view;
        if (view2 == null) {
            return false;
        }
        return this.mCanSlide && ((LayoutParams) view2.getLayoutParams()).dimWhenOffset && this.mSlideOffset > 0.0f;
    }

    /* access modifiers changed from: protected */
    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        ViewGroup.LayoutParams layoutParams;
        new LayoutParams();
        return layoutParams;
    }

    /* access modifiers changed from: protected */
    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        ViewGroup.LayoutParams layoutParams2;
        ViewGroup.LayoutParams layoutParams3;
        ViewGroup.LayoutParams layoutParams4;
        ViewGroup.LayoutParams layoutParams5 = layoutParams;
        if (layoutParams5 instanceof ViewGroup.MarginLayoutParams) {
            layoutParams3 = layoutParams4;
            new LayoutParams((ViewGroup.MarginLayoutParams) layoutParams5);
        } else {
            layoutParams3 = layoutParams2;
            new LayoutParams(layoutParams5);
        }
        return layoutParams3;
    }

    /* access modifiers changed from: protected */
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        ViewGroup.LayoutParams layoutParams2 = layoutParams;
        return (layoutParams2 instanceof LayoutParams) && super.checkLayoutParams(layoutParams2);
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        ViewGroup.LayoutParams layoutParams;
        new LayoutParams(getContext(), attributeSet);
        return layoutParams;
    }

    /* access modifiers changed from: protected */
    public Parcelable onSaveInstanceState() {
        SavedState savedState;
        new SavedState(super.onSaveInstanceState());
        SavedState savedState2 = savedState;
        savedState2.isOpen = isSlideable() ? isOpen() : this.mPreservedOpenState;
        return savedState2;
    }

    /* access modifiers changed from: protected */
    public void onRestoreInstanceState(Parcelable parcelable) {
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        if (savedState.isOpen) {
            boolean openPane = openPane();
        } else {
            boolean closePane = closePane();
        }
        this.mPreservedOpenState = savedState.isOpen;
    }

    /* renamed from: android.support.v4.widget.SlidingPaneLayout$DragHelperCallback */
    private class DragHelperCallback extends ViewDragHelper.Callback {
        final /* synthetic */ SlidingPaneLayout this$0;

        private DragHelperCallback(SlidingPaneLayout slidingPaneLayout) {
            this.this$0 = slidingPaneLayout;
        }

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        /* synthetic */ DragHelperCallback(SlidingPaneLayout slidingPaneLayout, C01931 r7) {
            this(slidingPaneLayout);
            C01931 r2 = r7;
        }

        public boolean tryCaptureView(View view, int i) {
            View view2 = view;
            int i2 = i;
            if (this.this$0.mIsUnableToDrag) {
                return false;
            }
            return ((LayoutParams) view2.getLayoutParams()).slideable;
        }

        public void onViewDragStateChanged(int i) {
            int i2 = i;
            if (this.this$0.mDragHelper.getViewDragState() != 0) {
                return;
            }
            if (this.this$0.mSlideOffset == 0.0f) {
                this.this$0.updateObscuredViewsVisibility(this.this$0.mSlideableView);
                this.this$0.dispatchOnPanelClosed(this.this$0.mSlideableView);
                boolean access$502 = SlidingPaneLayout.access$502(this.this$0, false);
                return;
            }
            this.this$0.dispatchOnPanelOpened(this.this$0.mSlideableView);
            boolean access$5022 = SlidingPaneLayout.access$502(this.this$0, true);
        }

        public void onViewCaptured(View view, int i) {
            View view2 = view;
            int i2 = i;
            this.this$0.setAllChildrenVisible();
        }

        public void onViewPositionChanged(View view, int i, int i2, int i3, int i4) {
            View view2 = view;
            int i5 = i2;
            int i6 = i3;
            int i7 = i4;
            this.this$0.onPanelDragged(i);
            this.this$0.invalidate();
        }

        public void onViewReleased(View view, float f, float f2) {
            int paddingLeft;
            View view2 = view;
            float f3 = f;
            float f4 = f2;
            LayoutParams layoutParams = (LayoutParams) view2.getLayoutParams();
            if (this.this$0.isLayoutRtlSupport()) {
                int paddingRight = this.this$0.getPaddingRight() + layoutParams.rightMargin;
                if (f3 < 0.0f || (f3 == 0.0f && this.this$0.mSlideOffset > 0.5f)) {
                    paddingRight += this.this$0.mSlideRange;
                }
                paddingLeft = (this.this$0.getWidth() - paddingRight) - this.this$0.mSlideableView.getWidth();
            } else {
                paddingLeft = this.this$0.getPaddingLeft() + layoutParams.leftMargin;
                if (f3 > 0.0f || (f3 == 0.0f && this.this$0.mSlideOffset > 0.5f)) {
                    paddingLeft += this.this$0.mSlideRange;
                }
            }
            boolean z = this.this$0.mDragHelper.settleCapturedViewAt(paddingLeft, view2.getTop());
            this.this$0.invalidate();
        }

        public int getViewHorizontalDragRange(View view) {
            View view2 = view;
            return this.this$0.mSlideRange;
        }

        public int clampViewPositionHorizontal(View view, int i, int i2) {
            int min;
            View view2 = view;
            int i3 = i;
            int i4 = i2;
            LayoutParams layoutParams = (LayoutParams) this.this$0.mSlideableView.getLayoutParams();
            if (this.this$0.isLayoutRtlSupport()) {
                int width = this.this$0.getWidth() - ((this.this$0.getPaddingRight() + layoutParams.rightMargin) + this.this$0.mSlideableView.getWidth());
                min = Math.max(Math.min(i3, width), width - this.this$0.mSlideRange);
            } else {
                int paddingLeft = this.this$0.getPaddingLeft() + layoutParams.leftMargin;
                min = Math.min(Math.max(i3, paddingLeft), paddingLeft + this.this$0.mSlideRange);
            }
            return min;
        }

        public int clampViewPositionVertical(View view, int i, int i2) {
            int i3 = i;
            int i4 = i2;
            return view.getTop();
        }

        public void onEdgeDragStarted(int i, int i2) {
            int i3 = i;
            this.this$0.mDragHelper.captureChildView(this.this$0.mSlideableView, i2);
        }
    }

    /* renamed from: android.support.v4.widget.SlidingPaneLayout$LayoutParams */
    public static class LayoutParams extends ViewGroup.MarginLayoutParams {
        private static final int[] ATTRS = {16843137};
        Paint dimPaint;
        boolean dimWhenOffset;
        boolean slideable;
        public float weight = 0.0f;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public LayoutParams() {
            super(-1, -1);
        }

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public LayoutParams(int i, int i2) {
            super(i, i2);
        }

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public LayoutParams(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public LayoutParams(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        /* JADX WARNING: Illegal instructions before constructor call */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public LayoutParams(android.support.p000v4.widget.SlidingPaneLayout.LayoutParams r5) {
            /*
                r4 = this;
                r0 = r4
                r1 = r5
                r2 = r0
                r3 = r1
                r2.<init>(r3)
                r2 = r0
                r3 = 0
                r2.weight = r3
                r2 = r0
                r3 = r1
                float r3 = r3.weight
                r2.weight = r3
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: android.support.p000v4.widget.SlidingPaneLayout.LayoutParams.<init>(android.support.v4.widget.SlidingPaneLayout$LayoutParams):void");
        }

        /* JADX WARNING: Illegal instructions before constructor call */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public LayoutParams(android.content.Context r9, android.util.AttributeSet r10) {
            /*
                r8 = this;
                r0 = r8
                r1 = r9
                r2 = r10
                r4 = r0
                r5 = r1
                r6 = r2
                r4.<init>(r5, r6)
                r4 = r0
                r5 = 0
                r4.weight = r5
                r4 = r1
                r5 = r2
                int[] r6 = ATTRS
                android.content.res.TypedArray r4 = r4.obtainStyledAttributes(r5, r6)
                r3 = r4
                r4 = r0
                r5 = r3
                r6 = 0
                r7 = 0
                float r5 = r5.getFloat(r6, r7)
                r4.weight = r5
                r4 = r3
                r4.recycle()
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: android.support.p000v4.widget.SlidingPaneLayout.LayoutParams.<init>(android.content.Context, android.util.AttributeSet):void");
        }
    }

    /* renamed from: android.support.v4.widget.SlidingPaneLayout$SavedState */
    static class SavedState extends View.BaseSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR;
        boolean isOpen;

        /* JADX INFO: this call moved to the top of the method (can break code semantics) */
        /* synthetic */ SavedState(Parcel parcel, C01931 r7) {
            this(parcel);
            C01931 r2 = r7;
        }

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        /* JADX WARNING: Illegal instructions before constructor call */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        private SavedState(android.os.Parcel r5) {
            /*
                r4 = this;
                r0 = r4
                r1 = r5
                r2 = r0
                r3 = r1
                r2.<init>(r3)
                r2 = r0
                r3 = r1
                int r3 = r3.readInt()
                if (r3 == 0) goto L_0x0013
                r3 = 1
            L_0x0010:
                r2.isOpen = r3
                return
            L_0x0013:
                r3 = 0
                goto L_0x0010
            */
            throw new UnsupportedOperationException("Method not decompiled: android.support.p000v4.widget.SlidingPaneLayout.SavedState.<init>(android.os.Parcel):void");
        }

        public void writeToParcel(Parcel parcel, int i) {
            Parcel parcel2 = parcel;
            super.writeToParcel(parcel2, i);
            parcel2.writeInt(this.isOpen ? 1 : 0);
        }

        static {
            Parcelable.Creator<SavedState> creator;
            new Parcelable.Creator<SavedState>() {
                public SavedState createFromParcel(Parcel parcel) {
                    SavedState savedState;
                    new SavedState(parcel, (C01931) null);
                    return savedState;
                }

                public SavedState[] newArray(int i) {
                    return new SavedState[i];
                }
            };
            CREATOR = creator;
        }
    }

    /* renamed from: android.support.v4.widget.SlidingPaneLayout$SlidingPanelLayoutImplBase */
    static class SlidingPanelLayoutImplBase implements SlidingPanelLayoutImpl {
        SlidingPanelLayoutImplBase() {
        }

        public void invalidateChildRegion(SlidingPaneLayout slidingPaneLayout, View view) {
            View view2 = view;
            ViewCompat.postInvalidateOnAnimation(slidingPaneLayout, view2.getLeft(), view2.getTop(), view2.getRight(), view2.getBottom());
        }
    }

    /* renamed from: android.support.v4.widget.SlidingPaneLayout$SlidingPanelLayoutImplJB */
    static class SlidingPanelLayoutImplJB extends SlidingPanelLayoutImplBase {
        private Method mGetDisplayList;
        private Field mRecreateDisplayList;

        SlidingPanelLayoutImplJB() {
            try {
                this.mGetDisplayList = View.class.getDeclaredMethod("getDisplayList", (Class[]) null);
            } catch (NoSuchMethodException e) {
                int e2 = Log.e(SlidingPaneLayout.TAG, "Couldn't fetch getDisplayList method; dimming won't work right.", e);
            }
            try {
                this.mRecreateDisplayList = View.class.getDeclaredField("mRecreateDisplayList");
                this.mRecreateDisplayList.setAccessible(true);
            } catch (NoSuchFieldException e3) {
                int e4 = Log.e(SlidingPaneLayout.TAG, "Couldn't fetch mRecreateDisplayList field; dimming will be slow.", e3);
            }
        }

        public void invalidateChildRegion(SlidingPaneLayout slidingPaneLayout, View view) {
            SlidingPaneLayout slidingPaneLayout2 = slidingPaneLayout;
            View view2 = view;
            if (this.mGetDisplayList == null || this.mRecreateDisplayList == null) {
                view2.invalidate();
                return;
            }
            try {
                this.mRecreateDisplayList.setBoolean(view2, true);
                Object invoke = this.mGetDisplayList.invoke(view2, (Object[]) null);
            } catch (Exception e) {
                int e2 = Log.e(SlidingPaneLayout.TAG, "Error refreshing display list state", e);
            }
            super.invalidateChildRegion(slidingPaneLayout2, view2);
        }
    }

    /* renamed from: android.support.v4.widget.SlidingPaneLayout$SlidingPanelLayoutImplJBMR1 */
    static class SlidingPanelLayoutImplJBMR1 extends SlidingPanelLayoutImplBase {
        SlidingPanelLayoutImplJBMR1() {
        }

        public void invalidateChildRegion(SlidingPaneLayout slidingPaneLayout, View view) {
            SlidingPaneLayout slidingPaneLayout2 = slidingPaneLayout;
            View view2 = view;
            ViewCompat.setLayerPaint(view2, ((LayoutParams) view2.getLayoutParams()).dimPaint);
        }
    }

    /* renamed from: android.support.v4.widget.SlidingPaneLayout$AccessibilityDelegate */
    class AccessibilityDelegate extends AccessibilityDelegateCompat {
        private final Rect mTmpRect;
        final /* synthetic */ SlidingPaneLayout this$0;

        AccessibilityDelegate(SlidingPaneLayout slidingPaneLayout) {
            Rect rect;
            this.this$0 = slidingPaneLayout;
            new Rect();
            this.mTmpRect = rect;
        }

        public void onInitializeAccessibilityNodeInfo(View view, AccessibilityNodeInfoCompat accessibilityNodeInfoCompat) {
            View view2 = view;
            AccessibilityNodeInfoCompat accessibilityNodeInfoCompat2 = accessibilityNodeInfoCompat;
            AccessibilityNodeInfoCompat obtain = AccessibilityNodeInfoCompat.obtain(accessibilityNodeInfoCompat2);
            super.onInitializeAccessibilityNodeInfo(view2, obtain);
            copyNodeInfoNoChildren(accessibilityNodeInfoCompat2, obtain);
            obtain.recycle();
            accessibilityNodeInfoCompat2.setClassName(SlidingPaneLayout.class.getName());
            accessibilityNodeInfoCompat2.setSource(view2);
            ViewParent parentForAccessibility = ViewCompat.getParentForAccessibility(view2);
            if (parentForAccessibility instanceof View) {
                accessibilityNodeInfoCompat2.setParent((View) parentForAccessibility);
            }
            int childCount = this.this$0.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = this.this$0.getChildAt(i);
                if (!filter(childAt) && childAt.getVisibility() == 0) {
                    ViewCompat.setImportantForAccessibility(childAt, 1);
                    accessibilityNodeInfoCompat2.addChild(childAt);
                }
            }
        }

        public void onInitializeAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            AccessibilityEvent accessibilityEvent2 = accessibilityEvent;
            super.onInitializeAccessibilityEvent(view, accessibilityEvent2);
            accessibilityEvent2.setClassName(SlidingPaneLayout.class.getName());
        }

        public boolean onRequestSendAccessibilityEvent(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
            ViewGroup viewGroup2 = viewGroup;
            View view2 = view;
            AccessibilityEvent accessibilityEvent2 = accessibilityEvent;
            if (!filter(view2)) {
                return super.onRequestSendAccessibilityEvent(viewGroup2, view2, accessibilityEvent2);
            }
            return false;
        }

        public boolean filter(View view) {
            return this.this$0.isDimmed(view);
        }

        private void copyNodeInfoNoChildren(AccessibilityNodeInfoCompat accessibilityNodeInfoCompat, AccessibilityNodeInfoCompat accessibilityNodeInfoCompat2) {
            AccessibilityNodeInfoCompat accessibilityNodeInfoCompat3 = accessibilityNodeInfoCompat;
            AccessibilityNodeInfoCompat accessibilityNodeInfoCompat4 = accessibilityNodeInfoCompat2;
            Rect rect = this.mTmpRect;
            accessibilityNodeInfoCompat4.getBoundsInParent(rect);
            accessibilityNodeInfoCompat3.setBoundsInParent(rect);
            accessibilityNodeInfoCompat4.getBoundsInScreen(rect);
            accessibilityNodeInfoCompat3.setBoundsInScreen(rect);
            accessibilityNodeInfoCompat3.setVisibleToUser(accessibilityNodeInfoCompat4.isVisibleToUser());
            accessibilityNodeInfoCompat3.setPackageName(accessibilityNodeInfoCompat4.getPackageName());
            accessibilityNodeInfoCompat3.setClassName(accessibilityNodeInfoCompat4.getClassName());
            accessibilityNodeInfoCompat3.setContentDescription(accessibilityNodeInfoCompat4.getContentDescription());
            accessibilityNodeInfoCompat3.setEnabled(accessibilityNodeInfoCompat4.isEnabled());
            accessibilityNodeInfoCompat3.setClickable(accessibilityNodeInfoCompat4.isClickable());
            accessibilityNodeInfoCompat3.setFocusable(accessibilityNodeInfoCompat4.isFocusable());
            accessibilityNodeInfoCompat3.setFocused(accessibilityNodeInfoCompat4.isFocused());
            accessibilityNodeInfoCompat3.setAccessibilityFocused(accessibilityNodeInfoCompat4.isAccessibilityFocused());
            accessibilityNodeInfoCompat3.setSelected(accessibilityNodeInfoCompat4.isSelected());
            accessibilityNodeInfoCompat3.setLongClickable(accessibilityNodeInfoCompat4.isLongClickable());
            accessibilityNodeInfoCompat3.addAction(accessibilityNodeInfoCompat4.getActions());
            accessibilityNodeInfoCompat3.setMovementGranularities(accessibilityNodeInfoCompat4.getMovementGranularities());
        }
    }

    /* renamed from: android.support.v4.widget.SlidingPaneLayout$DisableLayerRunnable */
    private class DisableLayerRunnable implements Runnable {
        final View mChildView;
        final /* synthetic */ SlidingPaneLayout this$0;

        DisableLayerRunnable(SlidingPaneLayout slidingPaneLayout, View view) {
            this.this$0 = slidingPaneLayout;
            this.mChildView = view;
        }

        public void run() {
            if (this.mChildView.getParent() == this.this$0) {
                ViewCompat.setLayerType(this.mChildView, 0, (Paint) null);
                this.this$0.invalidateChildRegion(this.mChildView);
            }
            boolean remove = this.this$0.mPostedRunnables.remove(this);
        }
    }

    /* access modifiers changed from: private */
    public boolean isLayoutRtlSupport() {
        return ViewCompat.getLayoutDirection(this) == 1;
    }
}
