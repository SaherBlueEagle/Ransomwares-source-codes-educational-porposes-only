package android.support.p000v4.graphics;

import android.graphics.Bitmap;

/* renamed from: android.support.v4.graphics.BitmapCompatHoneycombMr1 */
class BitmapCompatHoneycombMr1 {
    BitmapCompatHoneycombMr1() {
    }

    static int getAllocationByteCount(Bitmap bitmap) {
        return bitmap.getByteCount();
    }
}
