package android.support.p000v4.graphics;

import android.graphics.Bitmap;

/* renamed from: android.support.v4.graphics.BitmapCompatKitKat */
class BitmapCompatKitKat {
    BitmapCompatKitKat() {
    }

    static int getAllocationByteCount(Bitmap bitmap) {
        return bitmap.getAllocationByteCount();
    }
}
