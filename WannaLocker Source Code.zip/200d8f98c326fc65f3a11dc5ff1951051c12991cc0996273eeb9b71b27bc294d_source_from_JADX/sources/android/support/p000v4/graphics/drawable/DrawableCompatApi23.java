package android.support.p000v4.graphics.drawable;

import android.graphics.drawable.Drawable;

/* renamed from: android.support.v4.graphics.drawable.DrawableCompatApi23 */
class DrawableCompatApi23 {
    DrawableCompatApi23() {
    }

    public static void setLayoutDirection(Drawable drawable, int i) {
        boolean layoutDirection = drawable.setLayoutDirection(i);
    }

    public static int getLayoutDirection(Drawable drawable) {
        return drawable.getLayoutDirection();
    }
}
