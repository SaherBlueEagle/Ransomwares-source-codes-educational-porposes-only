package android.support.p000v4.view;

import android.view.ViewConfiguration;

/* renamed from: android.support.v4.view.ViewConfigurationCompatFroyo */
class ViewConfigurationCompatFroyo {
    ViewConfigurationCompatFroyo() {
    }

    public static int getScaledPagingTouchSlop(ViewConfiguration viewConfiguration) {
        return viewConfiguration.getScaledPagingTouchSlop();
    }
}
