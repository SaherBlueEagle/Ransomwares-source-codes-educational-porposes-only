package android.support.p000v4.animation;

/* renamed from: android.support.v4.animation.AnimatorUpdateListenerCompat */
public interface AnimatorUpdateListenerCompat {
    void onAnimationUpdate(ValueAnimatorCompat valueAnimatorCompat);
}
