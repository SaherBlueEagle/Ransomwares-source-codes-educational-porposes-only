<?php
$servername = "localhost";
$username = "dbusername";
$password = "password";
$dbname = "dbname";


$conn = new mysqli($servername, $username, $password, $dbname);

