# Teardroid-phprat


its easy to use android php rat the best part is no port forwarding needed also work as ransomware 

# requirement:
1.android studio

2.website

# version 2.0 

![Screenshot](https://github.com/ScRiPt1337/Teardroid-phprat/blob/master/Capture.PNG)

# how to use

# https://www.youtube.com/watch?v=dGe5caZHpeo&t=218s     (old version's setup tutorial)

# Contact us

# https://discord.gg/5CjQacc
